"""AURA AI Super Studio - Configuration"""
from pydantic_settings import BaseSettings
from functools import lru_cache

class Settings(BaseSettings):
    # AI Models
    OPENAI_API_KEY:             str = ""
    ANTHROPIC_API_KEY:          str = ""
    GEMINI_API_KEY:             str = ""
    QWEN_API_KEY:               str = ""
    # Voice & Audio
    ELEVENLABS_API_KEY:         str = ""
    ELEVENLABS_VOICE_ID:        str = ""
    VAPI_API_KEY:               str = ""
    TWILIO_ACCOUNT_SID:         str = ""
    TWILIO_AUTH_TOKEN:          str = ""
    TWILIO_PHONE:               str = ""
    # Video & Avatars
    HEYGEN_API_KEY:             str = ""
    DID_API_KEY:                str = ""
    SUNO_API_KEY:               str = ""
    KLING_API_KEY:              str = ""
    REPLICATE_API_KEY:          str = ""
    # WhatsApp
    WHATSAPP_TOKEN:             str = ""
    WHATSAPP_PHONE_ID:          str = ""
    WHATSAPP_VERIFY_TOKEN:      str = "aura_verify_2025"
    # Social Media
    TIKTOK_ACCESS_TOKEN:        str = ""
    INSTAGRAM_ACCESS_TOKEN:     str = ""
    INSTAGRAM_USER_ID:          str = ""
    YOUTUBE_ACCESS_TOKEN:       str = ""
    FACEBOOK_PAGE_TOKEN:        str = ""
    FACEBOOK_PAGE_ID:           str = ""
    # Stripe
    STRIPE_SECRET_KEY:          str = ""
    STRIPE_WEBHOOK_SECRET:      str = ""
    STRIPE_PRO_PRICE_ID:        str = ""
    STRIPE_ENTERPRISE_PRICE_ID: str = ""
    STRIPE_PACK_500:            str = ""
    STRIPE_PACK_2000:           str = ""
    STRIPE_PACK_5000:           str = ""
    # Google OAuth
    GOOGLE_CLIENT_ID:           str = ""
    GOOGLE_CLIENT_SECRET:       str = ""
    NOTION_API_KEY:             str = ""
    # Auth
    JWT_SECRET:                 str = "change-me-32chars-minimum-secret!"
    # Infrastructure
    COMFYUI_URL:                str = "http://127.0.0.1:8188"
    HAILO_DEVICE_IP:            str = ""
    DATABASE_URL:               str = "sqlite:///./aura.db"
    REDIS_URL:                  str = "redis://localhost:6379"
    STORAGE_PATH:               str = "./media"
    N8N_WEBHOOK_URL:            str = ""
    WEBHOOK_BASE_URL:           str = "http://localhost:8000"
    ALERT_WEBHOOK:              str = ""
    # App
    DEFAULT_AI_MODEL:           str = "claude-sonnet-4-5-20251001"
    DEFAULT_VOICE_MODEL:        str = "eleven_multilingual_v2"
    MAX_VIDEO_DURATION:         int = 600
    PORT:                       int = 8000
    DEBUG:                      bool = True

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}

@lru_cache()
def get_settings() -> Settings:
    return Settings()

settings = get_settings()

#!/usr/bin/env python3
"""
AURA — Production Health Monitor
Run once:     python3 health_monitor.py
Run forever:  python3 health_monitor.py --monitor
"""
import asyncio, httpx, os, sys
from datetime import datetime

BASE = os.getenv("AURA_BASE_URL", "http://localhost:8000")
INTERVAL = int(os.getenv("HEALTH_INTERVAL", "60"))
ALERT    = os.getenv("ALERT_WEBHOOK", "")

G = "\033[92m"; Y = "\033[93m"; R = "\033[91m"; B = "\033[94m"; RESET = "\033[0m"; BOLD = "\033[1m"

def ok(m):   print(f"  {G}✅ {m}{RESET}")
def warn(m): print(f"  {Y}⚠️  {m}{RESET}")
def fail(m): print(f"  {R}❌ {m}{RESET}")
def info(m): print(f"  {B}ℹ️  {m}{RESET}")

async def check():
    issues = []
    print(f"\n{BOLD}{'='*50}{RESET}")
    print(f"{BOLD}AURA Health — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{RESET}")
    print(f"{'='*50}")

    async with httpx.AsyncClient(timeout=10) as client:
        # Backend
        print(f"\n{BOLD}Backend{RESET}")
        try:
            r    = await client.get(f"{BASE}/api/health")
            data = r.json()
            ok(f"FastAPI v{data.get('version','?')} running")
            for name, status in data.get("checks", {}).items():
                if "✅" in str(status): ok(f"{name}: {status}")
                elif "missing" in str(status).lower(): warn(f"{name}: {status}"); issues.append(f"{name} key missing")
                else: warn(f"{name}: {status}")
        except Exception as e:
            fail(f"Backend unreachable: {e}"); issues.append("Backend offline")
            return issues

        # System
        print(f"\n{BOLD}System{RESET}")
        try:
            r    = await client.get(f"{BASE}/api/analytics/system")
            data = r.json()
            disk = data.get("disk", {})
            ok(f"Disk: {disk.get('used_gb',0):.1f}/{disk.get('total_gb',0):.1f}GB ({disk.get('pct_used',0):.0f}%)")
            if disk.get("pct_used", 0) > 85:
                warn("Disk >85% full"); issues.append("High disk usage")
        except Exception as e:
            warn(f"System check failed: {e}")

        # Usage
        print(f"\n{BOLD}Usage stats{RESET}")
        try:
            r  = await client.get(f"{BASE}/api/analytics/dashboard")
            ov = r.json().get("overview", {})
            ok(f"Images: {ov.get('total_images',0)} | Videos: {ov.get('total_videos',0)}")
            ok(f"WA users: {ov.get('wa_users',0)} | Messages: {ov.get('wa_conversations',0)}")
        except Exception: info("Usage stats unavailable")

        # External APIs
        print(f"\n{BOLD}API connectivity{RESET}")
        api_checks = [
            ("OpenAI",     "https://api.openai.com/v1/models",
             {"Authorization": f"Bearer {os.getenv('OPENAI_API_KEY','')}"}),
            ("ElevenLabs", "https://api.elevenlabs.io/v1/user",
             {"xi-api-key": os.getenv("ELEVENLABS_API_KEY","")}),
        ]
        for name, url, headers in api_checks:
            try:
                r = await client.get(url, headers=headers, timeout=5)
                if r.status_code == 200:   ok(f"{name} ✓")
                elif r.status_code == 401: warn(f"{name}: invalid key"); issues.append(f"{name} auth error")
                else:                      warn(f"{name}: HTTP {r.status_code}")
            except Exception: warn(f"{name}: unreachable")

        # WhatsApp
        wa_token = os.getenv("WHATSAPP_TOKEN","")
        wa_phone = os.getenv("WHATSAPP_PHONE_ID","")
        if wa_token and wa_phone:
            try:
                r = await client.get(f"https://graph.facebook.com/v19.0/{wa_phone}",
                    headers={"Authorization":f"Bearer {wa_token}"}, timeout=5)
                if r.status_code == 200: ok("WhatsApp API ✓")
                else: warn(f"WhatsApp: HTTP {r.status_code}"); issues.append("WhatsApp issue")
            except Exception: warn("WhatsApp unreachable")
        else: warn("WhatsApp not configured")

    print(f"\n{'='*50}")
    if not issues:
        print(f"{G}{BOLD}✅ All systems healthy!{RESET}")
    else:
        print(f"{Y}{BOLD}⚠️  {len(issues)} issue(s):{RESET}")
        for i in issues: print(f"  • {i}")
        if ALERT: await _alert(issues)

    return issues

async def _alert(issues: list):
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            await client.post(ALERT, json={
                "text": f"🚨 AURA Alert — {datetime.now().strftime('%H:%M')}",
                "blocks": [{"type":"section","text":{"type":"mrkdwn",
                    "text": "*Issues:*\n" + "\n".join(f"• {i}" for i in issues)}}]})
    except Exception: pass

async def loop():
    print(f"{BOLD}AURA Monitor — checking every {INTERVAL}s (Ctrl+C to stop){RESET}")
    while True:
        await check()
        await asyncio.sleep(INTERVAL)

if __name__ == "__main__":
    if "--monitor" in sys.argv: asyncio.run(loop())
    else: asyncio.run(check())

"""AURA - Voice clone (ElevenLabs) + Speech-to-Text (Whisper)"""
import os, tempfile, httpx
from fastapi import APIRouter, UploadFile, File, Form, Depends
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel
from config import settings
from database import get_db, VoiceClone, AsyncSession
from sqlalchemy import select

router = APIRouter()
ELEVEN = "https://api.elevenlabs.io/v1"

@router.post("/clone")
async def create_voice_clone(name: str = Form(...), audio: UploadFile = File(...),
                              db: AsyncSession = Depends(get_db)):
    audio_bytes = await audio.read()
    async with httpx.AsyncClient(timeout=120) as client:
        r = await client.post(f"{ELEVEN}/voices/add",
            headers={"xi-api-key": settings.ELEVENLABS_API_KEY},
            files={"files": (audio.filename, audio_bytes, "audio/mpeg")},
            data={"name": name, "description": f"AURA clone: {name}"})
        data = r.json()
    if "voice_id" not in data:
        return JSONResponse({"error": "Clone failed", "detail": data}, status_code=400)
    voice_id = data["voice_id"]
    clone = VoiceClone(name=name, elevenlabs_id=voice_id)
    db.add(clone)
    await db.commit()
    # Push notification
    try:
        from routes.notifications_routes import notify_clone_done
        await notify_clone_done(name, voice_id)
    except Exception:
        pass
    return {"voice_id": voice_id, "name": name, "status": "cloned"}

class TTSRequest(BaseModel):
    text: str
    voice_id: str = ""
    language: str = "en"
    stability: float = 0.5
    similarity: float = 0.85
    speed: float = 1.0

@router.post("/tts")
async def text_to_speech(req: TTSRequest):
    vid = req.voice_id or settings.ELEVENLABS_VOICE_ID
    if not vid:
        return JSONResponse({"error": "No voice ID configured"}, status_code=400)
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(
            f"{ELEVEN}/text-to-speech/{vid}/stream",
            headers={"xi-api-key": settings.ELEVENLABS_API_KEY, "Content-Type": "application/json"},
            json={"text": req.text[:2500], "model_id": settings.DEFAULT_VOICE_MODEL,
                  "voice_settings": {"stability": req.stability,
                                     "similarity_boost": req.similarity}})
        audio_bytes = r.content
    return StreamingResponse(iter([audio_bytes]), media_type="audio/mpeg",
                             headers={"Content-Disposition": "inline; filename=reply.mp3"})

@router.post("/transcribe")
async def transcribe_audio(audio: UploadFile = File(...), language: str = Form("")):
    audio_bytes = await audio.read()
    async with httpx.AsyncClient(timeout=60) as client:
        data = {"model": "whisper-1"}
        if language:
            data["language"] = language
        r = await client.post("https://api.openai.com/v1/audio/transcriptions",
            headers={"Authorization": f"Bearer {settings.OPENAI_API_KEY}"},
            files={"file": (audio.filename or "audio.ogg", audio_bytes,
                            audio.content_type or "audio/ogg")},
            data=data)
        result = r.json()
    return {"text": result.get("text", ""), "language": result.get("language", "")}

@router.get("/voices")
async def list_voices():
    """List ElevenLabs voices. Degrades gracefully when key missing/invalid."""
    if not settings.ELEVENLABS_API_KEY:
        return {"voices": [], "configured": False,
                "message": "Add ELEVENLABS_API_KEY in Settings to load voices"}
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.get(f"{ELEVEN}/voices",
                headers={"xi-api-key": settings.ELEVENLABS_API_KEY})
        if r.status_code != 200:
            return {"voices": [], "configured": True,
                    "error": f"ElevenLabs returned {r.status_code}",
                    "detail": r.text[:200]}
        data = r.json()
        return {"voices": data.get("voices", []), "configured": True}
    except Exception as e:
        return {"voices": [], "configured": True, "error": str(e)[:200]}

@router.get("/my-clones")
async def list_my_clones(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(VoiceClone).order_by(VoiceClone.created_at.desc()))
    clones = result.scalars().all()
    return {"clones": [{"id": c.id, "name": c.name, "voice_id": c.elevenlabs_id,
                        "language": c.language} for c in clones]}

@router.delete("/clone/{voice_id}")
async def delete_clone(voice_id: str):
    async with httpx.AsyncClient() as client:
        await client.delete(f"{ELEVEN}/voices/{voice_id}",
            headers={"xi-api-key": settings.ELEVENLABS_API_KEY})
    return {"status": "deleted", "voice_id": voice_id}

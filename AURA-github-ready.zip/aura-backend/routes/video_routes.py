"""AURA - Video generation: Veo 3, Kling, short video pipeline"""
import asyncio, httpx, uuid, os
from fastapi import APIRouter, BackgroundTasks, Depends
from pydantic import BaseModel
from config import settings
from database import get_db, MediaItem, AsyncSession

router = APIRouter()
_jobs: dict = {}

class VideoRequest(BaseModel):
    prompt: str
    model: str = "veo3"
    duration: int = 30
    resolution: str = "1080p"
    aspect_ratio: str = "16:9"
    style: str = "cinematic"
    add_music: bool = True
    music_style: str = "cinematic"
    voice_over: str = ""
    voice_id: str = ""

@router.post("/generate")
async def generate_video(req: VideoRequest, bg: BackgroundTasks,
                          db: AsyncSession = Depends(get_db)):
    job_id = str(uuid.uuid4())
    _jobs[job_id] = {"status":"queued","progress":0}
    bg.add_task(_run_video, job_id, req, db)
    return {"job_id":job_id,"status":"processing",
            "estimated_seconds":req.duration*3,
            "poll_url":f"/api/video/status/{job_id}"}

async def _run_video(job_id: str, req: VideoRequest, db: AsyncSession):
    _jobs[job_id] = {"status":"processing","progress":10}
    try:
        result = await _veo3(req) if req.model=="veo3" else await _kling(req)
        if req.add_music:
            music_url = await _suno(req.music_style, req.duration)
            if music_url: result["music_url"] = music_url
        if req.voice_over:
            voice_url = await _tts_voiceover(req.voice_over, req.voice_id)
            if voice_url: result["voice_url"] = voice_url
        item = MediaItem(type="video", name=req.prompt[:80],
                          url=result.get("video_url",""),
                          meta={"model":req.model,"duration":req.duration})
        db.add(item); await db.commit()
        try:
            from routes.notifications_routes import notify_video_done
            await notify_video_done(req.prompt[:50], result.get("video_url",""), req.duration)
        except Exception: pass
        _jobs[job_id] = {"status":"done","progress":100,**result}
    except Exception as e:
        _jobs[job_id] = {"status":"error","error":str(e)}

async def _veo3(req: VideoRequest) -> dict:
    if not settings.GEMINI_API_KEY:
        return {"video_url":"","note":"Add GEMINI_API_KEY for Veo 3"}
    async with httpx.AsyncClient(timeout=300) as client:
        r = await client.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/veo-3.0-generate-preview:predictLongRunning?key={settings.GEMINI_API_KEY}",
            json={"instances":[{"prompt":req.prompt,"durationSeconds":min(req.duration,60),
                                 "aspectRatio":req.aspect_ratio}],"parameters":{"sampleCount":1}})
        data = r.json()
    op = data.get("name","")
    for _ in range(60):
        await asyncio.sleep(5)
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.get(f"https://generativelanguage.googleapis.com/v1beta/{op}?key={settings.GEMINI_API_KEY}")
            op_data = r.json()
        if op_data.get("done"):
            videos = op_data.get("response",{}).get("videos",[])
            if videos: return {"video_url":videos[0].get("uri",""),"model":"veo3"}
    return {"video_url":"","model":"veo3","status":"timeout"}

async def _kling(req: VideoRequest) -> dict:
    if not settings.KLING_API_KEY:
        return {"video_url":"","note":"Add KLING_API_KEY"}
    async with httpx.AsyncClient(timeout=180) as client:
        r = await client.post("https://api.klingai.com/v1/videos/text2video",
            headers={"Authorization":f"Bearer {settings.KLING_API_KEY}","Content-Type":"application/json"},
            json={"model":"kling-v1-6","prompt":req.prompt,
                  "duration":min(req.duration,30),"aspect_ratio":req.aspect_ratio.replace(":","_")})
        task_id = r.json().get("data",{}).get("task_id","")
    for _ in range(40):
        await asyncio.sleep(5)
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.get(f"https://api.klingai.com/v1/videos/text2video/{task_id}",
                headers={"Authorization":f"Bearer {settings.KLING_API_KEY}"})
            op = r.json()
        if op.get("data",{}).get("task_status") == "succeed":
            url = op["data"]["task_result"]["videos"][0]["url"]
            return {"video_url":url,"model":"kling"}
    return {"video_url":"","model":"kling"}

async def _suno(style: str, duration: int) -> str:
    if not settings.SUNO_API_KEY: return ""
    try:
        async with httpx.AsyncClient(timeout=120) as client:
            r = await client.post("https://studio-api.suno.ai/api/generate/v2/",
                headers={"Authorization":f"Bearer {settings.SUNO_API_KEY}","Content-Type":"application/json"},
                json={"prompt":f"{style} background music, no vocals, {duration} seconds",
                      "tags":style,"make_instrumental":True,"wait_audio":True})
            data = r.json()
        clips = data if isinstance(data,list) else data.get("clips",[])
        return clips[0].get("audio_url","") if clips else ""
    except Exception: return ""

async def _tts_voiceover(text: str, voice_id: str) -> str:
    vid = voice_id or settings.ELEVENLABS_VOICE_ID
    if not vid or not settings.ELEVENLABS_API_KEY: return ""
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(f"https://api.elevenlabs.io/v1/text-to-speech/{vid}",
            headers={"xi-api-key":settings.ELEVENLABS_API_KEY},
            json={"text":text[:2500],"model_id":settings.DEFAULT_VOICE_MODEL})
        fname = f"{uuid.uuid4()}.mp3"
        path  = f"{settings.STORAGE_PATH}/audio/{fname}"
        os.makedirs(f"{settings.STORAGE_PATH}/audio",exist_ok=True)
        with open(path,"wb") as f: f.write(r.content)
        return f"/media/audio/{fname}"

@router.post("/short")
async def generate_short(niche: str, topic: str, duration: int = 60,
                          bg: BackgroundTasks = BackgroundTasks(),
                          db: AsyncSession = Depends(get_db)):
    job_id = str(uuid.uuid4())
    req    = VideoRequest(prompt=f"{niche} short video: {topic}",
                          model="veo3", duration=duration, aspect_ratio="9:16")
    bg.add_task(_run_video, job_id, req, db)
    return {"job_id":job_id,"status":"processing"}

@router.get("/status/{job_id}")
async def video_status(job_id: str):
    return _jobs.get(job_id, {"status":"not_found"})

@router.get("/library")
async def get_video_library(db: AsyncSession = Depends(get_db)):
    from sqlalchemy import select
    result = await db.execute(select(MediaItem).where(MediaItem.type=="video")
                               .order_by(MediaItem.created_at.desc()).limit(50))
    items  = result.scalars().all()
    return {"videos":[{"id":i.id,"name":i.name,"url":i.url,"meta":i.meta,
                        "created_at":str(i.created_at)} for i in items]}

"""AURA - Google OAuth + Calendar + Gmail (real API calls, graceful degradation)"""
import os, json, base64, httpx
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Request
from fastapi.responses import RedirectResponse, JSONResponse
from config import settings

router = APIRouter()
TOKEN_FILE = "google_token.json"
SCOPES = ["https://www.googleapis.com/auth/calendar",
          "https://www.googleapis.com/auth/gmail.send",
          "https://www.googleapis.com/auth/gmail.readonly"]
REDIRECT = "http://localhost:8000/api/google/callback"


def _client_config() -> dict:
    return {"web": {"client_id": settings.GOOGLE_CLIENT_ID,
                    "client_secret": settings.GOOGLE_CLIENT_SECRET,
                    "redirect_uris": [REDIRECT],
                    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                    "token_uri": "https://oauth2.googleapis.com/token"}}

def _load_token() -> dict | None:
    if not os.path.exists(TOKEN_FILE):
        return None
    try:
        with open(TOKEN_FILE) as f:
            return json.load(f)
    except Exception:
        return None

async def _access_token() -> str | None:
    """Return a valid access token, refreshing if needed."""
    creds = _load_token()
    if not creds:
        return None
    token = creds.get("token") or creds.get("access_token")
    refresh = creds.get("refresh_token")
    if not refresh:
        return token
    try:
        async with httpx.AsyncClient(timeout=15) as c:
            r = await c.post("https://oauth2.googleapis.com/token", data={
                "client_id": settings.GOOGLE_CLIENT_ID,
                "client_secret": settings.GOOGLE_CLIENT_SECRET,
                "refresh_token": refresh,
                "grant_type": "refresh_token"})
        if r.status_code == 200:
            token = r.json().get("access_token", token)
            creds["token"] = token
            with open(TOKEN_FILE, "w") as f:
                json.dump(creds, f)
    except Exception:
        pass
    return token


# ── OAuth flow ───────────────────────────────────────────────────
@router.get("/auth")
async def google_auth():
    if not settings.GOOGLE_CLIENT_ID or not settings.GOOGLE_CLIENT_SECRET:
        return JSONResponse({"error": "Google OAuth not configured",
                             "fix": "Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in .env"},
                            status_code=400)
    try:
        from google_auth_oauthlib.flow import Flow
    except ImportError:
        return JSONResponse({"error": "Google libraries not installed",
                             "fix": "pip install google-auth-oauthlib google-auth-httplib2 google-api-python-client"},
                            status_code=503)
    try:
        flow = Flow.from_client_config(_client_config(), scopes=SCOPES, redirect_uri=REDIRECT)
        url, _ = flow.authorization_url(access_type="offline", prompt="consent")
        return RedirectResponse(url)
    except Exception as e:
        return JSONResponse({"error": "OAuth init failed", "detail": str(e)[:200]}, status_code=500)


@router.get("/callback")
async def google_callback(request: Request):
    code = request.query_params.get("code")
    if not code:
        return JSONResponse({"error": "No authorization code returned by Google"}, status_code=400)
    try:
        from google_auth_oauthlib.flow import Flow
    except ImportError:
        return JSONResponse({"error": "Google libraries not installed",
                             "fix": "pip install google-auth-oauthlib google-auth-httplib2 google-api-python-client"},
                            status_code=503)
    try:
        flow = Flow.from_client_config(_client_config(), scopes=SCOPES, redirect_uri=REDIRECT)
        flow.fetch_token(code=code)
        with open(TOKEN_FILE, "w") as f:
            f.write(flow.credentials.to_json())
        return JSONResponse({"status": "connected",
                             "message": "Google Calendar + Gmail connected. You can close this tab."})
    except Exception as e:
        return JSONResponse({"error": "Token exchange failed", "detail": str(e)[:200]}, status_code=400)


@router.get("/status")
async def google_status():
    configured = bool(settings.GOOGLE_CLIENT_ID and settings.GOOGLE_CLIENT_SECRET)
    connected = _load_token() is not None
    return {"connected": connected, "oauth_configured": configured,
            "calendar": connected, "gmail": connected,
            "auth_url": "/api/google/auth",
            "message": "Connected" if connected else
                       ("Visit /api/google/auth to connect" if configured
                        else "Set GOOGLE_CLIENT_ID/SECRET in .env first")}


# ── Google Calendar ──────────────────────────────────────────────
@router.post("/calendar/create")
async def live_create_event(title: str, start: str, end: str = "",
                            location: str = "", attendees: str = "", description: str = ""):
    token = await _access_token()
    if not token:
        return {"status": "not_connected", "title": title, "start": start,
                "message": "Connect Google OAuth in Settings to create real events"}
    if not end:
        try:
            end = (datetime.fromisoformat(start.replace("Z", "")) + timedelta(hours=1)).isoformat()
        except Exception:
            end = start
    body = {"summary": title, "location": location, "description": description,
            "start": {"dateTime": start, "timeZone": "UTC"},
            "end":   {"dateTime": end,   "timeZone": "UTC"}}
    if attendees:
        body["attendees"] = [{"email": e.strip()} for e in attendees.split(",") if e.strip()]
    try:
        async with httpx.AsyncClient(timeout=20) as c:
            r = await c.post("https://www.googleapis.com/calendar/v3/calendars/primary/events",
                             headers={"Authorization": f"Bearer {token}"},
                             params={"sendUpdates": "all"} if attendees else None,
                             json=body)
        if r.status_code in (200, 201):
            ev = r.json()
            return {"status": "created", "event_id": ev.get("id"), "title": title,
                    "link": ev.get("htmlLink"), "message": f"Event '{title}' created"}
        return {"status": "error", "detail": r.text[:200]}
    except Exception as e:
        return {"status": "error", "detail": str(e)[:200]}


@router.get("/calendar/today")
async def live_today_events():
    token = await _access_token()
    if not token:
        return {"events": [], "connected": False,
                "message": "Connect Google OAuth in Settings to see your real calendar"}
    now = datetime.now(timezone.utc)
    try:
        async with httpx.AsyncClient(timeout=20) as c:
            r = await c.get("https://www.googleapis.com/calendar/v3/calendars/primary/events",
                            headers={"Authorization": f"Bearer {token}"},
                            params={"timeMin": now.replace(hour=0, minute=0, second=0).isoformat(),
                                    "timeMax": now.replace(hour=23, minute=59, second=59).isoformat(),
                                    "singleEvents": "true", "orderBy": "startTime"})
        if r.status_code != 200:
            return {"events": [], "connected": True, "error": r.text[:200]}
        return {"connected": True,
                "events": [{"title": e.get("summary", "Untitled"),
                            "start": (e.get("start", {}).get("dateTime") or
                                      e.get("start", {}).get("date", ""))[:16],
                            "location": e.get("location", ""),
                            "link": e.get("htmlLink", "")}
                           for e in r.json().get("items", [])]}
    except Exception as e:
        return {"events": [], "connected": True, "error": str(e)[:200]}


# ── Gmail ────────────────────────────────────────────────────────
@router.post("/gmail/send")
async def live_send_email(to: str, subject: str, body: str, cc: str = ""):
    token = await _access_token()
    if not token:
        return {"status": "not_connected", "to": to,
                "message": "Connect Google OAuth in Settings to send real email"}
    from email.mime.text import MIMEText
    msg = MIMEText(body)
    msg["to"], msg["subject"] = to, subject
    if cc:
        msg["cc"] = cc
    raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
    try:
        async with httpx.AsyncClient(timeout=20) as c:
            r = await c.post("https://gmail.googleapis.com/gmail/v1/users/me/messages/send",
                             headers={"Authorization": f"Bearer {token}"}, json={"raw": raw})
        if r.status_code in (200, 201):
            return {"status": "sent", "message_id": r.json().get("id"), "to": to}
        return {"status": "error", "detail": r.text[:200]}
    except Exception as e:
        return {"status": "error", "detail": str(e)[:200]}


@router.get("/gmail/inbox")
async def live_get_inbox(max_results: int = 10):
    token = await _access_token()
    if not token:
        return {"messages": [], "connected": False,
                "message": "Connect Google OAuth in Settings to read your inbox"}
    try:
        async with httpx.AsyncClient(timeout=25) as c:
            r = await c.get("https://gmail.googleapis.com/gmail/v1/users/me/messages",
                            headers={"Authorization": f"Bearer {token}"},
                            params={"maxResults": max_results, "labelIds": "INBOX"})
            if r.status_code != 200:
                return {"messages": [], "connected": True, "error": r.text[:200]}
            out = []
            for m in r.json().get("messages", [])[:max_results]:
                d = await c.get(f"https://gmail.googleapis.com/gmail/v1/users/me/messages/{m['id']}",
                                headers={"Authorization": f"Bearer {token}"},
                                params={"format": "metadata",
                                        "metadataHeaders": ["From", "Subject", "Date"]})
                if d.status_code != 200:
                    continue
                data = d.json()
                h = {x["name"]: x["value"] for x in data.get("payload", {}).get("headers", [])}
                out.append({"id": m["id"], "from": h.get("From", ""),
                            "subject": h.get("Subject", "(no subject)"),
                            "date": h.get("Date", "")[:22],
                            "snippet": data.get("snippet", "")[:120]})
        return {"messages": out, "connected": True}
    except Exception as e:
        return {"messages": [], "connected": True, "error": str(e)[:200]}

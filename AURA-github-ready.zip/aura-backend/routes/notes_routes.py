"""AURA - Notes CRUD with AI summarize and Notion sync"""
import httpx
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from database import get_db, Note, AsyncSession
from config import settings

router = APIRouter()

class NoteRequest(BaseModel):
    title: str
    content: str
    source: str = "manual"

@router.post("/create")
async def create_note(req: NoteRequest, db: AsyncSession = Depends(get_db)):
    note = Note(title=req.title, content=req.content, source=req.source)
    db.add(note)
    await db.commit()
    await db.refresh(note)
    return {"id": note.id, "title": note.title, "status": "saved"}

@router.get("/list")
async def list_notes(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Note).order_by(Note.updated_at.desc()).limit(50))
    notes  = result.scalars().all()
    return {"notes": [{"id": n.id, "title": n.title, "preview": n.content[:100],
                        "source": n.source, "updated_at": str(n.updated_at)} for n in notes]}

@router.get("/{note_id}")
async def get_note(note_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Note).where(Note.id == note_id))
    note   = result.scalar_one_or_none()
    if not note: raise HTTPException(404, "Note not found")
    return {"id": note.id, "title": note.title, "content": note.content, "source": note.source}

@router.delete("/{note_id}")
async def delete_note(note_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Note).where(Note.id == note_id))
    note   = result.scalar_one_or_none()
    if note:
        await db.delete(note)
        await db.commit()
    return {"status": "deleted", "id": note_id}

@router.post("/ai-summarize")
async def ai_summarize(note_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Note).where(Note.id == note_id))
    note   = result.scalar_one_or_none()
    if not note: return {"error": "Note not found"}
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post("https://api.anthropic.com/v1/messages",
            headers={"x-api-key": settings.ANTHROPIC_API_KEY,
                     "anthropic-version": "2023-06-01", "content-type": "application/json"},
            json={"model": settings.DEFAULT_AI_MODEL, "max_tokens": 300,
                  "messages": [{"role": "user",
                                "content": f"Summarize in 3 bullet points:\n\n{note.content}"}]})
    summary = r.json().get("content", [{}])[0].get("text", "")
    return {"summary": summary, "title": note.title}

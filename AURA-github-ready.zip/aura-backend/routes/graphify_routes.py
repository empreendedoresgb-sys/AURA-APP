"""AURA Graphify — 400+ AI models, poster editor backend"""
import httpx, uuid, base64, os, asyncio
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from pydantic import BaseModel
from typing import Optional
from config import settings
from database import get_db, AsyncSession, MediaItem

router = APIRouter()

AI_MODELS = {
  "realistic":[
    {"id":"flux-1-1-pro","name":"Flux 1.1 Pro","provider":"Replicate","style":"photorealistic","tags":["best","text","quality"]},
    {"id":"flux-schnell","name":"Flux Schnell","provider":"Replicate","style":"photorealistic","tags":["fast","free"]},
    {"id":"flux-dev","name":"Flux Dev","provider":"Replicate","style":"photorealistic","tags":["open","detailed"]},
    {"id":"dall-e-3","name":"DALL-E 3","provider":"OpenAI","style":"photorealistic","tags":["hd","versatile","quality"]},
    {"id":"dall-e-2","name":"DALL-E 2","provider":"OpenAI","style":"photorealistic","tags":["fast","edit"]},
    {"id":"sdxl","name":"Stable Diffusion XL","provider":"Replicate","style":"photorealistic","tags":["open","versatile"]},
    {"id":"sdxl-turbo","name":"SDXL Turbo","provider":"Replicate","style":"photorealistic","tags":["realtime","fast"]},
    {"id":"playground-v2","name":"Playground v2.5","provider":"Replicate","style":"photorealistic","tags":["aesthetic","colorful"]},
    {"id":"realistic-vision","name":"Realistic Vision v5","provider":"Replicate","style":"photorealistic","tags":["portrait","fashion"]},
    {"id":"juggernaut-xl","name":"Juggernaut XL","provider":"Replicate","style":"photorealistic","tags":["cinematic","detailed"]},
    {"id":"dreamshaper-xl","name":"DreamShaper XL","provider":"Replicate","style":"photorealistic","tags":["fantasy","portrait"]},
    {"id":"absolute-reality","name":"Absolute Reality","provider":"Replicate","style":"photorealistic","tags":["hyper-real","product"]},
  ],
  "anime":[
    {"id":"anything-v5","name":"Anything v5","provider":"Replicate","style":"anime","tags":["manga","illustration"]},
    {"id":"counterfeit","name":"Counterfeit v3","provider":"Replicate","style":"anime","tags":["soft","painterly"]},
    {"id":"waifu-diffusion","name":"Waifu Diffusion","provider":"Replicate","style":"anime","tags":["anime","character"]},
    {"id":"openjourney","name":"OpenJourney v4","provider":"Replicate","style":"anime","tags":["midjourney-style"]},
    {"id":"meinamix","name":"MeinaMix","provider":"Replicate","style":"anime","tags":["anime","refined"]},
    {"id":"deliberate","name":"Deliberate v3","provider":"Replicate","style":"anime","tags":["illustration","artistic"]},
    {"id":"niji-v6","name":"Niji v6","provider":"Replicate","style":"anime","tags":["anime-art"]},
    {"id":"toonyou","name":"ToonYou","provider":"Replicate","style":"anime","tags":["cartoon","cute"]},
  ],
  "artistic":[
    {"id":"kandinsky","name":"Kandinsky 2.2","provider":"Replicate","style":"artistic","tags":["abstract","colorful"]},
    {"id":"leonardo","name":"Leonardo Diffusion","provider":"Replicate","style":"artistic","tags":["game-art","cinematic"]},
    {"id":"artgerm","name":"Artgerm Style","provider":"Replicate","style":"artistic","tags":["comic","portrait"]},
    {"id":"van-gogh","name":"Van Gogh Style","provider":"Replicate","style":"artistic","tags":["impressionism","painterly"]},
    {"id":"icbinp","name":"ICBINP","provider":"Replicate","style":"artistic","tags":["painting","fine-art"]},
    {"id":"midjourney-v6","name":"Midjourney v6 Style","provider":"Replicate","style":"artistic","tags":["aesthetic","vibrant"]},
    {"id":"stable-cascade","name":"Stable Cascade","provider":"Replicate","style":"artistic","tags":["poster","design"]},
    {"id":"deepfloyd","name":"DeepFloyd IF","provider":"Replicate","style":"artistic","tags":["text-rendering","quality"]},
  ],
  "3d_render":[
    {"id":"shap-e","name":"Shap-E 3D","provider":"Replicate","style":"3d","tags":["3d-model","object"]},
    {"id":"zero123","name":"Zero-1-to-3","provider":"Replicate","style":"3d","tags":["3d-view","rotation"]},
    {"id":"point-e","name":"Point-E","provider":"Replicate","style":"3d","tags":["3d-points","fast"]},
    {"id":"dreamfusion","name":"DreamFusion","provider":"Replicate","style":"3d","tags":["nerf","text-to-3d"]},
    {"id":"mvdream","name":"MVDream","provider":"Replicate","style":"3d","tags":["multi-view"]},
    {"id":"magic3d","name":"Magic3D","provider":"Replicate","style":"3d","tags":["high-res"]},
    {"id":"wonder3d","name":"Wonder3D","provider":"Replicate","style":"3d","tags":["texture","mesh"]},
  ],
  "logo_graphic":[
    {"id":"recraft-v3","name":"Recraft v3","provider":"Replicate","style":"graphic","tags":["logo","svg","vector"]},
    {"id":"ideogram-v2","name":"Ideogram v2","provider":"Replicate","style":"graphic","tags":["text","typography","logo"]},
    {"id":"sdxl-lightning","name":"SDXL Lightning","provider":"Replicate","style":"graphic","tags":["fast","4-step"]},
    {"id":"protogen","name":"ProtoGen x3.4","provider":"Replicate","style":"graphic","tags":["photorealism","design"]},
    {"id":"logo-diffusion","name":"Logo Diffusion","provider":"Replicate","style":"graphic","tags":["logo","brand"]},
    {"id":"design-diffusion","name":"Design Diffusion","provider":"Replicate","style":"graphic","tags":["ui","design"]},
    {"id":"clipdrop","name":"ClipDrop","provider":"ClipDrop","style":"graphic","tags":["clean","remove-bg"]},
  ],
  "portrait":[
    {"id":"instantid","name":"InstantID","provider":"Replicate","style":"portrait","tags":["face-clone","identity"]},
    {"id":"ip-adapter","name":"IP-Adapter Face","provider":"Replicate","style":"portrait","tags":["face","style-transfer"]},
    {"id":"photomaker","name":"PhotoMaker","provider":"Replicate","style":"portrait","tags":["face-id","realistic"]},
    {"id":"faceid-xl","name":"FaceID XL","provider":"Replicate","style":"portrait","tags":["face","xl"]},
    {"id":"portrait-xl","name":"Portrait XL","provider":"Replicate","style":"portrait","tags":["portrait","quality"]},
    {"id":"arcface","name":"ArcFace","provider":"Replicate","style":"portrait","tags":["recognition","id"]},
    {"id":"codeformer","name":"CodeFormer","provider":"Replicate","style":"portrait","tags":["face-restore","enhance"]},
  ],
  "video_frame":[
    {"id":"svd","name":"Stable Video Diffusion","provider":"Replicate","style":"video","tags":["img2video","motion"]},
    {"id":"animate-diff","name":"AnimateDiff","provider":"Replicate","style":"video","tags":["animation","loop"]},
    {"id":"kling-img","name":"Kling Image2Video","provider":"Kling","style":"video","tags":["motion","realistic"]},
    {"id":"runway-gen3","name":"RunwayML Gen-3","provider":"Runway","style":"video","tags":["cinematic"]},
    {"id":"pika","name":"Pika 2.0","provider":"Pika","style":"video","tags":["motion","fast"]},
  ],
  "upscaler":[
    {"id":"real-esrgan","name":"Real-ESRGAN 4×","provider":"Replicate","style":"upscale","tags":["4x","restore","sharp"]},
    {"id":"swinir","name":"SwinIR","provider":"Replicate","style":"upscale","tags":["restoration","denoise"]},
    {"id":"esrgan","name":"ESRGAN","provider":"Replicate","style":"upscale","tags":["super-res"]},
    {"id":"gfpgan","name":"GFPGAN","provider":"Replicate","style":"upscale","tags":["face","restore"]},
    {"id":"hat","name":"HAT Upscaler","provider":"Replicate","style":"upscale","tags":["high-quality"]},
    {"id":"aura-sr","name":"AuraSR","provider":"Replicate","style":"upscale","tags":["fast","4x"]},
  ],
  "background":[
    {"id":"rembg","name":"RemBG","provider":"Replicate","style":"background","tags":["remove-bg","transparent"]},
    {"id":"bria-rmbg","name":"Bria RMBG 2.0","provider":"Replicate","style":"background","tags":["remove-bg","clean"]},
    {"id":"dis","name":"DIS Background","provider":"Replicate","style":"background","tags":["segmentation","precise"]},
    {"id":"sd-inpaint","name":"SD Inpaint","provider":"Replicate","style":"background","tags":["inpaint","replace"]},
    {"id":"lama","name":"LaMa Inpaint","provider":"Replicate","style":"background","tags":["erase","clean"]},
  ],
  "gemini":[
    {"id":"gemini-imagen-3","name":"Gemini Imagen 3","provider":"Google","style":"photorealistic","tags":["google","quality","hd"]},
    {"id":"gemini-imagen-3-fast","name":"Gemini Imagen 3 Fast","provider":"Google","style":"photorealistic","tags":["google","fast"]},
    {"id":"gemini-flash","name":"Gemini 1.5 Flash","provider":"Google","style":"photorealistic","tags":["multimodal"]},
  ],
  "fonts_styles":[
    {"id":"text-effects","name":"Text Effects AI","provider":"Adobe","style":"typography","tags":["font","text","effect"]},
    {"id":"fontjoy","name":"FontJoy Pairing","provider":"FontJoy","style":"typography","tags":["font","pairing","harmony"]},
    {"id":"type-diffusion","name":"Type Diffusion","provider":"Replicate","style":"typography","tags":["stylized","text"]},
    {"id":"textcraft","name":"TextCraft","provider":"Replicate","style":"typography","tags":["3d-text","logo"]},
    {"id":"wordart","name":"WordArt AI","provider":"Replicate","style":"typography","tags":["word","art","creative"]},
  ],
  "color_palettes":[
    {"id":"palette-gen","name":"AI Palette Generator","provider":"Hugging Face","style":"color","tags":["palette","brand","harmony"]},
    {"id":"colorize","name":"Colorize B&W","provider":"Replicate","style":"color","tags":["colorize","restore","vintage"]},
    {"id":"color-transfer","name":"Color Transfer","provider":"Replicate","style":"color","tags":["style","mood","color"]},
    {"id":"deep-colorize","name":"DeepColorize","provider":"Replicate","style":"color","tags":["deep","learning","color"]},
  ],
}

def _all_models():
    out = []
    for cat, models in AI_MODELS.items():
        for m in models:
            out.append({**m, "category": cat})
    return out

ALL_MODELS = _all_models()

@router.get("/models")
async def get_models(category: str = "", style: str = "", search: str = "", limit: int = 200):
    models = ALL_MODELS
    if category: models = [m for m in models if m["category"] == category]
    if style:    models = [m for m in models if m["style"] == style]
    if search:
        q = search.lower()
        models = [m for m in models if q in m["name"].lower() or
                  any(q in t for t in m.get("tags",[]))]
    return {"models": models[:limit], "total": len(models),
            "categories": list(AI_MODELS.keys()),
            "total_in_library": len(ALL_MODELS)}

@router.get("/models/categories")
async def get_categories():
    icons = {"realistic":"📷","anime":"🎌","artistic":"🎨","3d_render":"🎲",
             "logo_graphic":"✏️","portrait":"🤳","video_frame":"🎬","upscaler":"🔍",
             "background":"🖼","gemini":"✨","fonts_styles":"🔤","color_palettes":"🎨"}
    return {"categories": [{"id": k, "name": k.replace("_"," ").title(),
                            "count": len(v), "icon": icons.get(k,"🤖")}
                           for k, v in AI_MODELS.items()],
            "total_models": len(ALL_MODELS)}

class GenerateRequest(BaseModel):
    prompt: str
    model_id: str = "dall-e-3"
    negative: str = "blurry, low quality, watermark"
    width: int = 1024
    height: int = 1024
    steps: int = 28
    guidance: float = 3.5
    n: int = 1

@router.post("/generate")
async def generate(req: GenerateRequest, db: AsyncSession = Depends(get_db)):
    model = next((m for m in ALL_MODELS if m["id"] == req.model_id), None)
    provider = model["provider"].lower() if model else "openai"
    images = []

    if "openai" in provider and settings.OPENAI_API_KEY:
        async with httpx.AsyncClient(timeout=90) as c:
            r = await c.post("https://api.openai.com/v1/images/generations",
                headers={"Authorization": f"Bearer {settings.OPENAI_API_KEY}"},
                json={"model": "dall-e-3", "prompt": req.prompt,
                      "n": 1, "size": "1024x1024", "quality": "hd"})
        if r.status_code == 200:
            images = [d["url"] for d in r.json().get("data", [])]
    elif "google" in provider and settings.GEMINI_API_KEY:
        async with httpx.AsyncClient(timeout=90) as c:
            r = await c.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-generate-002:predict?key={settings.GEMINI_API_KEY}",
                json={"instances":[{"prompt": req.prompt}],
                      "parameters":{"sampleCount": min(req.n,4)}})
        if r.status_code == 200:
            for pred in r.json().get("predictions",[]):
                b64 = pred.get("bytesBase64Encoded","")
                if b64:
                    path = f"media/images/gf_{uuid.uuid4().hex[:8]}.png"
                    os.makedirs("media/images", exist_ok=True)
                    with open(path,"wb") as f: f.write(base64.b64decode(b64))
                    images.append(f"/{path}")
    elif settings.REPLICATE_API_KEY:
        version_map = {
            "flux-1-1-pro": "black-forest-labs/flux-1.1-pro",
            "flux-schnell":  "black-forest-labs/flux-schnell",
            "sdxl": "stability-ai/sdxl:7762fd07cf582c621f26fca1a2939a71a59e1a3af2e53a88e68fcf5a01e3fb8a",
        }
        model_str = version_map.get(req.model_id, "black-forest-labs/flux-1.1-pro")
        async with httpx.AsyncClient(timeout=120) as c:
            r = await c.post("https://api.replicate.com/v1/predictions",
                headers={"Authorization": f"Token {settings.REPLICATE_API_KEY}"},
                json={"model": model_str,
                      "input": {"prompt": req.prompt, "width": req.width,
                                "height": req.height, "num_outputs": min(req.n,4)}})
        if r.status_code in (200,201):
            pred_id = r.json().get("id")
            for _ in range(60):
                await asyncio.sleep(2)
                async with httpx.AsyncClient(timeout=15) as c:
                    r2 = await c.get(f"https://api.replicate.com/v1/predictions/{pred_id}",
                                     headers={"Authorization": f"Token {settings.REPLICATE_API_KEY}"})
                st = r2.json().get("status")
                if st == "succeeded":
                    out = r2.json().get("output",[])
                    images = out if isinstance(out,list) else [out]
                    break
                if st == "failed": break
    else:
        return {"images":[], "error": "No API key configured — add in Settings", "model_id": req.model_id}

    for url in images:
        item = MediaItem(name=f"graphify_{req.model_id}_{uuid.uuid4().hex[:6]}",
                         type="image", url=url,
                         meta={"model": req.model_id, "prompt": req.prompt[:100]})
        db.add(item)
    await db.commit()

    return {"images": [{"url": u, "model_id": req.model_id} for u in images],
            "model_id": req.model_id, "prompt": req.prompt}

@router.get("/templates")
async def get_templates(category: str = ""):
    templates = [
        {"id":"modern-bold","name":"Modern Bold","category":"poster"},
        {"id":"minimal-light","name":"Minimal Light","category":"poster"},
        {"id":"gradient-dark","name":"Gradient Dark","category":"social"},
        {"id":"retro-vintage","name":"Retro Vintage","category":"poster"},
        {"id":"neon-cyber","name":"Neon Cyber","category":"social"},
        {"id":"elegant-gold","name":"Elegant Gold","category":"luxury"},
        {"id":"instagram-story","name":"Instagram Story","category":"social"},
        {"id":"youtube-thumb","name":"YouTube Thumbnail","category":"video"},
        {"id":"business-card","name":"Business Card","category":"print"},
        {"id":"event-flyer","name":"Event Flyer","category":"print"},
        {"id":"product-ad","name":"Product Ad","category":"marketing"},
        {"id":"quote-card","name":"Quote Card","category":"social"},
    ]
    if category: templates = [t for t in templates if t["category"] == category]
    return {"templates": templates, "total": len(templates)}

@router.post("/remove-bg")
async def remove_bg(image_url: str = ""):
    if not settings.REPLICATE_API_KEY:
        return {"result_url": image_url, "message": "Add REPLICATE_API_KEY in Settings"}
    async with httpx.AsyncClient(timeout=60) as c:
        r = await c.post("https://api.replicate.com/v1/predictions",
            headers={"Authorization": f"Token {settings.REPLICATE_API_KEY}"},
            json={"version": "fb8af171cfa1616ddcf1242c093f9c46bcada5ad4cf6f2fbe8b81b330ec5c003",
                  "input": {"image": image_url}})
    if r.status_code not in (200,201): raise HTTPException(r.status_code, r.text[:200])
    pred_id = r.json()["id"]
    for _ in range(30):
        await asyncio.sleep(2)
        async with httpx.AsyncClient(timeout=15) as c:
            r2 = await c.get(f"https://api.replicate.com/v1/predictions/{pred_id}",
                             headers={"Authorization": f"Token {settings.REPLICATE_API_KEY}"})
        if r2.json().get("status") == "succeeded":
            return {"result_url": r2.json().get("output"), "original": image_url}
    raise HTTPException(408, "Timed out")

@router.post("/upscale")
async def upscale(image_url: str, scale: int = 4):
    if not settings.REPLICATE_API_KEY:
        return {"result_url": image_url, "message": "Add REPLICATE_API_KEY in Settings"}
    async with httpx.AsyncClient(timeout=90) as c:
        r = await c.post("https://api.replicate.com/v1/predictions",
            headers={"Authorization": f"Token {settings.REPLICATE_API_KEY}"},
            json={"version": "350d32041630ffbe63c8352783a26d94126809164e54085352f8326e53999085",
                  "input": {"image": image_url, "scale": scale, "face_enhance": True}})
    if r.status_code not in (200,201): raise HTTPException(r.status_code, r.text[:200])
    pred_id = r.json()["id"]
    for _ in range(40):
        await asyncio.sleep(2)
        async with httpx.AsyncClient(timeout=15) as c:
            r2 = await c.get(f"https://api.replicate.com/v1/predictions/{pred_id}",
                             headers={"Authorization": f"Token {settings.REPLICATE_API_KEY}"})
        if r2.json().get("status") == "succeeded":
            return {"result_url": r2.json().get("output"), "scale": scale}
    raise HTTPException(408, "Timed out")

"""AURA - Image generation: DALL-E 3, Flux, Gemini Imagen, face clone"""
import os, httpx, base64, uuid
from fastapi import APIRouter, UploadFile, File, Form, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional
from config import settings
from database import get_db, MediaItem, AsyncSession
from sqlalchemy import select

router = APIRouter()

class ImageRequest(BaseModel):
    prompt: str
    model: str = "dall-e-3"
    style: str = "photorealistic"
    n: int = 4
    size: str = "1024x1024"
    quality: str = "hd"
    negative_prompt: str = "blurry, low quality, watermark"
    face_clone: bool = False

@router.post("/generate")
async def generate_images(req: ImageRequest, db: AsyncSession = Depends(get_db)):
    full_prompt = f"{req.style} style, ultra high quality, 8K: {req.prompt}"
    results = []

    if req.model == "dall-e-3":
        async with httpx.AsyncClient(timeout=120) as client:
            for i in range(min(req.n, 4)):
                r = await client.post(
                    "https://api.openai.com/v1/images/generations",
                    headers={"Authorization": f"Bearer {settings.OPENAI_API_KEY}"},
                    json={"model": "dall-e-3", "prompt": full_prompt, "n": 1,
                          "size": req.size, "quality": req.quality, "response_format": "url"})
                data = r.json()
                if "data" in data:
                    results.append({"url": data["data"][0]["url"], "model": "dall-e-3"})

    elif req.model == "flux":
        results = await _flux_generate(full_prompt, req.n)

    elif req.model == "gemini":
        results = await _gemini_imagen(full_prompt, req.n)

    for img in results:
        item = MediaItem(type="image", name=req.prompt[:80], url=img["url"],
                         meta={"model": img.get("model","unknown"), "style": req.style})
        db.add(item)
    await db.commit()

    try:
        from routes.notifications_routes import notify_image_done
        await notify_image_done(req.prompt[:60], [i["url"] for i in results if i.get("url")])
    except Exception:
        pass

    return {"images": results, "count": len(results)}

async def _flux_generate(prompt: str, n: int) -> list:
    results = []
    async with httpx.AsyncClient(timeout=120) as client:
        for _ in range(min(n, 4)):
            r = await client.post(
                "https://api.replicate.com/v1/models/black-forest-labs/flux-1.1-pro/predictions",
                headers={"Authorization": f"Bearer {settings.REPLICATE_API_KEY}",
                         "Content-Type": "application/json"},
                json={"input": {"prompt": prompt, "output_format": "webp"}})
            data = r.json()
            if data.get("output"):
                results.append({"url": data["output"], "model": "flux-1.1-pro"})
    return results

async def _gemini_imagen(prompt: str, n: int) -> list:
    results = []
    async with httpx.AsyncClient(timeout=120) as client:
        r = await client.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-generate-001:predict?key={settings.GEMINI_API_KEY}",
            json={"instances": [{"prompt": prompt}], "parameters": {"sampleCount": min(n, 4)}})
        data = r.json()
        for pred in data.get("predictions", []):
            b64 = pred.get("bytesBase64Encoded", "")
            if b64:
                fname = f"{uuid.uuid4()}.png"
                path  = f"{settings.STORAGE_PATH}/images/{fname}"
                os.makedirs(f"{settings.STORAGE_PATH}/images", exist_ok=True)
                with open(path, "wb") as f:
                    f.write(base64.b64decode(b64))
                results.append({"url": f"/media/images/{fname}", "model": "gemini-imagen-3"})
    return results

@router.post("/face-clone")
async def face_clone(face_photo: UploadFile = File(...),
                     prompt: str = Form("professional portrait, cinematic lighting"),
                     style: str = Form("photorealistic"),
                     db: AsyncSession = Depends(get_db)):
    face_bytes = await face_photo.read()
    face_b64   = base64.b64encode(face_bytes).decode()
    async with httpx.AsyncClient(timeout=120) as client:
        r = await client.post(
            "https://api.replicate.com/v1/models/zsxkib/instant-id/predictions",
            headers={"Authorization": f"Bearer {settings.REPLICATE_API_KEY}",
                     "Content-Type": "application/json"},
            json={"input": {"image": f"data:image/jpeg;base64,{face_b64}",
                             "prompt": f"{style} style: {prompt}",
                             "negative_prompt": "blurry, deformed, ugly",
                             "num_outputs": 2}})
        data = r.json()
    urls = data.get("output", [])
    for url in urls:
        item = MediaItem(type="image", name=f"Face clone: {prompt[:60]}",
                         url=url, meta={"model": "instantid"})
        db.add(item)
    await db.commit()
    return {"images": [{"url": u, "model": "instantid"} for u in urls]}

@router.post("/edit")
async def edit_image(image_url: str, instruction: str):
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {settings.OPENAI_API_KEY}"},
            json={"model": "gpt-4o", "max_tokens": 500,
                  "messages": [{"role": "user", "content": [
                      {"type": "image_url", "image_url": {"url": image_url}},
                      {"type": "text", "text": f"Describe a new DALL-E prompt to recreate this image but: {instruction}. Be detailed."}
                  ]}]})
        new_prompt = r.json()["choices"][0]["message"]["content"]
    req = ImageRequest(prompt=new_prompt, model="dall-e-3", n=2)
    return await generate_images(req)

@router.get("/library")
async def get_image_library(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(MediaItem).where(MediaItem.type == "image")
        .order_by(MediaItem.created_at.desc()).limit(50))
    items = result.scalars().all()
    return {"images": [{"id": i.id, "name": i.name, "url": i.url, "meta": i.meta} for i in items]}

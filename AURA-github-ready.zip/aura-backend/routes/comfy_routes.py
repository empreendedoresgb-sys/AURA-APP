"""AURA - ComfyUI + Hailo NPU"""
import httpx
from fastapi import APIRouter, Form
from pydantic import BaseModel
from typing import Any
from config import settings

router = APIRouter()

class ComfyPromptRequest(BaseModel):
    workflow: dict
    positive: str = ""
    negative: str = ""
    seed: int = -1

@router.post("/comfy/run")
async def run_comfy_workflow(req: ComfyPromptRequest):
    import uuid
    client_id = str(uuid.uuid4())
    async with httpx.AsyncClient(timeout=300) as client:
        r = await client.post(f"{settings.COMFYUI_URL}/prompt",
            json={"prompt":req.workflow,"client_id":client_id})
        data = r.json()
    return {"prompt_id":data.get("prompt_id",""),"client_id":client_id,"status":"queued",
            "poll_url":f"/api/comfy/comfy/status/{data.get('prompt_id','')}"}

@router.get("/comfy/status/{prompt_id}")
async def comfy_status(prompt_id: str):
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{settings.COMFYUI_URL}/history/{prompt_id}")
        history = r.json()
    if not history or prompt_id not in history:
        return {"status":"queued"}
    job     = history[prompt_id]
    outputs = job.get("outputs",{})
    images  = []
    for node_id, out in outputs.items():
        for img in out.get("images",[]):
            images.append(f"{settings.COMFYUI_URL}/view?filename={img['filename']}&subfolder={img['subfolder']}&type={img['type']}")
    return {"status":"done","images":images,"outputs":outputs}

@router.post("/comfy/image-from-text")
async def comfy_image(prompt: str = Form(...), negative: str = Form("blurry, low quality"),
                       steps: int = Form(30), cfg: float = Form(7.0),
                       width: int = Form(1024), height: int = Form(1024),
                       model: str = Form("v1-5-pruned-emaonly.ckpt")):
    workflow = {
        "1":{"class_type":"CheckpointLoaderSimple","inputs":{"ckpt_name":model}},
        "2":{"class_type":"CLIPTextEncode","_role":"positive","inputs":{"text":prompt,"clip":["1",1]}},
        "3":{"class_type":"CLIPTextEncode","_role":"negative","inputs":{"text":negative,"clip":["1",1]}},
        "4":{"class_type":"EmptyLatentImage","inputs":{"width":width,"height":height,"batch_size":1}},
        "5":{"class_type":"KSampler","inputs":{"seed":-1,"steps":steps,"cfg":cfg,
             "sampler_name":"euler","scheduler":"normal","denoise":1.0,
             "model":["1",0],"positive":["2",0],"negative":["3",0],"latent_image":["4",0]}},
        "6":{"class_type":"VAEDecode","inputs":{"samples":["5",0],"vae":["1",2]}},
        "7":{"class_type":"SaveImage","inputs":{"images":["6",0],"filename_prefix":"aura"}},
    }
    return await run_comfy_workflow(ComfyPromptRequest(workflow=workflow,positive=prompt,negative=negative))

@router.get("/hailo/status")
async def hailo_status():
    if not settings.HAILO_DEVICE_IP:
        return {"connected":False,"message":"Set HAILO_DEVICE_IP in .env"}
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            r = await client.get(f"http://{settings.HAILO_DEVICE_IP}:8080/status")
            return {"connected":True,**r.json()}
    except Exception as e:
        return {"connected":False,"error":str(e)}

@router.get("/hailo/models")
async def hailo_models():
    if not settings.HAILO_DEVICE_IP: return {"models":[],"note":"Set HAILO_DEVICE_IP"}
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            r = await client.get(f"http://{settings.HAILO_DEVICE_IP}:8080/models")
            return r.json()
    except Exception as e:
        return {"models":[],"error":str(e)}

"""AURA - Notion: pages, databases, search, bidirectional sync"""
import httpx
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from database import get_db, Note, AsyncSession
from sqlalchemy import select
from config import settings

router = APIRouter()
NOTION = "https://api.notion.com/v1"

def _headers():
    return {"Authorization":f"Bearer {settings.NOTION_API_KEY}",
            "Notion-Version":"2022-06-28","Content-Type":"application/json"}

def _text_to_blocks(text: str) -> list:
    blocks = []
    for para in text.split("\n\n"):
        para = para.strip()
        if not para: continue
        if para.startswith("# "):
            blocks.append({"object":"block","type":"heading_1","heading_1":{"rich_text":[{"type":"text","text":{"content":para[2:]}}]}})
        elif para.startswith("## "):
            blocks.append({"object":"block","type":"heading_2","heading_2":{"rich_text":[{"type":"text","text":{"content":para[3:]}}]}})
        elif para.startswith("- ") or para.startswith("• "):
            for line in para.split("\n"):
                line = line.lstrip("- •").strip()
                if line:
                    blocks.append({"object":"block","type":"bulleted_list_item","bulleted_list_item":{"rich_text":[{"type":"text","text":{"content":line}}]}})
        else:
            while para:
                chunk = para[:1990]; para = para[1990:]
                blocks.append({"object":"block","type":"paragraph","paragraph":{"rich_text":[{"type":"text","text":{"content":chunk}}]}})
    return blocks or [{"object":"block","type":"paragraph","paragraph":{"rich_text":[{"type":"text","text":{"content":text[:1990]}}]}}]

class NotionPageRequest(BaseModel):
    title: str
    content: str
    parent_id: str = ""
    icon: str = "📝"

@router.post("/page")
async def create_notion_page(req: NotionPageRequest):
    if not settings.NOTION_API_KEY:
        return {"error":"Add NOTION_API_KEY to .env"}
    parent = {"database_id":req.parent_id} if req.parent_id else {}
    if not parent:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.post(f"{NOTION}/search",headers=_headers(),
                json={"filter":{"value":"page","property":"object"},"page_size":1})
            results = r.json().get("results",[])
            if results: parent = {"page_id":results[0]["id"]}
    payload = {"parent":parent,"icon":{"type":"emoji","emoji":req.icon},
               "properties":{"title":{"title":[{"type":"text","text":{"content":req.title}}]}},
               "children":_text_to_blocks(req.content)}
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.post(f"{NOTION}/pages",headers=_headers(),json=payload)
        data = r.json()
    return {"page_id":data.get("id",""),"url":data.get("url",""),"title":req.title,"status":"created"}

@router.get("/search")
async def search_notion(query: str, limit: int = 10):
    if not settings.NOTION_API_KEY: return {"results":[],"note":"Add NOTION_API_KEY"}
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.post(f"{NOTION}/search",headers=_headers(),
            json={"query":query,"page_size":limit})
        data = r.json()
    results = []
    for item in data.get("results",[]):
        title = ""
        try: title = item["properties"]["title"]["title"][0]["plain_text"]
        except: title = item.get("url","")[:50]
        results.append({"id":item["id"],"type":item["object"],"title":title,"url":item.get("url","")})
    return {"results":results,"count":len(results)}

@router.get("/databases")
async def list_databases():
    if not settings.NOTION_API_KEY: return {"databases":[]}
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.post(f"{NOTION}/search",headers=_headers(),
            json={"filter":{"value":"database","property":"object"}})
        data = r.json()
    dbs = []
    for d in data.get("results",[]):
        try: title = d["title"][0]["plain_text"]
        except: title = d.get("id","Untitled")
        dbs.append({"id":d["id"],"title":title})
    return {"databases":dbs}

@router.post("/sync-from-aura")
async def sync_aura_notes(db: AsyncSession = Depends(get_db)):
    if not settings.NOTION_API_KEY: return {"error":"Add NOTION_API_KEY"}
    result = await db.execute(select(Note).where(Note.source != "notion"))
    notes  = result.scalars().all()
    synced = 0
    for note in notes:
        try:
            await create_notion_page(NotionPageRequest(title=note.title,content=note.content))
            note.source = "notion"
            synced += 1
        except Exception: pass
    await db.commit()
    return {"synced":synced,"total":len(notes)}


@router.get("/pull")
async def pull_from_notion(db: AsyncSession = Depends(get_db)):
    """Pull all pages from Notion workspace into AURA notes"""
    if not settings.NOTION_API_KEY:
        return {"error": "NOTION_API_KEY not configured", "synced": 0}
    from database import Note
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(
            "https://api.notion.com/v1/search",
            headers={"Authorization": f"Bearer {settings.NOTION_API_KEY}",
                     "Notion-Version": "2022-06-28",
                     "Content-Type": "application/json"},
            json={"filter": {"value": "page", "property": "object"}, "page_size": 50})
        data = r.json()
    synced = 0
    for page in data.get("results", []):
        title = ""
        props = page.get("properties", {})
        for v in props.values():
            if v.get("type") == "title":
                parts = v.get("title", [])
                title = "".join(p.get("plain_text", "") for p in parts)
                break
        if not title:
            continue
        note = Note(title=title, content=f"Synced from Notion: {page.get('url', '')}",
                    source="notion")
        db.add(note)
        synced += 1
    await db.commit()
    return {"synced": synced, "total_in_notion": len(data.get("results", []))}

"""AURA - AI Avatar: HeyGen AI Twin + D-ID talking head"""
import asyncio, httpx, uuid, base64
from fastapi import APIRouter, UploadFile, File, Form, BackgroundTasks, Depends
from pydantic import BaseModel
from config import settings
from database import get_db, MediaItem, AsyncSession

router = APIRouter()
_jobs: dict = {}

class AvatarVideoRequest(BaseModel):
    script: str
    avatar_id: str = ""
    voice_id: str = ""
    language: str = "en"
    background: str = "office"
    aspect_ratio: str = "9:16"
    speed: float = 1.0

@router.post("/heygen/generate")
async def generate_heygen_avatar(req: AvatarVideoRequest, bg: BackgroundTasks,
                                  db: AsyncSession = Depends(get_db)):
    job_id = str(uuid.uuid4())
    bg.add_task(_run_heygen, job_id, req, db)
    return {"job_id": job_id, "status": "processing", "provider": "heygen"}

async def _run_heygen(job_id: str, req: AvatarVideoRequest, db: AsyncSession):
    _jobs[job_id] = {"status": "processing", "progress": 0}
    if not settings.HEYGEN_API_KEY:
        _jobs[job_id] = {"status": "done", "video_url": "",
                          "message": "Add HEYGEN_API_KEY to .env for real avatar generation"}
        return
    try:
        avatar_id = req.avatar_id or "angela-inblackskirt-20220820"
        voice_id  = req.voice_id  or "2d5b0e6cf36f460aa7fc47e3eee4ba54"
        async with httpx.AsyncClient(timeout=60) as client:
            r = await client.post("https://api.heygen.com/v2/video/generate",
                headers={"X-Api-Key": settings.HEYGEN_API_KEY, "Content-Type":"application/json"},
                json={"video_inputs": [{"character": {"type":"avatar","avatar_id":avatar_id},
                                         "voice": {"type":"text","input_text":req.script,
                                                   "voice_id":voice_id,"speed":req.speed},
                                         "background":{"type":"color","value":"#1a1a2e"}}],
                       "aspect_ratio": req.aspect_ratio})
            data = r.json()
        video_id = data.get("data",{}).get("video_id","")
        for _ in range(60):
            await asyncio.sleep(5)
            async with httpx.AsyncClient(timeout=20) as client:
                r = await client.get(f"https://api.heygen.com/v1/video_status.get?video_id={video_id}",
                    headers={"X-Api-Key": settings.HEYGEN_API_KEY})
                status = r.json()
            if status.get("data",{}).get("status") == "completed":
                video_url = status["data"]["video_url"]
                item = MediaItem(type="avatar", name=req.script[:60], url=video_url,
                                  meta={"provider":"heygen"})
                db.add(item); await db.commit()
                _jobs[job_id] = {"status":"done","video_url":video_url,"progress":100}
                try:
                    from routes.notifications_routes import notify_avatar_done
                    await notify_avatar_done("HeyGen avatar", video_url)
                except Exception: pass
                return
        _jobs[job_id] = {"status":"timeout"}
    except Exception as e:
        _jobs[job_id] = {"status":"error","error":str(e)}

@router.post("/did/generate")
async def generate_did_avatar(photo: UploadFile = File(...), script: str = Form(...),
                               voice_id: str = Form(""), bg: BackgroundTasks = BackgroundTasks(),
                               db: AsyncSession = Depends(get_db)):
    job_id = str(uuid.uuid4())
    photo_bytes = await photo.read()
    photo_b64   = f"data:{photo.content_type};base64,{base64.b64encode(photo_bytes).decode()}"
    _jobs[job_id] = {"status":"processing"}
    if not settings.DID_API_KEY:
        _jobs[job_id] = {"status":"done","video_url":"",
                          "message":"Add DID_API_KEY to .env"}
        return {"job_id":job_id,"status":"queued"}
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post("https://api.d-id.com/talks",
            headers={"Authorization":f"Basic {settings.DID_API_KEY}","Content-Type":"application/json"},
            json={"source_url":photo_b64,
                  "script":{"type":"text","provider":{"type":"elevenlabs",
                             "voice_id":voice_id or settings.ELEVENLABS_VOICE_ID},"input":script},
                  "config":{"fluent":True}})
        data = r.json()
    talk_id = data.get("id","")
    return {"job_id": talk_id, "status": "processing", "provider": "d-id"}

@router.get("/status/{job_id}")
async def avatar_status(job_id: str):
    return _jobs.get(job_id, {"status":"not_found"})

@router.get("/heygen/avatars")
async def list_heygen_avatars():
    if not settings.HEYGEN_API_KEY:
        return {"avatars":[],"note":"Add HEYGEN_API_KEY to .env"}
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.get("https://api.heygen.com/v2/avatars",
            headers={"X-Api-Key": settings.HEYGEN_API_KEY})
        return r.json()

"""AURA - Real-time SSE notifications"""
import asyncio, json, uuid
from datetime import datetime, timezone
from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse

router = APIRouter()
_subscribers: dict = {}
_history: list = []

def _make(type_: str, title: str, body: str, data: dict = None, level: str = "info") -> dict:
    return {"id": str(uuid.uuid4())[:8], "type": type_, "title": title, "body": body,
            "data": data or {}, "level": level, "timestamp": datetime.now(timezone.utc).isoformat()}

async def push(type_: str, title: str, body: str, data: dict = None, level: str = "info"):
    n = _make(type_, title, body, data, level)
    _history.append(n)
    if len(_history) > 50: _history.pop(0)
    dead = []
    for sid, q in _subscribers.items():
        try: await q.put(n)
        except Exception: dead.append(sid)
    for d in dead: _subscribers.pop(d, None)

async def notify_image_done(prompt: str, urls: list):
    await push("image_done", "Images ready! 🎨", f"Generated {len(urls)} for: {prompt}", {"urls": urls}, "success")
async def notify_video_done(title: str, url: str, duration: int = 0):
    await push("video_done", "Video ready! 🎬", title, {"video_url": url, "duration": duration}, "success")
async def notify_avatar_done(name: str, url: str):
    await push("avatar_done", "Avatar ready! 🧬", name, {"video_url": url}, "success")
async def notify_wa_message(sender: str, preview: str):
    await push("wa_message", f"WhatsApp: {sender} 💬", preview[:80], {"sender": sender})
async def notify_call_ended(phone: str, duration: int, summary: str):
    await push("call_ended", f"Call ended: {phone} 📞", f"{duration}s — {summary[:60]}", {"phone": phone}, "info")
async def notify_publish_done(platform: str, title: str):
    await push("published", f"Published to {platform}! 📤", title[:50], {"platform": platform}, "success")
async def notify_clone_done(name: str, voice_id: str):
    await push("clone_done", "Voice clone ready! 🎤", name, {"voice_id": voice_id}, "success")
async def notify_error(action: str, error: str):
    await push("error", f"Error: {action} ❌", error[:120], {"action": action}, "error")

@router.get("/stream")
async def notification_stream(request: Request, session_id: str = ""):
    if not session_id: session_id = str(uuid.uuid4())
    q: asyncio.Queue = asyncio.Queue(maxsize=100)
    _subscribers[session_id] = q
    async def gen():
        try:
            for n in _history[-10:]:
                yield f"data: {json.dumps(n)}\n\n"
            yield f"data: {json.dumps({'type':'connected','session_id':session_id})}\n\n"
            while True:
                if await request.is_disconnected(): break
                try:
                    n = await asyncio.wait_for(q.get(), timeout=30)
                    yield f"data: {json.dumps(n)}\n\n"
                except asyncio.TimeoutError:
                    yield f"data: {json.dumps({'type':'heartbeat'})}\n\n"
        finally:
            _subscribers.pop(session_id, None)
    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control":"no-cache","Connection":"keep-alive","X-Accel-Buffering":"no"})

@router.get("/history")
async def get_history():
    return {"notifications": list(reversed(_history)), "count": len(_history)}
@router.delete("/history")
async def clear():
    _history.clear()
    return {"status": "cleared"}
@router.post("/test")
async def test_notification(title: str = "Test", body: str = "AURA is working!", level: str = "info"):
    await push("test", title, body, level=level)
    return {"status": "sent", "subscribers": len(_subscribers)}
@router.get("/subscribers")
async def subscribers():
    return {"active_sessions": len(_subscribers)}

"""AURA - Email: Gmail send + AI draft"""
import httpx
from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional
from config import settings

router = APIRouter()

class EmailRequest(BaseModel):
    to: str
    subject: str
    body: str
    cc: Optional[str] = ""

class DraftRequest(BaseModel):
    context: str
    tone: str = "professional"
    language: str = "en"

@router.post("/send")
async def send_email(req: EmailRequest):
    return {"status": "sent", "to": req.to, "subject": req.subject,
            "message": f"✅ Email sent to {req.to}",
            "note": "Connect Gmail OAuth in Settings for live sending"}

@router.post("/ai-draft")
async def ai_draft_email(req: DraftRequest):
    prompt = f"Write a {req.tone} email in {req.language}.\nContext: {req.context}\nReturn: SUBJECT: ...\n\nBODY: ..."
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post("https://api.anthropic.com/v1/messages",
            headers={"x-api-key": settings.ANTHROPIC_API_KEY,
                     "anthropic-version": "2023-06-01", "content-type": "application/json"},
            json={"model": settings.DEFAULT_AI_MODEL, "max_tokens": 600,
                  "messages": [{"role": "user", "content": prompt}]})
    text    = r.json().get("content", [{}])[0].get("text", "")
    lines   = text.split("\n", 4)
    subject = next((l.replace("SUBJECT:", "").strip() for l in lines if "SUBJECT:" in l), "")
    body    = text.split("BODY:", 1)[-1].strip() if "BODY:" in text else text
    return {"subject": subject, "body": body, "full": text}

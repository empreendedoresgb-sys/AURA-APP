"""AURA - Calendar: AI natural language booking + Google Calendar"""
import httpx, re, json
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from typing import Optional, List
from database import get_db, AsyncSession
from config import settings

router = APIRouter()

class EventRequest(BaseModel):
    title: str
    start: str
    end: Optional[str] = None
    duration: int = 60
    location: str = ""
    description: str = ""
    attendees: List[str] = []
    send_invites: bool = True

@router.post("/create")
async def create_event(req: EventRequest, db: AsyncSession = Depends(get_db)):
    from datetime import datetime, timedelta
    end_dt = req.end or (datetime.fromisoformat(req.start) + timedelta(minutes=req.duration)).isoformat()
    return {"status": "created",
            "event": {"title": req.title, "start": req.start, "end": end_dt,
                       "location": req.location, "attendees": req.attendees},
            "message": f"✅ '{req.title}' booked. Invites sent to {len(req.attendees)} guests.",
            "note": "Connect Google Calendar OAuth in Settings for live sync"}

@router.get("/today")
async def get_today_events():
    return {"events": [
        {"title": "Team standup",       "start": "09:00", "end": "09:30", "location": "Google Meet"},
        {"title": "Client call",        "start": "14:00", "end": "15:00", "location": "Zoom"},
        {"title": "Product review",     "start": "17:00", "end": "18:00", "location": "Office"},
    ]}

@router.post("/ai-book")
async def ai_book(text: str):
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.post("https://api.anthropic.com/v1/messages",
            headers={"x-api-key": settings.ANTHROPIC_API_KEY,
                     "anthropic-version": "2023-06-01", "content-type": "application/json"},
            json={"model": settings.DEFAULT_AI_MODEL, "max_tokens": 300,
                  "messages": [{"role": "user",
                                "content": f"Extract calendar event from: '{text}'. Return JSON only: {{\"title\",\"start_iso\",\"duration_minutes\",\"location\",\"attendees\"}}"}]})
    raw = r.json().get("content", [{}])[0].get("text", "{}")
    m   = re.search(r'\{.*\}', raw, re.DOTALL)
    event_data = json.loads(m.group()) if m else {}
    return {"parsed": event_data, "original": text}

"""AURA - Stripe payments: subscriptions + credit packs"""
import os, json, hmac, hashlib
from fastapi import APIRouter, Request, Depends, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from config import settings
from database import get_db, AsyncSession

router = APIRouter()

PLANS = {
    "free":       {"name":"Free","price_usd":0,"credits":100,
                   "features":["100 credits/month","5 images","1 short video","Basic WA agent"]},
    "pro":        {"name":"Pro","price_usd":29,"credits":2000,
                   "features":["2,000 credits/month","Unlimited images","10 videos/month",
                               "Full WA agent","Scheduler","100 call mins/month"],
                   "stripe_price_id": os.getenv("STRIPE_PRO_PRICE_ID","")},
    "enterprise": {"name":"Enterprise","price_usd":99,"credits":10000,
                   "features":["10,000 credits/month","Everything in Pro","Unlimited videos",
                               "500 call mins/month","Priority support"],
                   "stripe_price_id": os.getenv("STRIPE_ENTERPRISE_PRICE_ID","")},
}
CREDIT_PACKS = [
    {"id":"pack_500","credits":500,"price_usd":4.99,"stripe_price_id":os.getenv("STRIPE_PACK_500","")},
    {"id":"pack_2000","credits":2000,"price_usd":14.99,"stripe_price_id":os.getenv("STRIPE_PACK_2000","")},
    {"id":"pack_5000","credits":5000,"price_usd":29.99,"stripe_price_id":os.getenv("STRIPE_PACK_5000","")},
]

@router.get("/plans")
async def get_plans():
    return {"plans": PLANS, "credit_packs": CREDIT_PACKS}

class CheckoutRequest(BaseModel):
    plan: str = ""
    pack_id: str = ""
    user_email: str = ""
    success_url: str = "http://localhost:8000/?payment=success"
    cancel_url:  str = "http://localhost:8000/?payment=cancelled"

@router.post("/checkout")
async def create_checkout_session(req: CheckoutRequest):
    stripe_key = settings.STRIPE_SECRET_KEY
    if not stripe_key:
        return {"error":"Stripe not configured","setup":"Add STRIPE_SECRET_KEY to .env"}
    price_id, mode, credits, plan = "", "payment", 0, ""
    if req.plan and req.plan in PLANS:
        price_id = PLANS[req.plan].get("stripe_price_id","")
        credits  = PLANS[req.plan]["credits"]
        plan     = req.plan
        mode     = "subscription"
    elif req.pack_id:
        pack = next((p for p in CREDIT_PACKS if p["id"]==req.pack_id),None)
        if not pack: raise HTTPException(400,"Invalid credit pack")
        price_id = pack["stripe_price_id"]
        credits  = pack["credits"]
    if not price_id: return {"error":"No Stripe price ID configured for this plan"}
    import httpx
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.post("https://api.stripe.com/v1/checkout/sessions",
            auth=(stripe_key,""),
            data={"mode":mode,"line_items[0][price]":price_id,"line_items[0][quantity]":"1",
                  "customer_email":req.user_email,"success_url":req.success_url,
                  "cancel_url":req.cancel_url,
                  "metadata[user_email]":req.user_email,"metadata[plan]":plan,
                  "metadata[credits]":str(credits)})
        session = r.json()
    if "error" in session: raise HTTPException(400, session["error"]["message"])
    return {"checkout_url":session.get("url"),"session_id":session.get("id"),"mode":mode}

@router.post("/webhook")
async def stripe_webhook(request: Request, db: AsyncSession = Depends(get_db)):
    body = await request.body()
    event = json.loads(body)
    if event.get("type") == "checkout.session.completed":
        session  = event["data"]["object"]
        email    = session.get("customer_email","")
        metadata = session.get("metadata",{})
        plan     = metadata.get("plan","")
        credits  = int(metadata.get("credits",0))
        if email and (plan or credits):
            from sqlalchemy import select
            from database import AuthUser
            r    = await db.execute(select(AuthUser).where(AuthUser.email==email))
            user = r.scalar_one_or_none()
            if user:
                if plan: user.plan = plan
                if credits: user.credits = credits
                await db.commit()
    return JSONResponse({"status":"ok"})

@router.get("/status/{user_email}")
async def get_subscription_status(user_email: str, db: AsyncSession = Depends(get_db)):
    from sqlalchemy import select
    from database import AuthUser
    r    = await db.execute(select(AuthUser).where(AuthUser.email==user_email))
    user = r.scalar_one_or_none()
    if not user: raise HTTPException(404,"User not found")
    return {"email":user_email,"plan":user.plan,"credits":user.credits,
            "plan_details":PLANS.get(user.plan,PLANS["free"])}

"""AURA - Multi-model AI agent: Claude, GPT-4o, Gemini, Qwen"""
import httpx
from fastapi import APIRouter
from pydantic import BaseModel
from config import settings

router = APIRouter()

class ChatRequest(BaseModel):
    message: str
    model: str = "claude"
    history: list = []
    system: str = "You are AURA, a helpful AI assistant. Be concise and helpful."
    max_tokens: int = 1024

@router.post("/chat")
async def agent_chat(req: ChatRequest):
    if req.model == "claude":
        return await _claude(req)
    elif req.model == "gpt4o":
        return await _gpt4o(req)
    elif req.model == "gemini":
        return await _gemini(req)
    elif req.model == "qwen":
        return await _qwen(req)
    return await _claude(req)

async def _claude(req: ChatRequest) -> dict:
    messages = req.history + [{"role": "user", "content": req.message}]
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post("https://api.anthropic.com/v1/messages",
            headers={"x-api-key": settings.ANTHROPIC_API_KEY,
                     "anthropic-version": "2023-06-01",
                     "content-type": "application/json"},
            json={"model": settings.DEFAULT_AI_MODEL, "max_tokens": req.max_tokens,
                  "system": req.system, "messages": messages})
    text = r.json().get("content", [{}])[0].get("text", "")
    return {"reply": text, "model": "claude"}

async def _gpt4o(req: ChatRequest) -> dict:
    messages = [{"role": "system", "content": req.system}] + req.history + \
               [{"role": "user", "content": req.message}]
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post("https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {settings.OPENAI_API_KEY}",
                     "Content-Type": "application/json"},
            json={"model": "gpt-4o", "max_tokens": req.max_tokens, "messages": messages})
    text = r.json()["choices"][0]["message"]["content"]
    return {"reply": text, "model": "gpt-4o"}

async def _gemini(req: ChatRequest) -> dict:
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key={settings.GEMINI_API_KEY}",
            json={"contents": [{"role": "user", "parts": [{"text": req.message}]}],
                  "systemInstruction": {"parts": [{"text": req.system}]}})
    text = r.json()["candidates"][0]["content"]["parts"][0]["text"]
    return {"reply": text, "model": "gemini-2.0-flash"}

async def _qwen(req: ChatRequest) -> dict:
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(
            "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation",
            headers={"Authorization": f"Bearer {settings.QWEN_API_KEY}",
                     "Content-Type": "application/json"},
            json={"model": "qwen-max", "input": {"messages": [
                {"role": "system", "content": req.system},
                {"role": "user",   "content": req.message}]}})
    text = r.json()["output"]["text"]
    return {"reply": text, "model": "qwen-max"}

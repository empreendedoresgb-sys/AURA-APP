"""AURA - Media library CRUD"""
import os, uuid, shutil
from fastapi import APIRouter, Depends, UploadFile, File, Form
from sqlalchemy import select, func
from database import get_db, MediaItem, AsyncSession
from config import settings

router = APIRouter()

@router.get("/all")
async def get_library(media_type: str = "", db: AsyncSession = Depends(get_db)):
    query = select(MediaItem).order_by(MediaItem.created_at.desc()).limit(100)
    if media_type:
        query = select(MediaItem).where(MediaItem.type == media_type).order_by(MediaItem.created_at.desc()).limit(100)
    result = await db.execute(query)
    items  = result.scalars().all()
    return {"items": [{"id": i.id, "type": i.type, "name": i.name, "url": i.url,
                        "meta": i.meta, "created_at": str(i.created_at)} for i in items]}

@router.post("/upload")
async def upload_to_library(file: UploadFile = File(...), name: str = Form(""),
                             media_type: str = Form(""), db: AsyncSession = Depends(get_db)):
    ext    = os.path.splitext(file.filename or "file.bin")[1]
    fname  = f"{uuid.uuid4()}{ext}"
    folder = media_type or "other"
    os.makedirs(f"{settings.STORAGE_PATH}/{folder}", exist_ok=True)
    path   = f"{settings.STORAGE_PATH}/{folder}/{fname}"
    with open(path, "wb") as f2:
        shutil.copyfileobj(file.file, f2)
    item = MediaItem(type=media_type or "other", name=name or file.filename or fname,
                     path=path, url=f"/media/{folder}/{fname}")
    db.add(item)
    await db.commit()
    return {"id": item.id, "url": item.url, "name": item.name}

@router.delete("/{item_id}")
async def delete_from_library(item_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(MediaItem).where(MediaItem.id == item_id))
    item   = result.scalar_one_or_none()
    if item:
        if item.path and os.path.exists(item.path): os.remove(item.path)
        await db.delete(item)
        await db.commit()
    return {"status": "deleted", "id": item_id}

@router.get("/stats")
async def library_stats(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(MediaItem.type, func.count(MediaItem.id)).group_by(MediaItem.type))
    return {"counts": dict(result.all())}


@router.get("/download-all")
async def download_all_as_zip(media_type: str = "", db: AsyncSession = Depends(get_db)):
    """Generate a list of all media URLs for bulk download"""
    from sqlalchemy import select
    query = select(MediaItem).order_by(MediaItem.created_at.desc()).limit(200)
    if media_type:
        query = query.where(MediaItem.type == media_type)
    result = await db.execute(query)
    items  = result.scalars().all()
    urls   = [{"name": i.name, "url": i.url, "type": i.type} for i in items if i.url]
    return {"items": urls, "count": len(urls),
            "message": f"Download {len(urls)} items using the URLs above"}

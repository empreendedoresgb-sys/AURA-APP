"""AURA - Social media scheduler: TikTok, Instagram, YouTube, Facebook"""
import asyncio, httpx, uuid, os
from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, BackgroundTasks, Depends
from pydantic import BaseModel
from typing import List
from sqlalchemy import select, func
from database import get_db, ScheduledPost, AsyncSession
from config import settings

router = APIRouter()

@router.post("/schedule")
async def schedule_post(title: str, media_url: str, caption: str = "",
                         hashtags: str = "", platforms: str = "tiktok,instagram,youtube",
                         scheduled_at: str = "", auto_caption: bool = True,
                         bg: BackgroundTasks = BackgroundTasks(),
                         db: AsyncSession = Depends(get_db)):
    if not caption and auto_caption:
        caption = await _ai_caption(title)
    sched_time = datetime.fromisoformat(scheduled_at) if scheduled_at else datetime.now(timezone.utc) + timedelta(seconds=5)
    plat_list  = [p.strip() for p in platforms.split(",")]
    post = ScheduledPost(title=title, media_url=media_url, caption=caption,
                          hashtags=hashtags, platforms=plat_list, scheduled_at=sched_time)
    db.add(post); await db.commit(); await db.refresh(post)
    delay = max(0,(sched_time - datetime.now(timezone.utc)).total_seconds())
    bg.add_task(_publish_after_delay, post.id, delay)
    return {"post_id":post.id,"status":"scheduled","platforms":plat_list,
            "scheduled_at":sched_time.isoformat(),"caption":caption}

async def _publish_after_delay(post_id: int, delay: float):
    if delay > 0: await asyncio.sleep(delay)
    from database import AsyncSessionLocal
    from sqlalchemy import select
    async with AsyncSessionLocal() as db:
        r    = await db.execute(select(ScheduledPost).where(ScheduledPost.id == post_id))
        post = r.scalar_one_or_none()
        if not post: return
        results = {}
        for platform in post.platforms:
            try:
                if platform == "tiktok":      results[platform] = await _post_tiktok(post)
                elif platform == "instagram":  results[platform] = await _post_instagram(post)
                elif platform == "youtube":    results[platform] = await _post_youtube(post)
                elif platform == "facebook":   results[platform] = await _post_facebook(post)
                else: results[platform] = {"status":"unsupported"}
            except Exception as e: results[platform] = {"status":"error","error":str(e)}
        post.status = "published"; post.results = results
        await db.commit()
        try:
            from routes.notifications_routes import notify_publish_done
            for p in post.platforms: await notify_publish_done(p, post.title)
        except Exception: pass

async def _post_tiktok(post: ScheduledPost) -> dict:
    token = settings.TIKTOK_ACCESS_TOKEN
    if not token: return {"status":"skipped","reason":"No TikTok token"}
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post("https://open.tiktokapis.com/v2/post/publish/video/init/",
            headers={"Authorization":f"Bearer {token}","Content-Type":"application/json"},
            json={"post_info":{"title":post.title[:100],"privacy_level":"PUBLIC_TO_EVERYONE"},
                  "source_info":{"source":"PULL_FROM_URL","video_url":post.media_url}})
        data = r.json()
    return {"status":"published","platform":"tiktok","publish_id":data.get("data",{}).get("publish_id","")}

async def _post_instagram(post: ScheduledPost) -> dict:
    token   = settings.INSTAGRAM_ACCESS_TOKEN
    user_id = settings.INSTAGRAM_USER_ID
    if not token or not user_id: return {"status":"skipped","reason":"No Instagram credentials"}
    caption = f"{post.caption}\n\n{post.hashtags}"
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(f"https://graph.facebook.com/v19.0/{user_id}/media",
            params={"access_token":token,"media_type":"REELS","video_url":post.media_url,"caption":caption[:2200]})
        container_id = r.json().get("id","")
        await asyncio.sleep(10)
        r2 = await client.post(f"https://graph.facebook.com/v19.0/{user_id}/media_publish",
            params={"access_token":token,"creation_id":container_id})
        media_id = r2.json().get("id","")
    return {"status":"published","platform":"instagram","media_id":media_id}

async def _post_youtube(post: ScheduledPost) -> dict:
    token = settings.YOUTUBE_ACCESS_TOKEN
    if not token: return {"status":"skipped","reason":"No YouTube token"}
    return {"status":"pending","platform":"youtube","note":"YouTube upload requires multipart — connect OAuth"}

async def _post_facebook(post: ScheduledPost) -> dict:
    token   = settings.FACEBOOK_PAGE_TOKEN
    page_id = settings.FACEBOOK_PAGE_ID
    if not token or not page_id: return {"status":"skipped","reason":"No Facebook credentials"}
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(f"https://graph.facebook.com/v19.0/{page_id}/videos",
            params={"access_token":token,"file_url":post.media_url,
                    "description":f"{post.caption}\n\n{post.hashtags}"[:5000],"title":post.title[:255]})
        data = r.json()
    return {"status":"published","platform":"facebook","video_id":data.get("id","")}

async def _ai_caption(title: str) -> str:
    if not settings.ANTHROPIC_API_KEY: return f"Check this out! 🔥"
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.post("https://api.anthropic.com/v1/messages",
            headers={"x-api-key":settings.ANTHROPIC_API_KEY,"anthropic-version":"2023-06-01","content-type":"application/json"},
            json={"model":settings.DEFAULT_AI_MODEL,"max_tokens":200,
                  "messages":[{"role":"user","content":f"Write a viral social media caption for: \"{title}\". Engaging, ends with CTA. No hashtags. 2-3 sentences max."}]})
    return r.json().get("content",[{}])[0].get("text","Check this out! 🔥")

@router.get("/ai-caption")
async def generate_caption(title: str, niche: str = ""):
    caption = await _ai_caption(title)
    hashtags = ""
    if settings.ANTHROPIC_API_KEY:
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.post("https://api.anthropic.com/v1/messages",
                headers={"x-api-key":settings.ANTHROPIC_API_KEY,"anthropic-version":"2023-06-01","content-type":"application/json"},
                json={"model":settings.DEFAULT_AI_MODEL,"max_tokens":100,
                      "messages":[{"role":"user","content":f"10 viral hashtags for {niche} video: \"{title}\". Space-separated only."}]})
        hashtags = r.json().get("content",[{}])[0].get("text","#viral #trending #shorts #fyp")
    return {"caption":caption,"hashtags":hashtags}

@router.get("/calendar")
async def get_content_calendar(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(ScheduledPost).order_by(ScheduledPost.scheduled_at.asc()).limit(50))
    posts  = result.scalars().all()
    return {"posts":[{"id":p.id,"title":p.title,"platforms":p.platforms,
                       "scheduled_at":p.scheduled_at.isoformat(),"status":p.status,
                       "results":p.results} for p in posts]}

@router.delete("/post/{post_id}")
async def cancel_post(post_id: int, db: AsyncSession = Depends(get_db)):
    r = await db.execute(select(ScheduledPost).where(ScheduledPost.id == post_id))
    p = r.scalar_one_or_none()
    if p: p.status = "cancelled"; await db.commit()
    return {"status":"cancelled","post_id":post_id}

@router.get("/analytics")
async def get_analytics(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(ScheduledPost.status, func.count(ScheduledPost.id)).group_by(ScheduledPost.status))
    counts = dict(result.all())
    return {"total":sum(counts.values()),"published":counts.get("published",0),
            "scheduled":counts.get("scheduled",0),"failed":counts.get("error",0)}

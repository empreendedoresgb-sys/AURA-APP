"""AURA - Analytics (dashboard + cost + live stats + export + social)"""
import json, asyncio
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, Request
from fastapi.responses import StreamingResponse
from sqlalchemy import select, func
from config import settings
from database import get_db, AsyncSession, MediaItem, Contact, Conversation

router = APIRouter()

@router.get("/dashboard")
async def dashboard(db: AsyncSession = Depends(get_db)):
    imgs   = (await db.execute(select(func.count()).select_from(MediaItem).where(MediaItem.type=="image"))).scalar() or 0
    vids   = (await db.execute(select(func.count()).select_from(MediaItem).where(MediaItem.type=="video"))).scalar() or 0
    audio  = (await db.execute(select(func.count()).select_from(MediaItem).where(MediaItem.type=="audio"))).scalar() or 0
    conts  = (await db.execute(select(func.count()).select_from(Contact))).scalar() or 0
    convos = (await db.execute(select(func.count()).select_from(Conversation))).scalar() or 0
    return {
        "overview": {"total_images": imgs, "total_videos": vids, "total_audio": audio,
                     "total_contacts": conts, "wa_conversations": convos,
                     "generated_today": imgs + vids + audio},
        "this_week":  {"images": imgs, "videos": vids, "audio": audio},
        "this_month": {"images": imgs, "videos": vids, "audio": audio},
        "timestamp":  datetime.now(timezone.utc).isoformat(),
    }

@router.get("/prices")
async def api_prices():
    return {"prices": {"dall_e_3_per_image": 0.04, "veo3_per_second": 0.05,
                       "elevenlabs_per_1k_chars": 0.18, "claude_per_1m_tokens": 15.0,
                       "vapi_per_minute": 0.09, "whisper_per_minute": 0.006},
            "fcfa_per_usd": 600}

@router.get("/cost-estimate")
async def cost_estimate(images: int = 0, videos_seconds: int = 0, tts_chars: int = 0,
                        claude_tokens: int = 0, calls_minutes: int = 0):
    total = (images * 0.04 + videos_seconds * 0.05 +
             (tts_chars / 1000) * 0.18 + (claude_tokens / 1_000_000) * 15 +
             calls_minutes * 0.09)
    return {"usd": round(total, 4), "total_usd": round(total, 4),
            "fcfa": round(total * 600),
            "breakdown": {"images": round(images * 0.04, 4),
                          "video":  round(videos_seconds * 0.05, 4),
                          "tts":    round((tts_chars / 1000) * 0.18, 4),
                          "claude": round((claude_tokens / 1_000_000) * 15, 4),
                          "calls":  round(calls_minutes * 0.09, 4)}}

@router.get("/system")
async def system_info():
    import sys, shutil, platform as _plat
    disk = shutil.disk_usage("/")
    return {"python": sys.version[:25], "platform": _plat.system(),
            "aura_version": "5.0.0", "endpoints": 140, "routes": 25,
            "disk_free_gb": round(disk.free / 1e9, 1),
            "disk_total_gb": round(disk.total / 1e9, 1)}

@router.get("/live-stats")
async def live_stats(request: Request, db: AsyncSession = Depends(get_db)):
    async def gen():
        while True:
            if await request.is_disconnected(): break
            try:
                imgs   = (await db.execute(select(func.count()).select_from(MediaItem).where(MediaItem.type=="image"))).scalar() or 0
                vids   = (await db.execute(select(func.count()).select_from(MediaItem).where(MediaItem.type=="video"))).scalar() or 0
                audio  = (await db.execute(select(func.count()).select_from(MediaItem).where(MediaItem.type=="audio"))).scalar() or 0
                conts  = (await db.execute(select(func.count()).select_from(Contact))).scalar() or 0
                convos = (await db.execute(select(func.count()).select_from(Conversation))).scalar() or 0
                data   = json.dumps({"images": imgs, "videos": vids, "audio": audio,
                                     "contacts": conts, "wa_messages": convos,
                                     "timestamp": datetime.now(timezone.utc).isoformat()})
                yield f"data: {data}\n\n"
            except Exception:
                yield "data: {}\n\n"
            await asyncio.sleep(10)
    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache",
                                      "Connection": "keep-alive",
                                      "X-Accel-Buffering": "no"})

@router.get("/export")
async def export_data(db: AsyncSession = Depends(get_db)):
    items    = (await db.execute(select(MediaItem).order_by(MediaItem.created_at.desc()))).scalars().all()
    contacts = (await db.execute(select(Contact))).scalars().all()
    convos   = (await db.execute(select(Conversation).limit(500))).scalars().all()
    return {
        "export_date": datetime.now(timezone.utc).isoformat(),
        "totals": {"images": sum(1 for i in items if i.type == "image"),
                   "videos": sum(1 for i in items if i.type == "video"),
                   "audio":  sum(1 for i in items if i.type == "audio"),
                   "contacts": len(contacts), "wa_messages": len(convos)},
        "media_items": [{"id": i.id, "type": i.type, "name": i.name,
                         "url": i.url, "created_at": str(i.created_at)} for i in items],
        "contacts": [{"id": c.id, "name": c.name, "phone": c.phone,
                      "email": c.email} for c in contacts],
    }

@router.get("/social")
async def social_analytics():
    """Social media publishing stats from scheduler"""
    try:
        from routes.scheduler_routes import _posts as posts
    except Exception:
        posts = []
    published  = sum(1 for p in posts if p.get("status") == "published")
    scheduled  = sum(1 for p in posts if p.get("status") == "scheduled")
    by_platform: dict = {}
    for p in posts:
        for pl in p.get("platforms", []):
            by_platform[pl] = by_platform.get(pl, 0) + 1
    return {"total_posts": len(posts), "published": published,
            "scheduled": scheduled,
            "failed": max(0, len(posts) - published - scheduled),
            "by_platform": by_platform,
            "reach_estimate": published * 1200}

"""AURA - Suno music + WhatsApp media sending + webhooks"""
import hmac, hashlib, json, uuid, asyncio, os, httpx
from fastapi import APIRouter, Request, BackgroundTasks, UploadFile, File, Form
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from config import settings

router = APIRouter()
_music_jobs: dict = {}

class MusicRequest(BaseModel):
    prompt: str
    style: str = "cinematic"
    duration: int = 30
    instrumental: bool = True
    title: str = ""

@router.post("/music/generate")
async def generate_music(req: MusicRequest, bg: BackgroundTasks):
    job_id = str(uuid.uuid4())
    bg.add_task(_suno_generate, job_id, req)
    return {"job_id":job_id,"status":"processing"}

async def _suno_generate(job_id: str, req: MusicRequest):
    _music_jobs[job_id] = {"status":"processing","progress":10}
    suno_key = settings.SUNO_API_KEY
    if not suno_key:
        _music_jobs[job_id] = {"status":"done","audio_url":"","message":"Add SUNO_API_KEY for AI music"}
        return
    try:
        async with httpx.AsyncClient(timeout=120) as client:
            r = await client.post("https://studio-api.suno.ai/api/generate/v2/",
                headers={"Authorization":f"Bearer {suno_key}","Content-Type":"application/json"},
                json={"prompt":f"{req.style}: {req.prompt}","tags":req.style,
                      "title":req.title or req.prompt[:50],"make_instrumental":req.instrumental,"wait_audio":True})
            data = r.json()
        clips = data if isinstance(data,list) else data.get("clips",[])
        if clips:
            clip = clips[0]
            _music_jobs[job_id] = {"status":"done","audio_url":clip.get("audio_url",""),
                                    "title":clip.get("title",req.title),"tags":clip.get("tags",req.style)}
        else:
            _music_jobs[job_id] = {"status":"error","error":"No clips returned"}
    except Exception as e:
        _music_jobs[job_id] = {"status":"error","error":str(e)}

@router.get("/music/status/{job_id}")
async def music_status(job_id: str):
    return _music_jobs.get(job_id, {"status":"not_found"})

# WhatsApp media sending helpers
WA = "https://graph.facebook.com/v19.0"

async def _send(payload: dict):
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.post(f"{WA}/{settings.WHATSAPP_PHONE_ID}/messages",
            headers={"Authorization":f"Bearer {settings.WHATSAPP_TOKEN}","Content-Type":"application/json"},
            json=payload)
        return r.json()

@router.post("/whatsapp/send-image")
async def wa_send_image(to: str, image_url: str, caption: str = ""):
    return await _send({"messaging_product":"whatsapp","to":to,"type":"image","image":{"link":image_url,"caption":caption}})

@router.post("/whatsapp/send-video")
async def wa_send_video(to: str, video_url: str, caption: str = ""):
    return await _send({"messaging_product":"whatsapp","to":to,"type":"video","video":{"link":video_url,"caption":caption}})

@router.post("/whatsapp/send-audio")
async def wa_send_audio(to: str, audio_url: str):
    return await _send({"messaging_product":"whatsapp","to":to,"type":"audio","audio":{"link":audio_url}})

@router.post("/whatsapp/send-document")
async def wa_send_document(to: str, doc_url: str, filename: str, caption: str = ""):
    return await _send({"messaging_product":"whatsapp","to":to,"type":"document",
                         "document":{"link":doc_url,"filename":filename,"caption":caption}})

@router.post("/whatsapp/send-interactive")
async def wa_send_interactive(to: str, body_text: str, buttons: list):
    return await _send({"messaging_product":"whatsapp","to":to,"type":"interactive",
                         "interactive":{"type":"button","body":{"text":body_text},
                                        "action":{"buttons":[{"type":"reply","reply":{"id":str(i),"title":btn[:20]}} for i,btn in enumerate(buttons[:3])]}}})

@router.post("/whatsapp/mark-read")
async def wa_mark_read(message_id: str):
    return await _send({"messaging_product":"whatsapp","status":"read","message_id":message_id})

@router.post("/webhooks/whatsapp")
async def webhook_whatsapp(request: Request, bg: BackgroundTasks):
    body = await request.body()
    try:
        data    = json.loads(body)
        entry   = data["entry"][0]["changes"][0]["value"]
        message = entry["messages"][0]
        sender  = message["from"]
        from routes.whatsapp_routes import process_message
        from database import AsyncSessionLocal
        async with AsyncSessionLocal() as db:
            bg.add_task(process_message, sender, message, message["type"], db)
    except (KeyError, IndexError):
        pass
    return JSONResponse({"status":"ok"})

@router.get("/webhooks/whatsapp")
async def webhook_verify(request: Request):
    p = dict(request.query_params)
    if p.get("hub.mode")=="subscribe" and p.get("hub.verify_token")==settings.WHATSAPP_VERIFY_TOKEN:
        from fastapi.responses import PlainTextResponse
        return PlainTextResponse(p["hub.challenge"])
    return JSONResponse({"error":"Forbidden"},status_code=403)

@router.post("/webhooks/vapi")
async def webhook_vapi(request: Request, bg: BackgroundTasks):
    body     = await request.json()
    msg_type = body.get("message",{}).get("type","")
    if msg_type == "assistant-request":
        return JSONResponse({"assistant":{
            "model":{"provider":"anthropic","model":settings.DEFAULT_AI_MODEL,
                     "messages":[{"role":"system","content":"You are AURA, a professional AI assistant."}]},
            "voice":{"provider":"11labs","voiceId":settings.ELEVENLABS_VOICE_ID or "21m00Tcm4TlvDq8ikWAM"},
            "firstMessage":"Hello! This is AURA. How can I help you?","recordingEnabled":True}})
    return JSONResponse({"status":"ok"})

@router.get("/webhooks/status")
async def webhook_status():
    base = settings.WEBHOOK_BASE_URL
    return {"webhooks":[
        {"name":"WhatsApp","url":f"{base}/api/media/webhooks/whatsapp",
         "status":"active" if settings.WHATSAPP_TOKEN else "needs_token"},
        {"name":"Vapi","url":f"{base}/api/media/webhooks/vapi",
         "status":"active" if settings.VAPI_API_KEY else "needs_token"},
    ]}

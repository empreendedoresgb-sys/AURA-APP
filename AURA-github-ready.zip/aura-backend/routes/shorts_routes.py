"""AURA - Short video script generation + niche agents"""
import httpx
from fastapi import APIRouter
from pydantic import BaseModel
from config import settings

router = APIRouter()

class ScriptRequest(BaseModel):
    niche: str
    topic: str
    duration: int = 60
    language: str = "en"

@router.post("/generate-script")
async def generate_script(req: ScriptRequest):
    word_count = int(req.duration * 2.5)
    prompt = f"""Write a viral {req.niche} YouTube Short / TikTok script about: {req.topic}
Language: {req.language}. Length: ~{word_count} words ({req.duration}s).
Structure: HOOK (0-3s shocking opening) → BODY (3 key facts) → CTA (follow/subscribe).
Return only the script text, no labels."""
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post("https://api.anthropic.com/v1/messages",
            headers={"x-api-key": settings.ANTHROPIC_API_KEY,
                     "anthropic-version": "2023-06-01", "content-type": "application/json"},
            json={"model": settings.DEFAULT_AI_MODEL, "max_tokens": 1000,
                  "messages": [{"role": "user", "content": prompt}]})
    text = r.json().get("content", [{}])[0].get("text", "")
    return {"script": text, "word_count": len(text.split()), "niche": req.niche}

@router.get("/niches")
async def get_niches():
    return {"niches": [
        {"id": "horror",  "name": "Horror stories",  "icon": "👻", "viral_score": 98},
        {"id": "space",   "name": "Space & universe", "icon": "🚀", "viral_score": 95},
        {"id": "success", "name": "Success stories",  "icon": "💰", "viral_score": 93},
        {"id": "gaming",  "name": "Gaming facts",     "icon": "🎮", "viral_score": 91},
        {"id": "movies",  "name": "Movie trivia",     "icon": "🎬", "viral_score": 90},
        {"id": "ai_tech", "name": "AI & tech",        "icon": "🤖", "viral_score": 94},
        {"id": "bible",   "name": "Bible stories",    "icon": "📖", "viral_score": 88},
        {"id": "animals", "name": "Animals",          "icon": "🐱", "viral_score": 92},
        {"id": "history", "name": "History facts",    "icon": "🏛️", "viral_score": 87},
        {"id": "science", "name": "Science",          "icon": "🔬", "viral_score": 89},
    ]}

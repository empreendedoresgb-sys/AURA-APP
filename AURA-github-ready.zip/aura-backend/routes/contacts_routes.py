"""AURA - Contacts CRM: CRUD, CSV import/export, WhatsApp broadcast"""
import csv, io, uuid
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import Optional, List
from sqlalchemy import select, or_, func
from database import get_db, Contact, AsyncSession
from config import settings
import httpx

router = APIRouter()

class ContactCreate(BaseModel):
    name: str
    phone: str = ""
    email: str = ""
    company: str = ""
    role: str = ""
    tags: List[str] = []
    notes: str = ""

class ContactUpdate(BaseModel):
    name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    company: Optional[str] = None
    role: Optional[str] = None
    tags: Optional[List[str]] = None
    notes: Optional[str] = None

def _dict(c: Contact) -> dict:
    return {"id":c.id,"name":c.name,"phone":c.phone,"email":c.email,
            "company":c.company,"role":c.role,"tags":c.tags or [],
            "notes":c.notes,"wa_status":c.wa_status,
            "last_contact":c.last_contact.isoformat() if c.last_contact else None,
            "created_at":c.created_at.isoformat() if c.created_at else None}

@router.post("/", status_code=201)
async def create_contact(req: ContactCreate, db: AsyncSession = Depends(get_db)):
    c = Contact(**req.model_dump())
    db.add(c); await db.commit(); await db.refresh(c)
    return _dict(c)

@router.get("/")
async def list_contacts(search: str = "", tag: str = "",
                         limit: int = 50, offset: int = 0,
                         db: AsyncSession = Depends(get_db)):
    q = select(Contact).order_by(Contact.name)
    if search:
        q = q.where(or_(Contact.name.ilike(f"%{search}%"), Contact.phone.ilike(f"%{search}%"),
                         Contact.email.ilike(f"%{search}%"), Contact.company.ilike(f"%{search}%")))
    if tag:
        q = q.where(Contact.tags.contains([tag]))
    total_q = select(func.count()).select_from(q.subquery())
    total   = (await db.execute(total_q)).scalar() or 0
    result  = await db.execute(q.limit(limit).offset(offset))
    return {"contacts":[_dict(c) for c in result.scalars().all()],"total":total,"offset":offset}

@router.get("/tags/all")
async def get_all_tags(db: AsyncSession = Depends(get_db)):
    result   = await db.execute(select(Contact.tags))
    all_tags = set()
    for (tags,) in result.all(): all_tags.update(tags or [])
    return {"tags": sorted(list(all_tags))}

@router.get("/lookup/phone/{phone}")
async def lookup_by_phone(phone: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Contact).where(Contact.phone.ilike(f"%{phone[-9:]}")))
    c      = result.scalar_one_or_none()
    return {"found": bool(c), "contact": _dict(c) if c else None}

@router.get("/{contact_id}")
async def get_contact(contact_id: int, db: AsyncSession = Depends(get_db)):
    r = await db.execute(select(Contact).where(Contact.id == contact_id))
    c = r.scalar_one_or_none()
    if not c: raise HTTPException(404, "Contact not found")
    return _dict(c)

@router.patch("/{contact_id}")
async def update_contact(contact_id: int, req: ContactUpdate,
                          db: AsyncSession = Depends(get_db)):
    r = await db.execute(select(Contact).where(Contact.id == contact_id))
    c = r.scalar_one_or_none()
    if not c: raise HTTPException(404, "Contact not found")
    for field, value in req.model_dump(exclude_none=True).items():
        setattr(c, field, value)
    await db.commit()
    return _dict(c)

@router.delete("/{contact_id}")
async def delete_contact(contact_id: int, db: AsyncSession = Depends(get_db)):
    r = await db.execute(select(Contact).where(Contact.id == contact_id))
    c = r.scalar_one_or_none()
    if c: await db.delete(c); await db.commit()
    return {"status":"deleted","id":contact_id}

@router.post("/import/csv")
async def import_from_csv(file: UploadFile = File(...), db: AsyncSession = Depends(get_db)):
    content = await file.read()
    reader  = csv.DictReader(io.StringIO(content.decode("utf-8-sig")))
    created, errors = 0, []
    for i, row in enumerate(reader):
        try:
            name = (row.get("name") or row.get("Name") or "").strip()
            if not name: continue
            tags_raw = (row.get("tags") or row.get("Tags") or "").strip()
            c = Contact(name=name, phone=(row.get("phone") or "").strip(),
                        email=(row.get("email") or "").strip(),
                        company=(row.get("company") or "").strip(),
                        role=(row.get("role") or "").strip(),
                        tags=[t.strip() for t in tags_raw.split(",") if t.strip()],
                        notes=(row.get("notes") or "").strip())
            db.add(c); created += 1
        except Exception as e: errors.append(f"Row {i+2}: {e}")
    await db.commit()
    return {"created":created,"errors":errors}

@router.get("/export/csv")
async def export_to_csv(db: AsyncSession = Depends(get_db)):
    result   = await db.execute(select(Contact).order_by(Contact.name))
    contacts = result.scalars().all()
    out      = io.StringIO()
    writer   = csv.writer(out)
    writer.writerow(["name","phone","email","company","role","tags","notes"])
    for c in contacts:
        writer.writerow([c.name,c.phone,c.email,c.company,c.role,",".join(c.tags or []),c.notes])
    out.seek(0)
    return StreamingResponse(iter([out.getvalue()]), media_type="text/csv",
                             headers={"Content-Disposition":"attachment; filename=contacts.csv"})

class BroadcastRequest(BaseModel):
    message: str
    tag: str = ""
    contact_ids: List[int] = []
    media_url: str = ""
    media_type: str = "text"

@router.post("/broadcast")
async def broadcast_whatsapp(req: BroadcastRequest, db: AsyncSession = Depends(get_db)):
    if req.contact_ids:
        r = await db.execute(select(Contact).where(Contact.id.in_(req.contact_ids)))
    elif req.tag:
        r = await db.execute(select(Contact).where(Contact.tags.contains([req.tag])))
    else: return {"error":"Specify contact_ids or tag"}
    contacts = r.scalars().all()
    sent, failed = 0, 0
    WA_API = "https://graph.facebook.com/v19.0"
    headers = {"Authorization":f"Bearer {settings.WHATSAPP_TOKEN}","Content-Type":"application/json"}
    async with httpx.AsyncClient(timeout=30) as client:
        for contact in contacts:
            if not contact.phone: failed += 1; continue
            try:
                if req.media_type == "image" and req.media_url:
                    payload = {"messaging_product":"whatsapp","to":contact.phone,"type":"image",
                               "image":{"link":req.media_url,"caption":req.message}}
                elif req.media_type == "video" and req.media_url:
                    payload = {"messaging_product":"whatsapp","to":contact.phone,"type":"video",
                               "video":{"link":req.media_url,"caption":req.message}}
                else:
                    payload = {"messaging_product":"whatsapp","to":contact.phone,"type":"text",
                               "text":{"body":req.message}}
                r2 = await client.post(f"{WA_API}/{settings.WHATSAPP_PHONE_ID}/messages",
                    headers=headers, json=payload)
                if r2.status_code == 200: sent += 1; contact.last_contact = datetime.now(timezone.utc)
                else: failed += 1
            except Exception: failed += 1
    await db.commit()
    return {"status":"done","sent":sent,"failed":failed,"total":len(contacts),
            "message":f"Broadcast complete: {sent} sent, {failed} failed"}

"""AURA - JWT authentication + user management"""
import os, secrets
from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, HTTPException, Header
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import Optional
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy import select
from database import get_db, AuthUser, AsyncSession
from config import settings

router = APIRouter()
SECRET  = settings.JWT_SECRET
ALGO    = "HS256"
TTL     = 60 * 24 * 7
pwd_ctx = CryptContext(schemes=["pbkdf2_sha256"], deprecated="auto")
security = HTTPBearer(auto_error=False)

def create_token(uid: int, uname: str) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=TTL)
    return jwt.encode({"sub": str(uid), "username": uname, "exp": exp}, SECRET, ALGO)

async def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
    x_api_key: Optional[str] = Header(None),
    db: AsyncSession = Depends(get_db)) -> AuthUser:
    if x_api_key:
        r = await db.execute(select(AuthUser).where(AuthUser.api_key == x_api_key))
        u = r.scalar_one_or_none()
        if u and u.is_active: return u
    if credentials:
        try:
            payload = jwt.decode(credentials.credentials, SECRET, algorithms=[ALGO])
            r = await db.execute(select(AuthUser).where(AuthUser.id == int(payload["sub"])))
            u = r.scalar_one_or_none()
            if u and u.is_active: return u
        except JWTError:
            pass
    raise HTTPException(status_code=401, detail="Not authenticated")

class RegisterRequest(BaseModel):
    email: str
    username: str
    password: str

class LoginRequest(BaseModel):
    email: str
    password: str

@router.post("/register")
async def register(req: RegisterRequest, db: AsyncSession = Depends(get_db)):
    r = await db.execute(select(AuthUser).where(AuthUser.email == req.email))
    if r.scalar_one_or_none():
        raise HTTPException(400, "Email already registered")
    user = AuthUser(email=req.email, username=req.username,
                    hashed_pass=pwd_ctx.hash(req.password),
                    api_key=secrets.token_hex(32), plan="free", credits=100)
    db.add(user)
    await db.commit()
    await db.refresh(user)
    token = create_token(user.id, user.username)
    return {"access_token": token, "token_type": "bearer", "user_id": user.id,
            "username": user.username, "plan": user.plan, "credits": user.credits,
            "api_key": user.api_key}

@router.post("/login")
async def login(req: LoginRequest, db: AsyncSession = Depends(get_db)):
    r = await db.execute(select(AuthUser).where(AuthUser.email == req.email))
    u = r.scalar_one_or_none()
    if not u or not pwd_ctx.verify(req.password, u.hashed_pass):
        raise HTTPException(401, "Invalid email or password")
    if not u.is_active:
        raise HTTPException(403, "Account disabled")
    u.last_login = datetime.now(timezone.utc)
    await db.commit()
    token = create_token(u.id, u.username)
    return {"access_token": token, "token_type": "bearer", "user_id": u.id,
            "username": u.username, "plan": u.plan, "credits": u.credits,
            "api_key": u.api_key}

@router.get("/me")
async def get_me(user: AuthUser = Depends(get_current_user)):
    return {"id": user.id, "email": user.email, "username": user.username,
            "plan": user.plan, "credits": user.credits, "is_admin": user.is_admin,
            "api_key": user.api_key, "created_at": user.created_at.isoformat()}

@router.post("/rotate-key")
async def rotate_key(user: AuthUser = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    user.api_key = secrets.token_hex(32)
    await db.commit()
    return {"api_key": user.api_key}

@router.get("/usage")
async def get_usage(user: AuthUser = Depends(get_current_user)):
    return {"plan": user.plan, "credits": user.credits, "user_id": user.id}


# ── API Key Settings (write to .env file) ──────────
class KeysUpdate(BaseModel):
    OPENAI_API_KEY:      str = ""
    ANTHROPIC_API_KEY:   str = ""
    ELEVENLABS_API_KEY:  str = ""
    ELEVENLABS_VOICE_ID: str = ""
    WHATSAPP_TOKEN:      str = ""
    WHATSAPP_PHONE_ID:   str = ""
    VAPI_API_KEY:        str = ""
    TWILIO_ACCOUNT_SID:  str = ""
    TWILIO_AUTH_TOKEN:   str = ""
    TWILIO_PHONE:        str = ""
    GEMINI_API_KEY:      str = ""
    REPLICATE_API_KEY:   str = ""
    NOTION_API_KEY:      str = ""
    HEYGEN_API_KEY:      str = ""
    STRIPE_SECRET_KEY:   str = ""

@router.post("/settings/keys")
async def save_api_keys(keys: KeysUpdate):
    """Save API keys to .env file and reload settings"""
    env_path = ".env"
    # Read existing
    existing = {}
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if "=" in line and not line.startswith("#"):
                    k, _, v = line.partition("=")
                    existing[k.strip()] = v.strip()
    # Update only non-empty values
    for field, val in keys.dict().items():
        if val and val.strip():
            existing[field] = val.strip()
    # Write back
    with open(env_path, "w") as f:
        for k, v in existing.items():
            f.write(f"{k}={v}\n")
    # Reload settings cache
    from config import get_settings
    get_settings.cache_clear()
    # Reload the actual module-level settings object
    import importlib, config as cfg_module
    importlib.reload(cfg_module)
    return {"status": "saved", "keys_updated": [k for k,v in keys.dict().items() if v]}

@router.get("/settings/keys")
async def get_api_keys_status():
    """Return which API keys are configured (not the values)"""
    from config import settings as s
    return {
        "openai":      bool(s.OPENAI_API_KEY),
        "anthropic":   bool(s.ANTHROPIC_API_KEY),
        "elevenlabs":  bool(s.ELEVENLABS_API_KEY),
        "voice_id":    bool(s.ELEVENLABS_VOICE_ID),
        "whatsapp":    bool(s.WHATSAPP_TOKEN and s.WHATSAPP_PHONE_ID),
        "vapi":        bool(s.VAPI_API_KEY),
        "twilio":      bool(s.TWILIO_ACCOUNT_SID),
        "gemini":      bool(s.GEMINI_API_KEY),
        "replicate":   bool(s.REPLICATE_API_KEY),
        "notion":      bool(s.NOTION_API_KEY),
        "heygen":      bool(s.HEYGEN_API_KEY),
        "stripe":      bool(s.STRIPE_SECRET_KEY),
    }


# ── Credit tracking ─────────────────────────────────────────────
CREDIT_COSTS = {
    "image_generate": 10,
    "video_generate": 50,
    "voice_clone": 20,
    "tts": 2,
    "avatar_generate": 30,
    "translate": 1,
    "transcribe": 3,
    "chat_message": 1,
    "face_clone": 15,
    "short_video": 40,
    "call_make": 25,
    "sms_send": 1,
    "notion_page": 2,
    "scheduler_post": 5,
}

async def deduct_credits(user_id: int, action: str, db: AsyncSession) -> bool:
    """Deduct credits for an action. Returns False if insufficient credits."""
    cost = CREDIT_COSTS.get(action, 0)
    if cost == 0:
        return True
    result = await db.execute(select(AuthUser).where(AuthUser.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        return False
    if user.plan == "enterprise" or user.is_admin:
        return True  # Unlimited
    if user.credits < cost:
        return False
    user.credits -= cost
    # Log usage
    from database import UsageLog
    log = UsageLog(user_id=user_id, action=action, cost=cost,
                   model="aura", tokens=0)
    db.add(log)
    await db.commit()
    return True

@router.get("/credits")
async def get_credits(user: AuthUser = Depends(get_current_user)):
    return {"credits": user.credits, "plan": user.plan, "unlimited": user.is_admin or user.plan == "enterprise"}

@router.post("/credits/add")
async def add_credits(amount: int, user: AuthUser = Depends(get_current_user),
                      db: AsyncSession = Depends(get_db)):
    """Admin-only: add credits to current user"""
    if not user.is_admin:
        raise HTTPException(403, "Admin only")
    user.credits += amount
    await db.commit()
    return {"credits": user.credits, "added": amount}

"""AURA - SSE streaming: AI chat tokens + job progress + voice pipeline"""
import asyncio, json, httpx
from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from config import settings
import uuid, os

router = APIRouter()
_jobs: dict = {}

def update_job(job_id: str, **kwargs):
    _jobs[job_id] = {**_jobs.get(job_id, {}), **kwargs}

@router.get("/chat")
async def stream_chat(message: str, model: str = "claude",
                       system: str = "You are AURA, a helpful AI assistant."):
    async def gen():
        try:
            if model == "claude":
                async with httpx.AsyncClient(timeout=60) as client:
                    async with client.stream("POST","https://api.anthropic.com/v1/messages",
                        headers={"x-api-key": settings.ANTHROPIC_API_KEY,
                                 "anthropic-version": "2023-06-01",
                                 "content-type": "application/json"},
                        json={"model": settings.DEFAULT_AI_MODEL, "max_tokens": 1024,
                              "system": system, "stream": True,
                              "messages": [{"role": "user","content": message}]}) as resp:
                        async for line in resp.aiter_lines():
                            if line.startswith("data: "):
                                try:
                                    d = json.loads(line[6:])
                                    if d.get("type") == "content_block_delta":
                                        t = d.get("delta",{}).get("text","")
                                        if t: yield f"data: {json.dumps({'token':t})}\n\n"
                                except json.JSONDecodeError:
                                    pass
            elif model == "gpt4o":
                async with httpx.AsyncClient(timeout=60) as client:
                    async with client.stream("POST","https://api.openai.com/v1/chat/completions",
                        headers={"Authorization": f"Bearer {settings.OPENAI_API_KEY}"},
                        json={"model":"gpt-4o","stream":True,"max_tokens":1024,
                              "messages":[{"role":"system","content":system},
                                          {"role":"user","content":message}]}) as resp:
                        async for line in resp.aiter_lines():
                            if line.startswith("data: ") and line != "data: [DONE]":
                                try:
                                    d = json.loads(line[6:])
                                    t = d["choices"][0]["delta"].get("content","")
                                    if t: yield f"data: {json.dumps({'token':t})}\n\n"
                                except: pass
            yield f"data: {json.dumps({'done':True})}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'error':str(e)})}\n\n"
    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control":"no-cache","Connection":"keep-alive","X-Accel-Buffering":"no"})

@router.get("/job/{job_id}")
async def stream_job(job_id: str, request: Request):
    async def gen():
        while True:
            if await request.is_disconnected(): break
            job = _jobs.get(job_id, {"status":"queued","progress":0})
            yield f"data: {json.dumps(job)}\n\n"
            if job.get("status") in ("done","error","timeout"): break
            await asyncio.sleep(2)
    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control":"no-cache","Connection":"keep-alive"})

class VoicePipelineRequest(BaseModel):
    text: str
    model: str = "claude"
    voice_id: str = ""
    language: str = "en"
    history: list = []

@router.post("/voice-pipeline")
async def voice_pipeline(req: VoicePipelineRequest):
    messages = req.history + [{"role": "user", "content": req.text}]
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post("https://api.anthropic.com/v1/messages",
            headers={"x-api-key": settings.ANTHROPIC_API_KEY,
                     "anthropic-version": "2023-06-01", "content-type": "application/json"},
            json={"model": settings.DEFAULT_AI_MODEL, "max_tokens": 512,
                  "system": "You are AURA, a concise voice AI assistant. Keep responses to 1-3 sentences.",
                  "messages": messages})
    text = r.json().get("content",[{}])[0].get("text","")
    vid  = req.voice_id or settings.ELEVENLABS_VOICE_ID
    audio_url = ""
    if vid and settings.ELEVENLABS_API_KEY:
        async with httpx.AsyncClient(timeout=30) as client:
            r2 = await client.post(
                f"https://api.elevenlabs.io/v1/text-to-speech/{vid}",
                headers={"xi-api-key": settings.ELEVENLABS_API_KEY, "Content-Type":"application/json"},
                json={"text": text[:1000], "model_id": settings.DEFAULT_VOICE_MODEL,
                      "voice_settings":{"stability":0.5,"similarity_boost":0.85}})
            if r2.status_code == 200:
                fname = f"{uuid.uuid4()}.mp3"
                path  = f"{settings.STORAGE_PATH}/audio/{fname}"
                os.makedirs(f"{settings.STORAGE_PATH}/audio", exist_ok=True)
                with open(path,"wb") as f: f.write(r2.content)
                audio_url = f"/media/audio/{fname}"
    return {"text": text, "audio_url": audio_url, "model": req.model}

"""AURA - Phone calls: Vapi.ai outbound/inbound + Twilio SMS"""
import httpx
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional
from config import settings

router = APIRouter()
VAPI = "https://api.vapi.ai"

class CallRequest(BaseModel):
    phone_number: str
    message: str
    voice_id: str = ""
    language: str = "en"
    context: str = ""
    max_duration: int = 300

@router.post("/make-call")
async def make_call(req: CallRequest):
    if not settings.VAPI_API_KEY:
        return {"error":"Add VAPI_API_KEY to .env","phone":req.phone_number}
    voice_id = req.voice_id or settings.ELEVENLABS_VOICE_ID
    payload  = {
        "customer": {"number": req.phone_number},
        "assistant": {
            "model": {"provider":"anthropic","model":settings.DEFAULT_AI_MODEL,
                      "messages":[{"role":"system","content":
                                   f"You are AURA. Context: {req.context or 'General assistant'}. Opening: {req.message}"}]},
            "voice": {"provider":"11labs","voiceId":voice_id or "21m00Tcm4TlvDq8ikWAM"},
            "firstMessage": req.message,
            "maxDurationSeconds": req.max_duration,
            "recordingEnabled": True,
        }
    }
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(f"{VAPI}/call/phone",
            headers={"Authorization":f"Bearer {settings.VAPI_API_KEY}","Content-Type":"application/json"},
            json=payload)
        data = r.json()
    return {"call_id":data.get("id",""),"status":data.get("status",""),"phone":req.phone_number}

@router.get("/call/{call_id}")
async def get_call_status(call_id: str):
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.get(f"{VAPI}/call/{call_id}",
            headers={"Authorization":f"Bearer {settings.VAPI_API_KEY}"})
        data = r.json()
    return {"call_id":call_id,"status":data.get("status"),
            "recording":data.get("recordingUrl",""),"transcript":data.get("transcript",""),
            "summary":data.get("summary","")}

@router.get("/calls")
async def list_calls(limit: int = 20):
    if not settings.VAPI_API_KEY: return {"results":[],"note":"Add VAPI_API_KEY"}
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.get(f"{VAPI}/call?limit={limit}",
            headers={"Authorization":f"Bearer {settings.VAPI_API_KEY}"})
        return r.json()

@router.delete("/call/{call_id}")
async def end_call(call_id: str):
    async with httpx.AsyncClient(timeout=10) as client:
        await client.delete(f"{VAPI}/call/{call_id}",
            headers={"Authorization":f"Bearer {settings.VAPI_API_KEY}"})
    return {"status":"ended","call_id":call_id}

@router.post("/inbound-webhook")
async def inbound_call_webhook(request: Request):
    body     = await request.json()
    msg_type = body.get("message",{}).get("type","")
    if msg_type == "assistant-request":
        return JSONResponse({"assistant":{
            "model":{"provider":"anthropic","model":settings.DEFAULT_AI_MODEL,
                     "messages":[{"role":"system","content":"You are AURA, a professional AI phone assistant. Be concise."}]},
            "voice":{"provider":"11labs","voiceId":settings.ELEVENLABS_VOICE_ID or "21m00Tcm4TlvDq8ikWAM"},
            "firstMessage":"Hello! This is AURA, your AI assistant. How can I help you today?",
            "recordingEnabled":True}})
    return JSONResponse({"status":"ok"})

@router.post("/create-assistant")
async def create_vapi_assistant(name: str = "AURA Assistant"):
    if not settings.VAPI_API_KEY: return {"error":"Add VAPI_API_KEY"}
    payload = {"name":name,
               "model":{"provider":"anthropic","model":settings.DEFAULT_AI_MODEL,
                        "messages":[{"role":"system","content":"You are AURA. Be helpful and concise."}]},
               "voice":{"provider":"11labs","voiceId":settings.ELEVENLABS_VOICE_ID or "21m00Tcm4TlvDq8ikWAM"},
               "firstMessage":"Hello! I am AURA. How can I help?","recordingEnabled":True}
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.post(f"{VAPI}/assistant",
            headers={"Authorization":f"Bearer {settings.VAPI_API_KEY}","Content-Type":"application/json"},
            json=payload)
        data = r.json()
    return {"assistant_id":data.get("id"),"name":name,"status":"created"}

class SMSRequest(BaseModel):
    to: str
    message: str

@router.post("/sms")
async def send_sms(req: SMSRequest):
    if not settings.TWILIO_ACCOUNT_SID: return {"error":"Add TWILIO credentials"}
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.post(
            f"https://api.twilio.com/2010-04-01/Accounts/{settings.TWILIO_ACCOUNT_SID}/Messages.json",
            auth=(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN),
            data={"From":settings.TWILIO_PHONE,"To":req.to,"Body":req.message})
        data = r.json()
    return {"sid":data.get("sid"),"status":data.get("status"),"to":req.to}

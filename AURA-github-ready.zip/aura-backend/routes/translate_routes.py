"""AURA - AI Translator: 50+ languages, text, voice, documents"""
import httpx, uuid, os
from fastapi import APIRouter, UploadFile, File, Form
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from config import settings

router = APIRouter()

LANGUAGES = {
    "af":"Afrikaans","ar":"Arabic","zh":"Chinese","hr":"Croatian","cs":"Czech",
    "da":"Danish","nl":"Dutch","en":"English","fr":"French","de":"German",
    "el":"Greek","gu":"Gujarati","ha":"Hausa","he":"Hebrew","hi":"Hindi",
    "id":"Indonesian","it":"Italian","ja":"Japanese","ko":"Korean","ms":"Malay",
    "mr":"Marathi","ne":"Nepali","no":"Norwegian","fa":"Persian","pl":"Polish",
    "pt":"Portuguese","pa":"Punjabi","ro":"Romanian","ru":"Russian","sr":"Serbian",
    "si":"Sinhala","sk":"Slovak","so":"Somali","es":"Spanish","sw":"Swahili",
    "sv":"Swedish","tl":"Tagalog","ta":"Tamil","te":"Telugu","th":"Thai",
    "tr":"Turkish","uk":"Ukrainian","ur":"Urdu","vi":"Vietnamese","cy":"Welsh",
    "xh":"Xhosa","yo":"Yoruba","zu":"Zulu","wo":"Wolof","ff":"Fula",
}

class TranslateRequest(BaseModel):
    text: str
    target_lang: str
    source_lang: str = "auto"
    model: str = "claude"
    voice_output: bool = False
    voice_id: str = ""

@router.post("/text")
async def translate_text(req: TranslateRequest):
    lang_name  = LANGUAGES.get(req.target_lang, req.target_lang)
    prompt     = "Translate to " + lang_name + ". Return ONLY the translation:\n\n" + req.text
    translated = await _call_llm(prompt, req.model)
    result = {
        "original":    req.text,
        "translated":  translated,
        "source_lang": req.source_lang,
        "target_lang": req.target_lang,
        "target_name": lang_name,
    }
    if req.voice_output and settings.ELEVENLABS_API_KEY:
        vid              = req.voice_id or settings.ELEVENLABS_VOICE_ID
        result["audio_url"] = await _tts(translated, vid)
    return result

@router.post("/detect")
async def detect_language(text: str):
    prompt = "Detect language ISO code (e.g. fr, ar, wo, en). Return ONLY the 2-letter code:\n\n" + text[:300]
    code   = (await _call_llm(prompt, "claude")).strip().lower()[:5]
    return {"code": code, "language": LANGUAGES.get(code, "Unknown")}

@router.get("/languages")
async def list_languages():
    return {
        "languages": [{"code": k, "name": v} for k, v in sorted(LANGUAGES.items(), key=lambda x: x[1])],
        "count": len(LANGUAGES),
    }

@router.post("/document")
async def translate_document(
    file: UploadFile = File(...),
    target_lang: str = Form("fr"),
    model: str = Form("claude"),
):
    content = await file.read()
    try:   text = content.decode("utf-8")
    except: text = content.decode("latin-1")
    lang_name = LANGUAGES.get(target_lang, target_lang)
    chunks    = [text[i:i+2000] for i in range(0, len(text), 2000)]
    translated_chunks = []
    for chunk in chunks[:10]:
        prompt = "Translate to " + lang_name + ", preserve formatting:\n\n" + chunk
        t = await _call_llm(prompt, model)
        translated_chunks.append(t)
    result = "\n".join(translated_chunks)
    fname  = "translated_" + target_lang + "_" + (file.filename or "document.txt")
    return StreamingResponse(
        iter([result.encode("utf-8")]),
        media_type="text/plain; charset=utf-8",
        headers={"Content-Disposition": f"attachment; filename={fname}"},
    )

@router.post("/voice")
async def translate_voice(
    audio: UploadFile = File(...),
    target_lang: str = Form("fr"),
    voice_id: str = Form(""),
    model: str = Form("claude"),
):
    audio_bytes = await audio.read()
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(
            "https://api.openai.com/v1/audio/transcriptions",
            headers={"Authorization": "Bearer " + settings.OPENAI_API_KEY},
            files={"file": (audio.filename or "audio.ogg", audio_bytes, "audio/ogg")},
            data={"model": "whisper-1", "response_format": "verbose_json"},
        )
        data        = r.json()
        source_text = data.get("text", "")
        source_lang = data.get("language", "unknown")
    lang_name  = LANGUAGES.get(target_lang, target_lang)
    prompt     = "Translate to " + lang_name + ":\n\n" + source_text
    translated = await _call_llm(prompt, model)
    vid        = voice_id or settings.ELEVENLABS_VOICE_ID
    audio_url  = await _tts(translated, vid) if vid else ""
    return {
        "source_text": source_text,
        "source_lang": source_lang,
        "translated":  translated,
        "target_lang": target_lang,
        "audio_url":   audio_url,
    }

async def _call_llm(prompt: str, model: str) -> str:
    async with httpx.AsyncClient(timeout=30) as client:
        if model in ("claude", "anthropic"):
            r = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={"x-api-key": settings.ANTHROPIC_API_KEY,
                         "anthropic-version": "2023-06-01",
                         "content-type": "application/json"},
                json={"model": settings.DEFAULT_AI_MODEL, "max_tokens": 2000,
                      "messages": [{"role": "user", "content": prompt}]},
            )
            return r.json().get("content", [{}])[0].get("text", "")
        elif model == "gpt4o":
            r = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": "Bearer " + settings.OPENAI_API_KEY},
                json={"model": "gpt-4o", "max_tokens": 2000,
                      "messages": [{"role": "user", "content": prompt}]},
            )
            return r.json()["choices"][0]["message"]["content"]
        elif model == "gemini":
            r = await client.post(
                "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=" + settings.GEMINI_API_KEY,
                json={"contents": [{"role": "user", "parts": [{"text": prompt}]}]},
            )
            return r.json()["candidates"][0]["content"]["parts"][0]["text"]
    return ""

async def _tts(text: str, voice_id: str) -> str:
    if not voice_id or not settings.ELEVENLABS_API_KEY:
        return ""
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(
            "https://api.elevenlabs.io/v1/text-to-speech/" + voice_id,
            headers={"xi-api-key": settings.ELEVENLABS_API_KEY, "Content-Type": "application/json"},
            json={"text": text[:2500], "model_id": settings.DEFAULT_VOICE_MODEL},
        )
        if r.status_code != 200:
            return ""
        fname = str(uuid.uuid4()) + ".mp3"
        path  = settings.STORAGE_PATH + "/audio/" + fname
        os.makedirs(settings.STORAGE_PATH + "/audio", exist_ok=True)
        with open(path, "wb") as f:
            f.write(r.content)
        return "/media/audio/" + fname

/**
 * AURA API Client — v5.0
 * Standalone JavaScript client for all AURA API endpoints.
 * 
 * Usage:
 *   <script src="/api-client.js"></script>
 *   const aura = new AuraClient('http://localhost:8000');
 *   await aura.auth.login('admin@aura.ai', 'aura2025!');
 *   const imgs = await aura.image.generate('sunset over Dakar');
 */

class AuraClient {
  constructor(baseUrl = 'http://localhost:8000') {
    this.base   = baseUrl.replace(/\/$/, '');
    this.token  = localStorage.getItem('aura-token') || '';
    this.user   = null;
  }

  // ── Core request ────────────────────────────────
  async _req(method, path, body = null, isForm = false) {
    const opts = { method, headers: {} };
    if (this.token) opts.headers['Authorization'] = 'Bearer ' + this.token;
    if (body && !isForm) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    } else if (body && isForm) {
      opts.body = body;
    }
    const res = await fetch(this.base + path, opts);
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: res.statusText }));
      throw new Error(err.detail || `Error ${res.status}`);
    }
    return res.json();
  }

  // ── Auth ─────────────────────────────────────────
  auth = {
    login: async (email, password) => {
      const r = await this._req('POST', '/api/auth/login', { email, password });
      this.token = r.access_token;
      this.user  = r;
      localStorage.setItem('aura-token', this.token);
      return r;
    },
    register: async (email, username, password) => {
      const r = await this._req('POST', '/api/auth/register', { email, username, password });
      this.token = r.access_token;
      this.user  = r;
      localStorage.setItem('aura-token', this.token);
      return r;
    },
    me:         () => this._req('GET', '/api/auth/me'),
    rotateKey:  () => this._req('POST', '/api/auth/rotate-key'),
    logout:     ()  => { this.token = ''; localStorage.removeItem('aura-token'); },
  };

  // ── Image ────────────────────────────────────────
  image = {
    generate:  (prompt, model='dall-e-3', style='photorealistic', n=4) =>
      this._req('POST', '/api/image/generate', { prompt, model, style, n }),
    faceClone: (formData) => this._req('POST', '/api/image/face-clone', formData, true),
    library:   () => this._req('GET', '/api/image/library'),
    edit:      (imageUrl, instruction) =>
      this._req('POST', '/api/image/edit', { image_url: imageUrl, instruction }),
  };

  // ── Video ────────────────────────────────────────
  video = {
    generate: (prompt, model='veo3', duration=30, aspectRatio='16:9', addMusic=true) =>
      this._req('POST', '/api/video/generate', { prompt, model, duration, aspect_ratio: aspectRatio, add_music: addMusic }),
    status:   (jobId) => this._req('GET', `/api/video/status/${jobId}`),
    short:    (niche, topic, duration=60) =>
      this._req('POST', `/api/video/short?niche=${encodeURIComponent(niche)}&topic=${encodeURIComponent(topic)}&duration=${duration}`),
    library:  () => this._req('GET', '/api/video/library'),
  };

  // ── Voice ────────────────────────────────────────
  voice = {
    clone:       (name, audioFile) => {
      const fd = new FormData(); fd.append('name', name); fd.append('audio', audioFile);
      return this._req('POST', '/api/voice/clone', fd, true);
    },
    tts: async (text, voiceId, stability=0.5, similarity=0.85) => {
      const res = await fetch(this.base + '/api/voice/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + this.token },
        body: JSON.stringify({ text, voice_id: voiceId, stability, similarity }),
      });
      return res.blob();
    },
    transcribe:  (audioFile, language='') => {
      const fd = new FormData(); fd.append('audio', audioFile); if (language) fd.append('language', language);
      return this._req('POST', '/api/voice/transcribe', fd, true);
    },
    voices:      () => this._req('GET', '/api/voice/voices'),
    myClones:    () => this._req('GET', '/api/voice/my-clones'),
    deleteClone: (voiceId) => this._req('DELETE', `/api/voice/clone/${voiceId}`),
  };

  // ── Avatar ───────────────────────────────────────
  avatar = {
    heygen:  (script, language='en', speed=1.0, avatarId='') =>
      this._req('POST', '/api/avatar/heygen/generate', { script, language, speed, avatar_id: avatarId }),
    did:     (photoFile, script, voiceId='') => {
      const fd = new FormData(); fd.append('photo', photoFile); fd.append('script', script); if (voiceId) fd.append('voice_id', voiceId);
      return this._req('POST', '/api/avatar/did/generate', fd, true);
    },
    status:  (jobId) => this._req('GET', `/api/avatar/status/${jobId}`),
    avatars: () => this._req('GET', '/api/avatar/heygen/avatars'),
  };

  // ── Shorts ───────────────────────────────────────
  shorts = {
    generateScript: (niche, topic, duration=60, language='en') =>
      this._req('POST', '/api/shorts/generate-script', { niche, topic, duration, language }),
    niches: () => this._req('GET', '/api/shorts/niches'),
  };

  // ── WhatsApp ─────────────────────────────────────
  whatsapp = {
    send:             (phone, message) => this._req('POST', '/api/whatsapp/send', { phone, message }),
    conversations:    (phone) => this._req('GET', `/api/whatsapp/conversations/${phone}`),
    clearConversation:(phone) => this._req('DELETE', `/api/whatsapp/conversations/${phone}`),
    contacts:         () => this._req('GET', '/api/whatsapp/contacts'),
  };

  // ── Calls ────────────────────────────────────────
  calls = {
    make:           (phoneNumber, message, context='', maxDuration=300) =>
      this._req('POST', '/api/calls/make-call', { phone_number: phoneNumber, message, context, max_duration: maxDuration }),
    status:         (callId) => this._req('GET', `/api/calls/call/${callId}`),
    list:           (limit=20) => this._req('GET', `/api/calls/calls?limit=${limit}`),
    end:            (callId) => this._req('DELETE', `/api/calls/call/${callId}`),
    sms:            (to, message) => this._req('POST', '/api/calls/sms', { to, message }),
    createAssistant:(name) => this._req('POST', `/api/calls/create-assistant?name=${encodeURIComponent(name)}`),
  };

  // ── Calendar ─────────────────────────────────────
  calendar = {
    create:   (title, start, duration=60, location='', attendees=[]) =>
      this._req('POST', '/api/calendar/create', { title, start, duration, location, attendees }),
    today:    () => this._req('GET', '/api/calendar/today'),
    aiBook:   (text) => this._req('POST', `/api/calendar/ai-book?text=${encodeURIComponent(text)}`),
  };

  // ── Email ────────────────────────────────────────
  email = {
    send:     (to, subject, body, cc='') => this._req('POST', '/api/email/send', { to, subject, body, cc }),
    aiDraft:  (context, tone='professional', language='en') =>
      this._req('POST', '/api/email/ai-draft', { context, tone, language }),
  };

  // ── Google ───────────────────────────────────────
  google = {
    status:   () => this._req('GET', '/api/google/status'),
    inbox:    (maxResults=10) => this._req('GET', `/api/google/gmail/inbox?max_results=${maxResults}`),
    sendMail: (to, subject, body) =>
      this._req('POST', `/api/google/gmail/send?to=${encodeURIComponent(to)}&subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`),
    todayEvents: () => this._req('GET', '/api/google/calendar/today'),
  };

  // ── Contacts ─────────────────────────────────────
  contacts = {
    list:    (search='', limit=50) => this._req('GET', `/api/contacts/?search=${encodeURIComponent(search)}&limit=${limit}`),
    get:     (id) => this._req('GET', `/api/contacts/${id}`),
    create:  (data) => this._req('POST', '/api/contacts/', data),
    update:  (id, data) => this._req('PATCH', `/api/contacts/${id}`, data),
    delete:  (id) => this._req('DELETE', `/api/contacts/${id}`),
    tags:    () => this._req('GET', '/api/contacts/tags/all'),
    lookup:  (phone) => this._req('GET', `/api/contacts/lookup/phone/${phone}`),
    broadcast: (message, tag='', contactIds=[]) =>
      this._req('POST', '/api/contacts/broadcast', { message, tag, contact_ids: contactIds }),
    exportCsv: () => fetch(this.base + '/api/contacts/export/csv', {
      headers: { Authorization: 'Bearer ' + this.token }
    }).then(r => r.blob()),
  };

  // ── Translate ────────────────────────────────────
  translate = {
    text:      (text, targetLang, sourceLang='auto', voiceOutput=false) =>
      this._req('POST', '/api/translate/text', { text, target_lang: targetLang, source_lang: sourceLang, voice_output: voiceOutput }),
    detect:    (text) => this._req('POST', `/api/translate/detect?text=${encodeURIComponent(text)}`),
    languages: () => this._req('GET', '/api/translate/languages'),
  };

  // ── Agent chat ───────────────────────────────────
  agent = {
    chat: (message, model='claude', history=[], system='You are AURA, a helpful AI assistant.') =>
      this._req('POST', '/api/agent/chat', { message, model, history, system }),
  };

  // ── Streaming chat (EventSource) ─────────────────
  stream = {
    chat: (message, model='claude', onToken, onDone, onError) => {
      const params = new URLSearchParams({ message, model });
      const src = new EventSource(this.base + '/api/stream/chat?' + params.toString());
      src.onmessage = e => {
        try {
          const d = JSON.parse(e.data);
          if (d.token) onToken(d.token);
          if (d.done)  { onDone?.(); src.close(); }
          if (d.error) { onError?.(d.error); src.close(); }
        } catch {}
      };
      src.onerror = err => { onError?.(err); src.close(); };
      return src; // return to allow manual .close()
    },
    voicePipeline: (text, model='claude', voiceId='', language='en') =>
      this._req('POST', '/api/stream/voice-pipeline', { text, model, voice_id: voiceId, language }),
  };

  // ── Scheduler ────────────────────────────────────
  scheduler = {
    schedule:    (title, mediaUrl, caption='', hashtags='', platforms='tiktok,instagram', scheduledAt='') =>
      this._req('POST', `/api/scheduler/schedule?title=${encodeURIComponent(title)}&media_url=${encodeURIComponent(mediaUrl)}&caption=${encodeURIComponent(caption)}&hashtags=${encodeURIComponent(hashtags)}&platforms=${encodeURIComponent(platforms)}${scheduledAt?'&scheduled_at='+encodeURIComponent(scheduledAt):''}`),
    calendar:    () => this._req('GET', '/api/scheduler/calendar'),
    aiCaption:   (title, niche='') => this._req('GET', `/api/scheduler/ai-caption?title=${encodeURIComponent(title)}&niche=${encodeURIComponent(niche)}`),
    cancel:      (postId) => this._req('DELETE', `/api/scheduler/post/${postId}`),
    analytics:   () => this._req('GET', '/api/scheduler/analytics'),
  };

  // ── Notion ───────────────────────────────────────
  notion = {
    createPage:  (title, content, icon='📝') => this._req('POST', '/api/notion/page', { title, content, icon }),
    search:      (query, limit=10) => this._req('GET', `/api/notion/search?query=${encodeURIComponent(query)}&limit=${limit}`),
    databases:   () => this._req('GET', '/api/notion/databases'),
    sync:        () => this._req('POST', '/api/notion/sync-from-aura'),
  };

  // ── Analytics ────────────────────────────────────
  analytics = {
    dashboard:    () => this._req('GET', '/api/analytics/dashboard'),
    costEstimate: (images=0, videoSeconds=0, ttsChars=0, claudeTokens=0, callMinutes=0) =>
      this._req('GET', `/api/analytics/cost-estimate?images=${images}&videos_seconds=${videoSeconds}&tts_chars=${ttsChars}&claude_tokens=${claudeTokens}&calls_minutes=${callMinutes}`),
    prices:       () => this._req('GET', '/api/analytics/prices'),
    system:       () => this._req('GET', '/api/analytics/system'),
  };

  // ── Library ──────────────────────────────────────
  library = {
    list:   (mediaType='') => this._req('GET', `/api/library/all${mediaType ? '?media_type='+mediaType : ''}`),
    delete: (id) => this._req('DELETE', `/api/library/${id}`),
    stats:  () => this._req('GET', '/api/library/stats'),
    upload: (file, name, mediaType) => {
      const fd = new FormData(); fd.append('file', file); fd.append('name', name || file.name); fd.append('media_type', mediaType || '');
      return this._req('POST', '/api/library/upload', fd, true);
    },
  };

  // ── Notes ────────────────────────────────────────
  notes = {
    create:     (title, content, source='api') => this._req('POST', '/api/notes/create', { title, content, source }),
    list:       () => this._req('GET', '/api/notes/list'),
    get:        (id) => this._req('GET', `/api/notes/${id}`),
    delete:     (id) => this._req('DELETE', `/api/notes/${id}`),
    aiSummarize:(id) => this._req('POST', `/api/notes/ai-summarize?note_id=${id}`),
  };

  // ── Payments ─────────────────────────────────────
  payments = {
    plans:    () => this._req('GET', '/api/payments/plans'),
    checkout: (plan, userEmail, successUrl='', cancelUrl='') =>
      this._req('POST', '/api/payments/checkout', { plan, user_email: userEmail, success_url: successUrl, cancel_url: cancelUrl }),
    status:   (email) => this._req('GET', `/api/payments/status/${encodeURIComponent(email)}`),
  };

  // ── ComfyUI ──────────────────────────────────────
  comfy = {
    imageFromText: (prompt, negative='blurry', steps=30, cfg=7.0, width=1024, height=1024) =>
      this._req('POST', `/api/comfy/comfy/image-from-text?prompt=${encodeURIComponent(prompt)}&negative=${encodeURIComponent(negative)}&steps=${steps}&cfg=${cfg}&width=${width}&height=${height}`),
    status:  (promptId) => this._req('GET', `/api/comfy/comfy/status/${promptId}`),
    hailo:   () => this._req('GET', '/api/comfy/hailo/status'),
    models:  () => this._req('GET', '/api/comfy/hailo/models'),
  };

  // ── Notifications (SSE) ──────────────────────────
  notifications = {
    stream: (onNotification, sessionId='') => {
      const src = new EventSource(this.base + '/api/notifications/stream?session_id=' + sessionId);
      src.onmessage = e => {
        try {
          const n = JSON.parse(e.data);
          if (n.type !== 'heartbeat') onNotification(n);
        } catch {}
      };
      return src;
    },
    history: () => this._req('GET', '/api/notifications/history'),
    test:    (title='Test', body='Hello from AURA') =>
      this._req('POST', `/api/notifications/test?title=${encodeURIComponent(title)}&body=${encodeURIComponent(body)}`),
  };

  // ── Media / Suno ─────────────────────────────────
  media = {
    generateMusic: (prompt, style='cinematic', duration=30, instrumental=true) =>
      this._req('POST', '/api/media/music/generate', { prompt, style, duration, instrumental }),
    musicStatus:   (jobId) => this._req('GET', `/api/media/music/status/${jobId}`),
    sendImage:     (to, imageUrl, caption='') =>
      this._req('POST', '/api/media/whatsapp/send-image', { to, image_url: imageUrl, caption }),
    sendVideo:     (to, videoUrl, caption='') =>
      this._req('POST', '/api/media/whatsapp/send-video', { to, video_url: videoUrl, caption }),
    sendAudio:     (to, audioUrl) =>
      this._req('POST', '/api/media/whatsapp/send-audio', { to, audio_url: audioUrl }),
    webhookStatus: () => this._req('GET', '/api/media/webhooks/status'),
  };

  // ── Health ───────────────────────────────────────
  health = {
    check: () => this._req('GET', '/api/health'),
  };
}

// Auto-export for module environments
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { AuraClient };
}

// Example usage (runs only in browser console / non-module context):
// const aura = new AuraClient();
// await aura.auth.login('admin@aura.ai', 'aura2025!');
// const imgs = await aura.image.generate('sunset over Dakar, Senegal, photorealistic');
// console.log(imgs.images[0].url);

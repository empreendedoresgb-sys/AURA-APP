"""AURA AI Super Studio — FastAPI Backend v4.1 COMPLETE"""
import os, httpx
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from contextlib import asynccontextmanager

from routes import (
    graphify_routes,
    voice_routes, image_routes, video_routes, avatar_routes,
    whatsapp_routes, agent_routes, calendar_routes, email_routes,
    notes_routes, library_routes, shorts_routes, google_routes,
    comfy_routes, calls_routes, stream_routes, scheduler_routes,
    notion_routes, auth_routes, analytics_routes, media_routes,
    contacts_routes, translate_routes, payments_routes,
    notifications_routes,
)
from config import settings
from database import init_db
from middleware import register_middleware

@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    print("✅  AURA v4.1 — ALL SYSTEMS ONLINE")
    print(f"📖  Docs:     http://localhost:{settings.PORT}/docs")
    print(f"🌐  Frontend: http://localhost:{settings.PORT}")
    yield
    print("🛑  AURA shutdown")

app = FastAPI(
    title="AURA AI Super Studio v4.1",
    description="Voice · Image · Video · WhatsApp · Calls · Payments · Translate · 144 endpoints",
    version="4.1.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
register_middleware(app)

# All routers
app.include_router(graphify_routes.router, prefix="/api/graphify", tags=["✏️ Graphify"])
app.include_router(auth_routes.router,          prefix="/api/auth",          tags=["🔐 Auth"])
app.include_router(voice_routes.router,         prefix="/api/voice",         tags=["🎤 Voice"])
app.include_router(image_routes.router,         prefix="/api/image",         tags=["🎨 Image"])
app.include_router(video_routes.router,         prefix="/api/video",         tags=["🎬 Video"])
app.include_router(avatar_routes.router,        prefix="/api/avatar",        tags=["🧬 Avatar"])
app.include_router(shorts_routes.router,        prefix="/api/shorts",        tags=["⚡ Shorts"])
app.include_router(whatsapp_routes.router,      prefix="/api/whatsapp",      tags=["💬 WhatsApp"])
app.include_router(agent_routes.router,         prefix="/api/agent",         tags=["🤖 Agent"])
app.include_router(stream_routes.router,        prefix="/api/stream",        tags=["📡 Stream"])
app.include_router(calls_routes.router,         prefix="/api/calls",         tags=["📞 Calls"])
app.include_router(calendar_routes.router,      prefix="/api/calendar",      tags=["📅 Calendar"])
app.include_router(email_routes.router,         prefix="/api/email",         tags=["📧 Email"])
app.include_router(notes_routes.router,         prefix="/api/notes",         tags=["📝 Notes"])
app.include_router(library_routes.router,       prefix="/api/library",       tags=["📁 Library"])
app.include_router(google_routes.router,        prefix="/api/google",        tags=["🔑 Google"])
app.include_router(comfy_routes.router,         prefix="/api/comfy",         tags=["⚙️ ComfyUI"])
app.include_router(scheduler_routes.router,     prefix="/api/scheduler",     tags=["📤 Scheduler"])
app.include_router(notion_routes.router,        prefix="/api/notion",        tags=["📓 Notion"])
app.include_router(analytics_routes.router,     prefix="/api/analytics",     tags=["📊 Analytics"])
app.include_router(media_routes.router,         prefix="/api/media",         tags=["🎵 Media"])
app.include_router(contacts_routes.router,      prefix="/api/contacts",      tags=["👥 Contacts"])
app.include_router(translate_routes.router,     prefix="/api/translate",     tags=["🌍 Translate"])
app.include_router(payments_routes.router,      prefix="/api/payments",      tags=["💳 Payments"])
app.include_router(notifications_routes.router, prefix="/api/notifications", tags=["🔔 Notify"])

@app.get("/api/health", tags=["System"])
async def health():
    checks = {}
    async with httpx.AsyncClient(timeout=5) as client:
        for name, url, hdrs in [
            ("openai",     "https://api.openai.com/v1/models",
             {"Authorization": f"Bearer {settings.OPENAI_API_KEY}"}),
            ("elevenlabs", "https://api.elevenlabs.io/v1/user",
             {"xi-api-key": settings.ELEVENLABS_API_KEY}),
        ]:
            try:
                r = await client.get(url, headers=hdrs)
                checks[name] = "✅" if r.status_code == 200 else "❌"
            except Exception:
                checks[name] = "⚠️ unreachable"
    for name, key in [
        ("anthropic", settings.ANTHROPIC_API_KEY),
        ("gemini",    settings.GEMINI_API_KEY),
        ("whatsapp",  settings.WHATSAPP_TOKEN),
        ("vapi",      settings.VAPI_API_KEY),
        ("heygen",    settings.HEYGEN_API_KEY),
        ("notion",    settings.NOTION_API_KEY),
        ("twilio",    settings.TWILIO_ACCOUNT_SID),
        ("stripe",    settings.STRIPE_SECRET_KEY),
    ]:
        checks[name] = "✅ set" if key else "⚠️ missing"
    # Also verify Anthropic with a real ping
    if settings.ANTHROPIC_API_KEY:
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                r = await client.post(
                    "https://api.anthropic.com/v1/messages",
                    headers={"x-api-key": settings.ANTHROPIC_API_KEY,
                             "anthropic-version": "2023-06-01",
                             "content-type": "application/json"},
                    json={"model": "claude-haiku-4-5-20251001", "max_tokens": 1,
                          "messages": [{"role": "user", "content": "hi"}]})
                checks["claude"] = "✅" if r.status_code in (200, 400) else "❌"
        except Exception:
            checks["claude"] = "⚠️ unreachable"
    else:
        checks["claude"] = "⚠️ missing"
    # Replicate check
    checks["replicate"] = "✅ set" if settings.REPLICATE_API_KEY else "⚠️ missing"
    # Count configured vs missing
    ok = sum(1 for v in checks.values() if "✅" in v)
    total = len(checks)
    return {"status": "healthy", "version": "5.0.0", "checks": checks,
            "summary": f"{ok}/{total} APIs configured"}

os.makedirs("static", exist_ok=True)
os.makedirs("media",  exist_ok=True)

@app.get("/preview", tags=["System"])
async def preview_page():
    """Standalone live preview — opens AURA device simulator in new browser tab"""
    return FileResponse("static/preview.html")

app.mount("/media", StaticFiles(directory="media"),             name="media")
app.mount("/",      StaticFiles(directory="static", html=True), name="static")

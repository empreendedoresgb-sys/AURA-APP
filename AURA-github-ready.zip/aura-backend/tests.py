"""
AURA v4.1 — Complete Test Suite
Run: pytest tests.py -v --asyncio-mode=auto
"""
import pytest, asyncio, os, json

# ── Setup ──────────────────────────────────────
os.environ.setdefault("DATABASE_URL",      "sqlite:///./test_aura.db")
os.environ.setdefault("OPENAI_API_KEY",    "test-openai-key")
os.environ.setdefault("ANTHROPIC_API_KEY", "test-anthropic-key")
os.environ.setdefault("ELEVENLABS_API_KEY","test-eleven-key")
os.environ.setdefault("ELEVENLABS_VOICE_ID","test-voice-id")
os.environ.setdefault("WHATSAPP_TOKEN",    "test-wa-token")
os.environ.setdefault("WHATSAPP_PHONE_ID", "test-phone-id")
os.environ.setdefault("WHATSAPP_VERIFY_TOKEN","aura_verify_2025")
os.environ.setdefault("JWT_SECRET",        "test-jwt-secret-must-be-32-chars!!")

@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()

@pytest.fixture(scope="session")
async def client():
    from httpx import AsyncClient, ASGITransport
    from main import app
    from database import init_db
    # Initialize database tables before any tests run
    await init_db()
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as c:
        yield c
    # Cleanup test DB
    import os
    try: os.remove("./test_aura.db")
    except FileNotFoundError: pass

@pytest.fixture(scope="session")
async def auth_token(client):
    await client.post("/api/auth/register", json={
        "email": "test@aura.ai", "username": "testuser", "password": "test1234"})
    r = await client.post("/api/auth/login", json={
        "email": "test@aura.ai", "password": "test1234"})
    return r.json().get("access_token", "")

@pytest.fixture(scope="session")
def auth_headers(auth_token):
    return {"Authorization": f"Bearer {auth_token}"}

# ── Health ─────────────────────────────────────
class TestHealth:
    async def test_health_200(self, client):
        r = await client.get("/api/health")
        assert r.status_code == 200

    async def test_health_version(self, client):
        r = await client.get("/api/health")
        assert "version" in r.json()
        assert r.json()["status"] == "healthy"

    async def test_health_checks_present(self, client):
        r   = await client.get("/api/health")
        chk = r.json()["checks"]
        for key in ["openai","anthropic","gemini","whatsapp","vapi"]:
            assert key in chk

# ── Auth ───────────────────────────────────────
class TestAuth:
    async def test_register_new_user(self, client):
        r = await client.post("/api/auth/register", json={
            "email": "new2@aura.ai", "username": "newuser2", "password": "password123"})
        assert r.status_code == 200
        data = r.json()
        assert "access_token" in data
        assert "api_key" in data
        assert data["username"] == "newuser2"

    async def test_login_valid(self, client, auth_token):
        assert len(auth_token) > 20

    async def test_login_wrong_password(self, client):
        r = await client.post("/api/auth/login", json={
            "email": "test@aura.ai", "password": "wrongpassword"})
        assert r.status_code == 401

    async def test_login_unknown_email(self, client):
        r = await client.post("/api/auth/login", json={
            "email": "nobody@example.com", "password": "anything"})
        assert r.status_code == 401

    async def test_get_me_with_token(self, client, auth_headers):
        r = await client.get("/api/auth/me", headers=auth_headers)
        assert r.status_code == 200
        assert "email" in r.json()
        assert "plan" in r.json()

    async def test_get_me_without_token(self, client):
        r = await client.get("/api/auth/me")
        assert r.status_code == 401

    async def test_duplicate_email_rejected(self, client):
        await client.post("/api/auth/register", json={
            "email": "dup@aura.ai", "username": "dup1", "password": "pass"})
        r = await client.post("/api/auth/register", json={
            "email": "dup@aura.ai", "username": "dup2", "password": "pass"})
        assert r.status_code == 400

    async def test_rotate_api_key(self, client, auth_headers):
        r = await client.post("/api/auth/rotate-key", headers=auth_headers)
        assert r.status_code == 200
        assert "api_key" in r.json()

# ── Contacts ───────────────────────────────────
class TestContacts:
    async def test_create_contact(self, client):
        r = await client.post("/api/contacts/", json={
            "name": "Mamadou Diallo", "phone": "+221771234567",
            "email": "mamadou@test.com", "company": "Tech Dakar",
            "tags": ["client", "vip"]})
        assert r.status_code == 201
        data = r.json()
        assert data["name"] == "Mamadou Diallo"
        assert "client" in data["tags"]
        return data["id"]

    async def test_list_contacts(self, client):
        r = await client.get("/api/contacts/")
        assert r.status_code == 200
        assert "contacts" in r.json()
        assert "total" in r.json()

    async def test_search_contacts_by_name(self, client):
        await client.post("/api/contacts/", json={"name": "Fatou Sarr", "phone": "+221770000001"})
        r = await client.get("/api/contacts/?search=Fatou")
        assert r.status_code == 200
        names = [c["name"] for c in r.json()["contacts"]]
        assert any("Fatou" in n for n in names)

    async def test_search_contacts_by_phone(self, client):
        r = await client.get("/api/contacts/?search=221771234567")
        assert r.status_code == 200

    async def test_filter_by_tag(self, client):
        r = await client.get("/api/contacts/?tag=vip")
        assert r.status_code == 200
        for c in r.json()["contacts"]:
            assert "vip" in c["tags"]

    async def test_update_contact(self, client):
        cr  = await client.post("/api/contacts/", json={"name": "Update Test"})
        cid = cr.json()["id"]
        r   = await client.patch(f"/api/contacts/{cid}", json={"company": "New Corp"})
        assert r.status_code == 200
        assert r.json()["company"] == "New Corp"

    async def test_delete_contact(self, client):
        cr  = await client.post("/api/contacts/", json={"name": "To Delete"})
        cid = cr.json()["id"]
        r   = await client.delete(f"/api/contacts/{cid}")
        assert r.status_code == 200
        r2  = await client.get(f"/api/contacts/{cid}")
        assert r2.status_code == 404

    async def test_get_all_tags(self, client):
        r = await client.get("/api/contacts/tags/all")
        assert r.status_code == 200
        assert "tags" in r.json()

    async def test_lookup_by_phone(self, client):
        r = await client.get("/api/contacts/lookup/phone/221771234567")
        assert r.status_code == 200
        data = r.json()
        assert "found" in data

    async def test_export_csv(self, client):
        r = await client.get("/api/contacts/export/csv")
        assert r.status_code == 200
        assert "text/csv" in r.headers.get("content-type","")

# ── Notes ──────────────────────────────────────
class TestNotes:
    async def test_create_note(self, client):
        r = await client.post("/api/notes/create", json={
            "title": "Test Note", "content": "This is test content", "source": "test"})
        assert r.status_code == 200
        assert r.json()["title"] == "Test Note"

    async def test_list_notes(self, client):
        r = await client.get("/api/notes/list")
        assert r.status_code == 200
        assert "notes" in r.json()

    async def test_get_note_by_id(self, client):
        cr  = await client.post("/api/notes/create", json={"title": "Get Me", "content": "body text"})
        nid = cr.json()["id"]
        r   = await client.get(f"/api/notes/{nid}")
        assert r.status_code == 200
        assert r.json()["content"] == "body text"

    async def test_get_missing_note_404(self, client):
        r = await client.get("/api/notes/999999")
        assert r.status_code == 404

    async def test_delete_note(self, client):
        cr  = await client.post("/api/notes/create", json={"title": "Delete Me", "content": "x"})
        nid = cr.json()["id"]
        r   = await client.delete(f"/api/notes/{nid}")
        assert r.status_code == 200

# ── Library ────────────────────────────────────
class TestLibrary:
    async def test_list_library(self, client):
        r = await client.get("/api/library/all")
        assert r.status_code == 200
        assert "items" in r.json()

    async def test_list_by_type(self, client):
        for media_type in ["image", "video", "audio"]:
            r = await client.get(f"/api/library/all?media_type={media_type}")
            assert r.status_code == 200

    async def test_library_stats(self, client):
        r = await client.get("/api/library/stats")
        assert r.status_code == 200
        assert "counts" in r.json()

# ── Analytics ──────────────────────────────────
class TestAnalytics:
    async def test_dashboard(self, client):
        r = await client.get("/api/analytics/dashboard")
        assert r.status_code == 200
        data = r.json()
        assert "overview" in data
        assert "this_week" in data

    async def test_cost_estimate(self, client):
        r = await client.get("/api/analytics/cost-estimate?images=10&videos_seconds=60")
        assert r.status_code == 200
        data = r.json()
        assert "usd" in data
        assert "total_usd" in data
        assert "fcfa" in data
        assert data["usd"] >= 0
        assert data["total_usd"] == data["usd"]

    
    async def test_prices(self, client):
        r = await client.get("/api/analytics/prices")
        assert r.status_code == 200
        assert "prices" in r.json()

    async def test_system_health(self, client):
        r = await client.get("/api/analytics/system")
        assert r.status_code == 200
        data = r.json()
        assert "aura_version" in data
        assert "endpoints" in data
        assert "platform" in data
        assert data["aura_version"] == "5.0.0"

    
    async def test_social_analytics(self, client, auth_headers):
        r = await client.get("/api/analytics/social", headers=auth_headers)
        assert r.status_code == 200
        data = r.json()
        assert "total_posts" in data
        assert "published" in data
        assert "by_platform" in data
        assert "reach_estimate" in data

    
class TestWhatsApp:
    async def test_webhook_verify_success(self, client):
        r = await client.get("/api/whatsapp/webhook", params={
            "hub.mode": "subscribe",
            "hub.verify_token": "aura_verify_2025",
            "hub.challenge": "CHALLENGE_TOKEN_123"})
        assert r.status_code == 200
        assert r.text == "CHALLENGE_TOKEN_123"

    async def test_webhook_verify_wrong_token(self, client):
        r = await client.get("/api/whatsapp/webhook", params={
            "hub.mode": "subscribe",
            "hub.verify_token": "wrong_token",
            "hub.challenge": "TEST"})
        assert r.status_code == 403

    async def test_list_wa_contacts(self, client):
        r = await client.get("/api/whatsapp/contacts")
        assert r.status_code == 200
        assert "contacts" in r.json()

    async def test_get_conversation(self, client):
        r = await client.get("/api/whatsapp/conversations/+221771111111")
        assert r.status_code == 200
        assert "messages" in r.json()

# ── Translator ─────────────────────────────────
class TestTranslator:
    async def test_languages_list(self, client):
        r = await client.get("/api/translate/languages")
        assert r.status_code == 200
        data = r.json()
        assert "languages" in data
        assert data["count"] >= 50

    async def test_languages_include_african(self, client):
        r    = await client.get("/api/translate/languages")
        codes = {l["code"] for l in r.json()["languages"]}
        assert "wo" in codes  # Wolof
        assert "sw" in codes  # Swahili
        assert "ha" in codes  # Hausa
        assert "ff" in codes  # Fula

# ── Payments ───────────────────────────────────
class TestPayments:
    async def test_plans_endpoint(self, client):
        r = await client.get("/api/payments/plans")
        assert r.status_code == 200
        data = r.json()
        assert "plans" in data
        assert "free" in data["plans"]
        assert "pro" in data["plans"]
        assert "enterprise" in data["plans"]
        assert "credit_packs" in data
        assert len(data["credit_packs"]) == 3

    async def test_plans_pricing(self, client):
        r     = await client.get("/api/payments/plans")
        plans = r.json()["plans"]
        assert plans["free"]["price_usd"] == 0
        assert plans["pro"]["price_usd"] == 29
        assert plans["enterprise"]["price_usd"] == 99

    async def test_checkout_no_stripe(self, client):
        r = await client.post("/api/payments/checkout", json={
            "plan": "pro", "user_email": "test@test.com"})
        assert r.status_code == 200
        data = r.json()
        # Should return error message (not crash) when Stripe not configured
        assert "error" in data or "checkout_url" in data

# ── Notifications ──────────────────────────────
class TestNotifications:
    async def test_history_endpoint(self, client):
        r = await client.get("/api/notifications/history")
        assert r.status_code == 200
        assert "notifications" in r.json()

    async def test_send_test_notification(self, client):
        r = await client.post("/api/notifications/test?title=Test&body=Hello&level=info")
        assert r.status_code == 200
        assert r.json()["status"] == "sent"

    async def test_subscriber_count(self, client):
        r = await client.get("/api/notifications/subscribers")
        assert r.status_code == 200
        assert "active_sessions" in r.json()

    async def test_clear_history(self, client):
        await client.post("/api/notifications/test?title=T&body=B")
        r = await client.delete("/api/notifications/history")
        assert r.status_code == 200

# ── Scheduler ──────────────────────────────────
class TestScheduler:
    async def test_content_calendar(self, client):
        r = await client.get("/api/scheduler/calendar")
        assert r.status_code == 200
        assert "posts" in r.json()

    async def test_ai_caption(self, client):
        r = await client.get("/api/scheduler/ai-caption?title=Amazing+space+facts&niche=science")
        assert r.status_code == 200
        # Should return without crashing even if Anthropic key is test key
        assert r.status_code in [200, 500]

    async def test_scheduler_analytics(self, client):
        r = await client.get("/api/scheduler/analytics")
        assert r.status_code == 200
        assert "total" in r.json()

# ── Shorts / Niches ────────────────────────────
class TestShorts:
    async def test_niches_list(self, client):
        r = await client.get("/api/shorts/niches")
        assert r.status_code == 200
        data = r.json()
        assert "niches" in data
        niches = data["niches"]
        assert len(niches) >= 8
        for niche in niches:
            assert "id" in niche
            assert "name" in niche
            assert "icon" in niche
            assert "viral_score" in niche

# ── Calendar ───────────────────────────────────
class TestCalendar:
    async def test_today_events(self, client):
        r = await client.get("/api/calendar/today")
        assert r.status_code == 200
        assert "events" in r.json()

    async def test_create_event(self, client):
        r = await client.post("/api/calendar/create", json={
            "title": "Test Meeting", "start": "2026-06-15T14:00:00",
            "duration": 60, "location": "Zoom"})
        assert r.status_code == 200
        data = r.json()
        assert "status" in data

# ── Email ──────────────────────────────────────
class TestEmail:
    async def test_send_email_endpoint(self, client):
        r = await client.post("/api/email/send", json={
            "to": "test@example.com", "subject": "Test", "body": "Hello"})
        assert r.status_code == 200

    async def test_ai_draft_endpoint(self, client):
        r = await client.post("/api/email/ai-draft", json={
            "context": "Meeting confirmation for Monday at 10am", "tone": "professional"})
        assert r.status_code == 200
        # Will return AI draft or error — just check it doesn't crash

# ── Notion ─────────────────────────────────────
class TestNotion:
    async def test_search_no_key(self, client):
        r = await client.get("/api/notion/search?query=test")
        assert r.status_code == 200

    async def test_databases_no_key(self, client):
        r = await client.get("/api/notion/databases")
        assert r.status_code == 200

# ── Video ──────────────────────────────────────
class TestVideo:
    async def test_video_library(self, client):
        r = await client.get("/api/video/library")
        assert r.status_code == 200
        assert "videos" in r.json()

    async def test_video_status_not_found(self, client):
        r = await client.get("/api/video/status/nonexistent-job-id")
        assert r.status_code == 200
        assert r.json()["status"] == "not_found"

# ── Media ──────────────────────────────────────
class TestMedia:
    async def test_webhook_status(self, client):
        r = await client.get("/api/media/webhooks/status")
        assert r.status_code == 200
        assert "webhooks" in r.json()

    async def test_music_status_not_found(self, client):
        r = await client.get("/api/media/music/status/nonexistent-job")
        assert r.status_code == 200
        assert r.json()["status"] == "not_found"

# ── Google OAuth ───────────────────────────────
class TestGoogle:
    async def test_status_endpoint(self, client):
        r = await client.get("/api/google/status")
        assert r.status_code == 200
        assert "connected" in r.json()

    async def test_today_events(self, client):
        r = await client.get("/api/google/calendar/today")
        assert r.status_code == 200
        assert "events" in r.json()

    async def test_inbox(self, client):
        r = await client.get("/api/google/gmail/inbox")
        assert r.status_code == 200
        assert "messages" in r.json()

# ── Calls ──────────────────────────────────────
class TestCalls:
    async def test_list_calls_no_key(self, client):
        r = await client.get("/api/calls/calls")
        assert r.status_code == 200

    async def test_make_call_no_key(self, client):
        r = await client.post("/api/calls/make-call", json={
            "phone_number": "+221771234567", "message": "Test call"})
        assert r.status_code == 200
        # Should return error (not crash) when VAPI not configured

    async def test_send_sms_no_key(self, client):
        r = await client.post("/api/calls/sms", json={
            "to": "+221771234567", "message": "Test SMS"})
        assert r.status_code == 200

# ── Integration ────────────────────────────────
class TestIntegration:
    async def test_full_contact_lifecycle(self, client):
        # Create
        cr = await client.post("/api/contacts/", json={
            "name": "Integration Test", "phone": "+221779876543", "tags": ["integration"]})
        assert cr.status_code == 201
        cid = cr.json()["id"]
        # Read
        gr = await client.get(f"/api/contacts/{cid}")
        assert gr.status_code == 200
        assert gr.json()["name"] == "Integration Test"
        # Update
        ur = await client.patch(f"/api/contacts/{cid}", json={"company": "Test Corp"})
        assert ur.status_code == 200
        # Tag filter
        tr = await client.get("/api/contacts/?tag=integration")
        assert any(c["id"] == cid for c in tr.json()["contacts"])
        # Delete
        dr = await client.delete(f"/api/contacts/{cid}")
        assert dr.status_code == 200

    async def test_note_create_and_list(self, client):
        cr  = await client.post("/api/notes/create", json={"title": "Integration Note", "content": "Full content here"})
        nid = cr.json()["id"]
        lr  = await client.get("/api/notes/list")
        ids = [n["id"] for n in lr.json()["notes"]]
        assert nid in ids

    async def test_analytics_reflect_data(self, client):
        await client.post("/api/notes/create", json={"title": "Analytics Test", "content": "x"})
        r = await client.get("/api/analytics/dashboard")
        assert r.status_code == 200

    async def test_cost_calculation_accuracy(self, client):
        r = await client.get("/api/analytics/cost-estimate?images=10&videos_seconds=0&claude_tokens=0")
        assert r.status_code == 200
        # 10 DALL-E 3 images × $0.04 = $0.40
        total = r.json()["total_usd"]
        assert abs(total - 0.40) < 0.01

def pytest_configure(config):
    config.addinivalue_line("markers", "asyncio: mark test as async")



# ── New endpoint tests ──────────────────────────────────────────
class TestNewEndpoints:
    async def test_settings_keys_get(self, client, auth_headers):
        r = await client.get("/api/auth/settings/keys", headers=auth_headers)
        assert r.status_code == 200
        data = r.json()
        assert "openai" in data
        assert isinstance(data["openai"], bool)

    async def test_settings_keys_post(self, client, auth_headers):
        r = await client.post("/api/auth/settings/keys",
                              json={"OPENAI_API_KEY": "test-key-123"},
                              headers=auth_headers)
        assert r.status_code == 200
        data = r.json()
        assert "keys_updated" in data

    async def test_credits_endpoint(self, client, auth_headers):
        r = await client.get("/api/auth/credits", headers=auth_headers)
        assert r.status_code == 200
        data = r.json()
        assert "credits" in data
        assert "plan" in data

    async def test_notion_pull(self, client, auth_headers):
        r = await client.get("/api/notion/pull", headers=auth_headers)
        assert r.status_code == 200
        data = r.json()
        assert "synced" in data

    async def test_library_download_all(self, client, auth_headers):
        r = await client.get("/api/library/download-all", headers=auth_headers)
        assert r.status_code == 200
        data = r.json()
        assert "items" in data
        assert "count" in data

    async def test_whatsapp_setup_guide(self, client):
        r = await client.get("/api/whatsapp/setup-guide")
        assert r.status_code == 200
        data = r.json()
        assert "webhook_url" in data
        assert "steps" in data
        assert len(data["steps"]) >= 5

    async def test_health_has_summary(self, client):
        r = await client.get("/api/health")
        assert r.status_code == 200
        data = r.json()
        assert "summary" in data
        assert "version" in data
        assert data["version"] == "5.0.0"

    async def test_video_library(self, client, auth_headers):
        r = await client.get("/api/video/library", headers=auth_headers)
        assert r.status_code == 200
        data = r.json()
        assert "videos" in data

    async def test_preview_page(self, client):
        r = await client.get("/preview")
        assert r.status_code == 200

    async def test_add_credits_non_admin(self, client, auth_headers):
        r = await client.post("/api/auth/credits/add?amount=100", headers=auth_headers)
        assert r.status_code == 403  # non-admin should be rejected


# ── Regression tests for audit fixes ────────────────────────────
class TestAuditFixes:
    """Regression tests for bugs found in the full audit."""

    async def test_voices_no_key_returns_empty_not_500(self, client, auth_headers):
        """BUG: /voices did `return r.json()` with no guard — crashed on non-JSON."""
        r = await client.get("/api/voice/voices", headers=auth_headers)
        assert r.status_code < 500, f"Should degrade gracefully, got {r.status_code}"
        data = r.json()
        assert "voices" in data
        assert isinstance(data["voices"], list)

    async def test_google_callback_missing_dep_is_503(self, client):
        """BUG: /google/callback raised bare ModuleNotFoundError → opaque 500."""
        r = await client.get("/api/google/callback?code=fake")
        # 503 (dep missing) or 400/500 with structured body — never an unhandled crash
        assert r.status_code in (400, 500, 503)
        body = r.json()
        assert "error" in body

    async def test_db_endpoints_do_not_500(self, client, auth_headers):
        """BUG: DB endpoints returned raw 500 when tables missing."""
        for path in ["/api/library/all", "/api/contacts/",
                     "/api/notes/list", "/api/analytics/dashboard"]:
            r = await client.get(path, headers=auth_headers)
            assert r.status_code < 500, f"{path} returned {r.status_code}"

    async def test_library_stats_ok(self, client, auth_headers):
        r = await client.get("/api/library/stats", headers=auth_headers)
        assert r.status_code == 200

    async def test_whatsapp_contacts_ok(self, client, auth_headers):
        r = await client.get("/api/whatsapp/contacts", headers=auth_headers)
        assert r.status_code == 200

    async def test_graphify_models_400_plus(self, client, auth_headers):
        """Graphify must expose the full model library."""
        r = await client.get("/api/graphify/models?limit=500", headers=auth_headers)
        assert r.status_code == 200
        data = r.json()
        assert "models" in data
        assert len(data["categories"]) >= 10

    async def test_graphify_categories(self, client, auth_headers):
        r = await client.get("/api/graphify/models/categories", headers=auth_headers)
        assert r.status_code == 200
        assert "categories" in r.json()

    async def test_graphify_templates(self, client, auth_headers):
        r = await client.get("/api/graphify/templates", headers=auth_headers)
        assert r.status_code == 200
        assert len(r.json()["templates"]) >= 10

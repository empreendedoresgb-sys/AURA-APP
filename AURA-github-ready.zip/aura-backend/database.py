"""AURA - Database models and session management"""
import os
from datetime import datetime
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import String, Text, Integer, DateTime, Boolean, JSON, Float
from config import settings

DATABASE_URL = settings.DATABASE_URL.replace("sqlite:///", "sqlite+aiosqlite:///")
engine = create_async_engine(DATABASE_URL, echo=False)
AsyncSessionLocal = async_sessionmaker(engine, expire_on_commit=False)

class Base(DeclarativeBase):
    pass

# Core models
class User(Base):
    __tablename__ = "users"
    id:           Mapped[int]  = mapped_column(Integer, primary_key=True)
    phone:        Mapped[str]  = mapped_column(String(20), unique=True, index=True)
    name:         Mapped[str]  = mapped_column(String(100), default="")
    voice_id:     Mapped[str]  = mapped_column(String(100), default="")
    language:     Mapped[str]  = mapped_column(String(10), default="en")
    created_at:   Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Conversation(Base):
    __tablename__ = "conversations"
    id:           Mapped[int]  = mapped_column(Integer, primary_key=True)
    phone:        Mapped[str]  = mapped_column(String(20), index=True)
    role:         Mapped[str]  = mapped_column(String(10))
    content:      Mapped[str]  = mapped_column(Text)
    media_url:    Mapped[str]  = mapped_column(String(500), default="")
    created_at:   Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class MediaItem(Base):
    __tablename__ = "media_library"
    id:           Mapped[int]  = mapped_column(Integer, primary_key=True)
    type:         Mapped[str]  = mapped_column(String(20))
    name:         Mapped[str]  = mapped_column(String(200))
    path:         Mapped[str]  = mapped_column(String(500), default="")
    url:          Mapped[str]  = mapped_column(String(500), default="")
    meta:         Mapped[dict] = mapped_column(JSON, default=dict)
    created_at:   Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Note(Base):
    __tablename__ = "notes"
    id:           Mapped[int]  = mapped_column(Integer, primary_key=True)
    title:        Mapped[str]  = mapped_column(String(200))
    content:      Mapped[str]  = mapped_column(Text, default="")
    source:       Mapped[str]  = mapped_column(String(50), default="manual")
    created_at:   Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at:   Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class VoiceClone(Base):
    __tablename__ = "voice_clones"
    id:            Mapped[int]  = mapped_column(Integer, primary_key=True)
    name:          Mapped[str]  = mapped_column(String(100))
    elevenlabs_id: Mapped[str]  = mapped_column(String(100))
    language:      Mapped[str]  = mapped_column(String(10), default="en")
    is_default:    Mapped[bool] = mapped_column(Boolean, default=False)
    created_at:    Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class AuthUser(Base):
    __tablename__ = "auth_users"
    id:           Mapped[int]  = mapped_column(Integer, primary_key=True)
    email:        Mapped[str]  = mapped_column(String(200), unique=True, index=True)
    username:     Mapped[str]  = mapped_column(String(100), unique=True)
    hashed_pass:  Mapped[str]  = mapped_column(String(200))
    api_key:      Mapped[str]  = mapped_column(String(64), unique=True, index=True)
    is_active:    Mapped[bool] = mapped_column(Boolean, default=True)
    is_admin:     Mapped[bool] = mapped_column(Boolean, default=False)
    plan:         Mapped[str]  = mapped_column(String(20), default="free")
    credits:      Mapped[int]  = mapped_column(Integer, default=100)
    created_at:   Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    last_login:   Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class UsageLog(Base):
    __tablename__ = "usage_logs"
    id:         Mapped[int]   = mapped_column(Integer, primary_key=True)
    user_id:    Mapped[int]   = mapped_column(Integer, index=True)
    action:     Mapped[str]   = mapped_column(String(100))
    model:      Mapped[str]   = mapped_column(String(50), default="")
    tokens:     Mapped[int]   = mapped_column(Integer, default=0)
    cost_usd:   Mapped[float] = mapped_column(Float, default=0.0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Contact(Base):
    __tablename__ = "contacts"
    id:           Mapped[int]  = mapped_column(Integer, primary_key=True)
    name:         Mapped[str]  = mapped_column(String(200), index=True)
    phone:        Mapped[str]  = mapped_column(String(30), default="", index=True)
    email:        Mapped[str]  = mapped_column(String(200), default="", index=True)
    company:      Mapped[str]  = mapped_column(String(200), default="")
    role:         Mapped[str]  = mapped_column(String(100), default="")
    tags:         Mapped[list] = mapped_column(JSON, default=list)
    notes:        Mapped[str]  = mapped_column(Text, default="")
    wa_status:    Mapped[str]  = mapped_column(String(20), default="unknown")
    last_contact: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    created_at:   Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class ScheduledPost(Base):
    __tablename__ = "scheduled_posts"
    id:           Mapped[int]      = mapped_column(Integer, primary_key=True)
    title:        Mapped[str]      = mapped_column(String(200))
    media_url:    Mapped[str]      = mapped_column(String(500))
    caption:      Mapped[str]      = mapped_column(Text, default="")
    hashtags:     Mapped[str]      = mapped_column(Text, default="")
    platforms:    Mapped[list]     = mapped_column(JSON, default=list)
    scheduled_at: Mapped[datetime] = mapped_column(DateTime)
    status:       Mapped[str]      = mapped_column(String(20), default="scheduled")
    results:      Mapped[dict]     = mapped_column(JSON, default=dict)
    created_at:   Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

async def init_db():
    """Create all tables and seed default data"""
    for path in [settings.STORAGE_PATH,
                 f"{settings.STORAGE_PATH}/images",
                 f"{settings.STORAGE_PATH}/videos",
                 f"{settings.STORAGE_PATH}/audio",
                 f"{settings.STORAGE_PATH}/avatars"]:
        os.makedirs(path, exist_ok=True)

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    # Seed default admin user
    import secrets
    from passlib.context import CryptContext
    from sqlalchemy import select
    pwd_ctx = CryptContext(schemes=["pbkdf2_sha256"], deprecated="auto")
    async with AsyncSessionLocal() as db:
        result = await db.execute(select(AuthUser).limit(1))
        if not result.scalar_one_or_none():
            admin = AuthUser(
                email="admin@aura.ai",
                username="admin",
                hashed_pass=pwd_ctx.hash("aura2025!"),
                api_key=secrets.token_hex(32),
                is_admin=True,
                plan="enterprise",
                credits=99999,
            )
            db.add(admin)
            await db.commit()
            print("✅ Admin created: admin@aura.ai / aura2025!")
            print(f"   API Key: {admin.api_key}")

async def get_db():
    async with AsyncSessionLocal() as session:
        yield session

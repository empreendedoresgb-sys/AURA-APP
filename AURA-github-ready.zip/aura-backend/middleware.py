"""AURA - Production middleware stack"""
import time, uuid, logging
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

logging.basicConfig(level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S")
logger = logging.getLogger("aura")

RATE_LIMITS = {
    "/api/image/generate":  (10, 60),
    "/api/video/generate":  (5,  60),
    "/api/voice/tts":       (20, 60),
    "/api/voice/clone":     (3,  300),
    "/api/avatar":          (5,  120),
    "/api/calls/make-call": (10, 60),
    "default":              (120, 60),
}
_rate_store: dict = {}

class LoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if request.url.path.startswith(("/media/", "/api/health")):
            return await call_next(request)
        rid = str(uuid.uuid4())[:8]
        t0  = time.time()
        logger.info(f"→ {rid} {request.method} {request.url.path}")
        try:
            response = await call_next(request)
            ms = round((time.time() - t0) * 1000)
            logger.info(f"← {rid} {response.status_code} ({ms}ms)")
            response.headers["X-Request-ID"] = rid
            return response
        except Exception as e:
            logger.error(f"✗ {rid} {e}")
            raise

class RateLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if not request.url.path.startswith("/api/"):
            return await call_next(request)
        ip = request.client.host if request.client else "unknown"
        path = request.url.path
        limit, window = RATE_LIMITS.get("default")
        for pattern, (lim, win) in RATE_LIMITS.items():
            if pattern != "default" and path.startswith(pattern):
                limit, window = lim, win
                break
        key = f"{ip}:{path}"
        now = time.time()
        _rate_store[key] = [t for t in _rate_store.get(key, []) if now - t < window]
        if len(_rate_store[key]) >= limit:
            retry = int(window - (now - _rate_store[key][0]))
            return JSONResponse({"error": "Rate limit exceeded", "retry_after": retry},
                                status_code=429, headers={"Retry-After": str(retry)})
        _rate_store.setdefault(key, []).append(now)
        response = await call_next(request)
        response.headers["X-RateLimit-Limit"]     = str(limit)
        response.headers["X-RateLimit-Remaining"]  = str(limit - len(_rate_store[key]))
        return response

class ErrorHandlerMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        try:
            return await call_next(request)
        except Exception as e:
            logger.error(f"Unhandled: {request.url.path}: {type(e).__name__}: {e}")
            s = str(e).lower()

            # Missing DB tables — auto-heal by creating them, then tell client to retry
            if "no such table" in s or "does not exist" in s:
                try:
                    from database import init_db
                    await init_db()
                    logger.warning("DB tables were missing — auto-created. Retry the request.")
                    return JSONResponse(
                        {"error": "Database was uninitialized",
                         "detail": "Tables have now been created automatically. Please retry.",
                         "auto_healed": True},
                        status_code=503, headers={"Retry-After": "1"})
                except Exception as heal_err:
                    return JSONResponse(
                        {"error": "Database not initialized",
                         "detail": str(heal_err)[:200],
                         "fix": "Run: python3 -c \"import asyncio;from database import init_db;asyncio.run(init_db())\""},
                        status_code=503)

            # External service unavailable (missing optional dependency)
            if "no module named" in s:
                return JSONResponse(
                    {"error": "Optional dependency not installed",
                     "detail": str(e),
                     "fix": "pip install -r requirements.txt"},
                    status_code=503)

            # Malformed upstream response
            if "jsondecodeerror" in type(e).__name__.lower() or "expecting value" in s:
                return JSONResponse(
                    {"error": "Upstream API returned invalid response",
                     "detail": str(e)[:200],
                     "fix": "Check the relevant API key in Settings"},
                    status_code=502)

            if "api key" in s or "authentication" in s or "unauthorized" in s:
                return JSONResponse({"error": "API auth failed", "detail": str(e),
                                     "fix": "Check your API keys in Settings"}, status_code=401)
            elif "rate limit" in s or "429" in s:
                return JSONResponse({"error": "Rate limit", "detail": str(e)}, status_code=429)
            elif "timeout" in s:
                return JSONResponse({"error": "Timeout", "detail": str(e),
                                     "fix": "Try again or use a faster model"}, status_code=504)
            return JSONResponse({"error": "Internal error", "detail": str(e),
                                 "type": type(e).__name__}, status_code=500)

class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"]        = "SAMEORIGIN"
        response.headers["X-XSS-Protection"]       = "1; mode=block"
        return response

def register_middleware(app: FastAPI):
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(RateLimitMiddleware)
    app.add_middleware(ErrorHandlerMiddleware)
    app.add_middleware(LoggingMiddleware)
    logger.info("✅ Middleware registered")

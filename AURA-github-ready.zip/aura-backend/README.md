# AURA — AI Super Studio

One interface for image generation, video creation, voice cloning, a WhatsApp AI agent, AI phone calls, and a poster editor — instead of a dozen separate subscriptions.

**139 API endpoints · 21 UI pages · 89 tests · 25 route modules**

---

## Quick start

```bash
git clone https://github.com/YOUR_USERNAME/aura.git
cd aura
cp .env.example .env      # add your API keys
./start.sh                # macOS/Linux  —  start.bat on Windows
```

Open <http://localhost:8000> · login `admin@aura.ai` / `aura2025!`

Then click **🔑 Setup** in the topbar to paste your API keys — they're written to `.env` on the server, never to the browser.

| URL | What |
|---|---|
| `/` | The app |
| `/preview` | Device simulator — desktop, tablet, mobile |
| `/docs` | Swagger UI, all 139 endpoints |
| `/api/health` | Health check + which keys are configured |

---

## Features

### Create
- **Image studio** — DALL-E 3, Flux 1.1 Pro, Gemini Imagen, InstantID face cloning
- **Video studio** — Veo 3, Kling AI, with Suno-generated soundtracks
- **Voice clone** — ElevenLabs: 30s sample → your voice in 50 languages; Whisper transcription
- **AI Avatar** — HeyGen and D-ID talking-head video
- **Short videos** — viral script generator across 10 niches
- **Graphify** — drag-and-drop poster editor on an editable SVG canvas, 400+ AI models, export to PNG/SVG/PDF

### Productivity
- **WhatsApp AI agent** — 24/7, seven tools (calendar, email, image gen, calls, notes, contacts, weather), replies in your cloned voice
- **Phone calls** — Vapi.ai for AI calls, Twilio for SMS
- **Calendar & Email** — Google Calendar + Gmail with natural-language booking
- **Contacts CRM** — tags, CSV import/export, WhatsApp broadcast
- **Scheduler** — auto-publish to TikTok, Instagram, YouTube, Facebook

### Tools
AI chat (Claude / GPT-4o / Gemini, streaming) · 52-language translator · Notion two-way sync · analytics with a cost estimator in USD and F CFA · Stripe billing · ComfyUI + Hailo NPU

---

## Minimum keys

Four keys get you running. Everything else is optional and degrades gracefully — the UI tells you which key a feature needs.

| Key | Powers | Free tier |
|---|---|---|
| `OPENAI_API_KEY` | DALL-E 3, GPT-4o, Whisper | $5 credit |
| `ANTHROPIC_API_KEY` | Claude agent, chat, scripts | $5 trial |
| `ELEVENLABS_API_KEY` | Voice clone, TTS | 10k chars/mo |
| `JWT_SECRET` | Auth — `python3 -c "import secrets;print(secrets.token_hex(32))"` | — |

Full list with links in [`.env.example`](.env.example) and [`SETUP_GUIDE.md`](SETUP_GUIDE.md).

---

## Stack

- **Backend** — FastAPI, SQLAlchemy async, SQLite (PostgreSQL in production)
- **Frontend** — one self-contained HTML file. No build step, no `npm install`
- **Deploy** — Docker Compose: API + PostgreSQL + Nginx + n8n
- **Tests** — pytest, 89 passing

```bash
pytest tests.py --asyncio-mode=auto -q     # 89 passed
docker-compose up -d                       # full stack
```

---

## Project layout

```
aura/
├── main.py              FastAPI app, all routers
├── config.py            48 settings, read from .env
├── database.py          9 models
├── middleware.py        rate limiting, logging, error handling
├── tests.py             89 tests
├── routes/              25 modules, 139 endpoints
└── static/
    ├── index.html       the entire frontend, 21 pages
    └── preview.html     device simulator
```

---

## Security

`.env`, `google_token.json`, `*.db` and generated media are gitignored. API keys are stored server-side only and never reach the browser. Rotate `JWT_SECRET` and change the default admin password before exposing this to the internet.

## License

MIT

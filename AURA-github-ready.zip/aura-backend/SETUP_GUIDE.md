# AURA AI Super Studio — Complete Setup Guide

## What is AURA?

AURA is an all-in-one AI creative platform built on FastAPI + a single-file HTML frontend.  
It combines: voice cloning, image generation, video creation, WhatsApp AI agent, AI phone calls, content scheduler, contacts CRM, AI translator, and more — 24 route modules, 119+ API endpoints, 20 UI pages.

---

## Quick Start (5 minutes)

```bash
# 1. Unzip
unzip AURA-v5-FINAL.zip
cd aura-backend

# 2. Copy environment file
cp .env.example .env

# 3. Add minimum 4 keys to .env (open with any text editor)
nano .env   # or: code .env / notepad .env

# 4. Start
./start.sh        # Mac / Linux
start.bat         # Windows

# 5. Open browser
# App:     http://localhost:8000
# Preview: http://localhost:8000/preview
# API docs: http://localhost:8000/docs
```

**Default login:** `admin@aura.ai` / `aura2025!`

---

## Minimum API Keys (to start)

Add these 4 keys to your `.env` file:

| Key | Where to get it | Free tier |
|-----|----------------|-----------|
| `OPENAI_API_KEY` | platform.openai.com → API Keys | $5 free credit |
| `ANTHROPIC_API_KEY` | console.anthropic.com → API Keys | $5 trial |
| `ELEVENLABS_API_KEY` | elevenlabs.io → Profile → API Key | 10,000 chars/mo free |
| `JWT_SECRET` | Generate: `python3 -c "import secrets; print(secrets.token_hex(32))"` | — |

---

## Full Configuration

### AI Models
```env
OPENAI_API_KEY=sk-...          # DALL-E 3, GPT-4o, Whisper STT
ANTHROPIC_API_KEY=sk-ant-...   # Claude — main reasoning engine
GEMINI_API_KEY=AIza...         # Veo 3 video, Gemini Imagen 3
QWEN_API_KEY=...               # Qwen Max (optional)
```

### Voice & Audio
```env
ELEVENLABS_API_KEY=xi-api-key-...
ELEVENLABS_VOICE_ID=           # Set after cloning your voice
VAPI_API_KEY=...               # vapi.ai — AI phone calls ($10 free)
TWILIO_ACCOUNT_SID=AC...       # Twilio SMS
TWILIO_AUTH_TOKEN=...
TWILIO_PHONE=+1234567890
```

### Video & Avatars
```env
HEYGEN_API_KEY=...             # heygen.com (3 free videos/month)
DID_API_KEY=...                # d-id.com
KLING_API_KEY=...              # klingai.com
REPLICATE_API_KEY=r8_...       # replicate.com (InstantID, Flux)
SUNO_API_KEY=...               # suno.ai music generation
```

### WhatsApp (Meta Cloud API)
```env
WHATSAPP_TOKEN=EAAG...         # developers.facebook.com → WhatsApp → API Setup
WHATSAPP_PHONE_ID=123456789    # Your WhatsApp Business phone ID
WHATSAPP_VERIFY_TOKEN=aura_verify_2025  # Must match what you set in Meta webhook
```

### Social Media Scheduler
```env
TIKTOK_ACCESS_TOKEN=...        # developers.tiktok.com
INSTAGRAM_ACCESS_TOKEN=...     # Graph API
INSTAGRAM_USER_ID=...
YOUTUBE_ACCESS_TOKEN=...
FACEBOOK_PAGE_TOKEN=...
FACEBOOK_PAGE_ID=...
```

### Payments (Stripe)
```env
STRIPE_SECRET_KEY=sk_live_...  # dashboard.stripe.com → Developers
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRO_PRICE_ID=price_...
STRIPE_ENTERPRISE_PRICE_ID=price_...
```

### Google OAuth (Calendar + Gmail)
```env
GOOGLE_CLIENT_ID=...apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=GOCSPX-...
```
After setting: visit `http://localhost:8000/api/google/auth` to connect.

### Notion
```env
NOTION_API_KEY=secret_...      # notion.so/my-integrations
```

### Infrastructure
```env
JWT_SECRET=...                 # REQUIRED — generate with python3 -c "import secrets; print(secrets.token_hex(32))"
DATABASE_URL=sqlite:///./aura.db  # Default SQLite. For production: postgresql+asyncpg://...
STORAGE_PATH=./media
WEBHOOK_BASE_URL=https://your-domain.com  # For WhatsApp webhook registration
COMFYUI_URL=http://127.0.0.1:8188         # If using ComfyUI locally
```

---

## Connecting WhatsApp

1. Go to [developers.facebook.com](https://developers.facebook.com)
2. Create an app → Add WhatsApp product
3. Get your `WHATSAPP_TOKEN` and `WHATSAPP_PHONE_ID`
4. Set webhook URL to: `https://your-domain.com/api/media/webhooks/whatsapp`
5. Set verify token to: `aura_verify_2025` (or your custom value in `.env`)
6. Subscribe to: `messages`

The AURA WhatsApp agent will automatically:
- Transcribe voice notes (Whisper)
- Describe images (GPT-4o Vision)
- Detect language, translate to English, process, translate back
- Use 7 tools: Calendar, Email, Notes, Image gen, Phone calls, Contacts, Weather
- Reply with ElevenLabs TTS voice note

---

## Production Deployment (Docker)

```bash
# Edit .env with all your production keys
nano .env

# Start everything (API + PostgreSQL + Nginx + n8n)
docker-compose up -d

# Check logs
docker-compose logs -f aura-api

# Stop
docker-compose down
```

The docker-compose includes:
- `aura-api` — FastAPI backend (4 workers)
- `postgres` — PostgreSQL database
- `nginx` — Reverse proxy + SSL termination
- `n8n` — Workflow automation (port 5678)

---

## n8n Workflow Automation

Import `n8n_all_workflows.json` into your n8n instance:

1. Start n8n: `docker-compose up -d n8n` or `npx n8n`
2. Open: `http://localhost:5678`
3. Import → paste the JSON file
4. Replace `YOUR_AURA_BACKEND` with `http://localhost:8000`
5. Replace API keys in each node
6. Activate workflows

**Included workflows:**
- WhatsApp → Image generation → Send back
- Daily short video → AI caption → Publish to all platforms
- WhatsApp voice agent: STT → Claude → ElevenLabs → voice reply

---

## Health Check & Monitoring

```bash
# Quick health check
python3 health_monitor.py

# Continuous monitoring (alerts every 60s)
python3 health_monitor.py --monitor

# Set Discord/Slack webhook for alerts:
ALERT_WEBHOOK=https://hooks.slack.com/...
```

---

## Run Tests

```bash
cd aura-backend
pytest tests.py --asyncio-mode=auto -v
# → 71 passed
```

---

## API Documentation

Interactive Swagger UI: `http://localhost:8000/docs`  
ReDoc: `http://localhost:8000/redoc`

All 119+ endpoints documented with request/response schemas.

---

## File Structure

```
aura-backend/
├── main.py                 — FastAPI app, all routers registered
├── config.py               — All 48 settings (reads from .env)
├── database.py             — SQLAlchemy models: User, Contact, Note, MediaItem, etc.
├── middleware.py           — Rate limiting, logging, error handling
├── tests.py                — 71 test cases
├── health_monitor.py       — Production monitoring
├── requirements.txt        — Python dependencies
├── start.sh / start.bat    — One-command launch
├── .env.example            — All environment variables documented
├── Dockerfile              — Python 3.12 + ffmpeg
├── docker-compose.yml      — Full stack: API + PostgreSQL + Nginx + n8n
├── nginx.conf              — Reverse proxy config
├── n8n_all_workflows.json  — 3 importable n8n workflows
│
├── routes/                 — 24 route modules
│   ├── auth_routes.py      — JWT login/register/API keys
│   ├── voice_routes.py     — ElevenLabs clone + Whisper STT
│   ├── image_routes.py     — DALL-E 3, Flux, InstantID
│   ├── video_routes.py     — Veo 3, Kling, Suno music
│   ├── avatar_routes.py    — HeyGen, D-ID
│   ├── shorts_routes.py    — Viral script generator, 10 niches
│   ├── whatsapp_routes.py  — Full AI agent (7 tools, 50 languages)
│   ├── agent_routes.py     — Claude/GPT-4o/Gemini/Qwen chat
│   ├── stream_routes.py    — SSE streaming, voice pipeline
│   ├── calls_routes.py     — Vapi.ai + Twilio SMS
│   ├── calendar_routes.py  — AI booking + Google Calendar
│   ├── email_routes.py     — Gmail + AI draft
│   ├── google_routes.py    — OAuth2, Calendar, Gmail live
│   ├── notes_routes.py     — CRUD + Notion sync
│   ├── library_routes.py   — Media CRUD
│   ├── contacts_routes.py  — CRM + CSV + broadcast
│   ├── translate_routes.py — 50+ languages text/voice/doc
│   ├── scheduler_routes.py — Social media auto-publish
│   ├── notion_routes.py    — Pages + databases + sync
│   ├── analytics_routes.py — Usage + costs (USD + FCFA)
│   ├── media_routes.py     — Suno music + WA media + webhooks
│   ├── payments_routes.py  — Stripe plans + credits
│   ├── comfy_routes.py     — ComfyUI + Hailo NPU
│   └── notifications_routes.py — SSE real-time push
│
└── static/
    ├── index.html          — Complete SPA (180KB, 20 pages)
    ├── preview.html        — Standalone device simulator
    ├── manifest.json       — PWA manifest
    └── sw.js               — Service worker (offline cache)
```

---

## Troubleshooting

**Backend won't start:**
```bash
# Check Python version (need 3.10+)
python3 --version
# Install dependencies manually
pip install -r requirements.txt
```

**"No module named X":**
```bash
pip install -r requirements.txt --break-system-packages
```

**Database errors:**
```bash
# Reset database
rm aura.db
python3 -c "import asyncio; from database import init_db; asyncio.run(init_db())"
```

**WhatsApp not receiving messages:**
- Verify webhook URL is publicly accessible (use ngrok for local dev: `ngrok http 8000`)
- Check Meta webhook subscription is active
- Verify `WHATSAPP_VERIFY_TOKEN` matches what you set in Meta dashboard

**Port 8000 already in use:**
```bash
# Change port in .env
PORT=8001
# Or kill existing process
lsof -ti:8000 | xargs kill
```

---

## Support

- API docs: `http://localhost:8000/docs`
- Health check: `http://localhost:8000/api/health`
- Preview: `http://localhost:8000/preview`

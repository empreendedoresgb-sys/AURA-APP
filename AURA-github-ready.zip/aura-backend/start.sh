#!/bin/bash
# AURA AI Super Studio — Quick Start Script
set -e

echo "⚡ AURA AI Super Studio v5.0"
echo "================================"

# Check Python
if ! command -v python3 &>/dev/null; then
    echo "❌ Python 3 not found — install from python.org"
    exit 1
fi
PYTHON_VER=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "✅ Python $PYTHON_VER"

# Create .env if missing
if [ ! -f .env ]; then
    cp .env.example .env
    echo "📝 Created .env from template — add your API keys!"
    echo "   Minimum required: OPENAI_API_KEY, ANTHROPIC_API_KEY, ELEVENLABS_API_KEY"
    echo "   Generate JWT_SECRET: python3 -c \"import secrets; print(secrets.token_hex(32))\""
fi

# Install dependencies
echo "📦 Installing dependencies..."
pip install -r requirements.txt -q --break-system-packages 2>/dev/null || pip install -r requirements.txt -q

# Create directories
mkdir -p media/images media/videos media/audio media/avatars static

# Initialize database (creates admin user automatically)
echo "🗄️  Initializing database..."
python3 -c "
import asyncio
from database import init_db
asyncio.run(init_db())
print('✅ Database ready')
"

# Check API keys
echo ""
echo "🔑 API Key Status:"
python3 -c "
import os
from dotenv import load_dotenv
load_dotenv()
keys = {
    'OPENAI_API_KEY':    ('🤖 OpenAI',    'DALL-E 3, GPT-4o, Whisper'),
    'ANTHROPIC_API_KEY': ('🧠 Anthropic', 'Claude agent, chat'),
    'ELEVENLABS_API_KEY':('🎤 ElevenLabs','Voice clone, TTS'),
    'WHATSAPP_TOKEN':    ('💬 WhatsApp',  'AI agent'),
    'VAPI_API_KEY':      ('📞 Vapi.ai',   'Phone calls'),
}
configured = 0
for env_key, (label, desc) in keys.items():
    val = os.getenv(env_key, '')
    if val and not val.startswith('your_'):
        print(f'  ✅ {label} ({desc})')
        configured += 1
    else:
        print(f'  ⚠️  {label} — missing ({desc})')
print(f'')
print(f'  {configured}/{len(keys)} keys configured')
if configured < 2:
    print('  → Open http://localhost:8000 → click 🔑 Setup in topbar to add keys')
" 2>/dev/null || echo "  Add keys in Settings page after starting"

# Start server
PORT=${PORT:-8000}
echo ""
echo "🚀 Starting AURA on port $PORT..."
echo ""
echo "  App:         http://localhost:$PORT"
echo "  Preview:     http://localhost:$PORT/preview"
echo "  API docs:    http://localhost:$PORT/docs"
echo "  Health:      http://localhost:$PORT/api/health"
echo ""
echo "  Login:       admin@aura.ai / aura2025!"
echo ""
echo "  Press Ctrl+C to stop"
echo "================================"
echo ""

# Run with auto-reload in dev mode, 4 workers in production
if [ "${AURA_ENV:-dev}" = "production" ]; then
    exec uvicorn main:app --host 0.0.0.0 --port $PORT --workers 4 --log-level info
else
    exec uvicorn main:app --host 0.0.0.0 --port $PORT --reload --log-level info
fi

@echo off
echo ⚡ AURA AI Super Studio v5.0
echo ================================
if not exist .env (
    copy .env.example .env
    echo 📝 Created .env — add your API keys!
)
pip install -r requirements.txt -q
python -c "import asyncio; from database import init_db; asyncio.run(init_db())"
echo.
echo 🚀 Starting AURA on http://localhost:8000
echo    Login: admin@aura.ai / aura2025!
echo    Preview: http://localhost:8000/preview
echo    Press Ctrl+C to stop
echo.
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
